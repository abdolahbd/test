// src/components/common/PrivateRoute.js
import React, { useContext } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { AuthContext } from '../../contexts/AuthContext';

const PrivateRoute = ({ children }) => {
  const { user, loading } = useContext(AuthContext);
  const location = useLocation();
  const LMARHALA = process.env.REACT_APP_LMARHALA;

  // If still checking auth
  if (loading) {
    return <div>Loading...</div>;
  }

  // Check if we are on a /chat route AND LMARHALA is 1 or 2:
  const isChatRoute = location.pathname.startsWith('/chat/');
  const marhalaIsOneOrTwo = LMARHALA === '1' || LMARHALA === '2';

  // If user not logged in:
  if (!user) {
    console.log(location);
    
    // If it's the chat route & LMARHALA is 1 or 2 => go to Google
    if (isChatRoute && marhalaIsOneOrTwo) {
      return <Navigate to={location.pathname.replace('chat','start')} />;
    }
    // Otherwise, go to your normal login page (or any other route you want)
    return <Navigate to="/login" />;
  }

  // If user is authenticated, render the children
  return children;
};

export default PrivateRoute;
