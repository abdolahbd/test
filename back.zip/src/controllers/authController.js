// src/controllers/authController.js
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { validationResult } = require('express-validator');
require('dotenv').config();

exports.register = async (req, res) => {
  try {
    // Validate request data
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }




    const { email, password, apiKey, name } = req.body; // <-- Extract name

    // Check if user already exists
    let user = await User.findOne({ where: { email } });
    if (user) {
      return res.status(400).json({ error: 'User already exists' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create new user
    user = await User.create({
      name:'name',     
      email,
      password: hashedPassword,
      apiKey:`{}`,
    });

    // Generate JWT token
    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, {
      expiresIn: '1h',
    });

    res.status(201).json({ token });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Registration failed' });
  }
};




exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ where: { email } });
    if (!user) return res.status(400).json({ error: 'Invalid credentials' });

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) return res.status(400).json({ error: 'Invalid credentials' });

    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET);
    res.json({ token });
  } catch (err) {
    res.status(400).json({ error: 'Login failed' });
  }
};



 exports.googleSaveKeys = async (req, res) => {
     try {
       // 1. We assume the token is set in the Authorization header as 'Bearer <token>'
       const authHeader = req.headers.authorization;
       if (!authHeader) {
         return res.status(401).json({ error: 'No authorization header' });
       }
  
       const token = authHeader.split(' ')[1];
       if (!token) {
         return res.status(401).json({ error: 'Invalid authorization header' });
       }
  
       // 2. Decode token and find user
       const decoded = jwt.verify(token, process.env.JWT_SECRET);
       const user = await User.findByPk(decoded.id);
       if (!user) {
         return res.status(404).json({ error: 'User not found' });
       }
  
       // 3. Save the API keys (they come in req.body.apiKeys as an object)
       //    If you store them in a JSON column or a string, adjust accordingly:
       user.apiKey = JSON.stringify(req.body.apiKeys);
       await user.save();
  
       return res.json({ message: 'API keys saved successfully' });
     } catch (err) {
       console.error('Error saving API keys:', err);
       return res.status(500).json({ error: 'Internal server error' });
     }
   };