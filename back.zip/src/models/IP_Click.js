// models/IP_Click.js

const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const IP_Click = sequelize.define('IP_Click', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  ipAddress: { 
    type: DataTypes.STRING, 
    allowNull: false, 
    unique: true // Ensures one record per unique IP
  },
  clickCount: { 
    type: DataTypes.INTEGER, 
    allowNull: false,
    defaultValue: 0 
  },
  conversationCount: { 
    type: DataTypes.INTEGER, 
    allowNull: false,
    defaultValue: 0 
  },
  favoriteCount: { 
    type: DataTypes.INTEGER, 
    allowNull: false,
    defaultValue: 0 
  },
  isLimitReached: { 
    type: DataTypes.TEXT
  },
  timestamp: { 
    type: DataTypes.DATE, 
    allowNull: false, 
    defaultValue: DataTypes.NOW 
  },
}, {
  tableName: 'ip_clicks',
  timestamps: false, // Disables Sequelize's automatic timestamps
});

module.exports = IP_Click;
