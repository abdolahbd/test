// src/components/pages/ChatPage.js

import React, { useState, useRef, useEffect, useContext } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import api from '../../services/apiService';
import Modal from 'react-modal';
import './ChatPage.css';
import { AuthContext } from '../../contexts/AuthContext';
import ReviewModal from '../Modals/ReviewModal';
import HelpModal from '../Modals/HelpModal';
import ShareModal from '../Modals/ShareModal';
import CryptoJS from 'crypto-js';

const encryptionKey = process.env.REACT_APP_ENCRYPTION_KEY;

const encryptData = (data) => {
  if (!encryptionKey) {
    throw new Error('Encryption key is missing. Please set REACT_APP_ENCRYPTION_KEY in your .env file.');
  }
  return CryptoJS.AES.encrypt(data, encryptionKey).toString();
};

const decryptData = (cipherText) => {
  if (!encryptionKey) {
    throw new Error('Encryption key is missing. Please set REACT_APP_ENCRYPTION_KEY in your .env file.');
  }
  try {
    const bytes = CryptoJS.AES.decrypt(cipherText, encryptionKey);
    const decrypted = bytes.toString(CryptoJS.enc.Utf8);
    if (!decrypted) {
      throw new Error('Decryption failed. Invalid ciphertext or encryption key.');
    }
    return decrypted;
  } catch (error) {
    console.error('Error during decryption:', error);
    throw new Error('Failed to decrypt data.');
  }
};

const readFileAsDataURL = (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

// Detect environment
const isFileSystemAccessSupported = !!window.showDirectoryPicker;
const useIndexedDB = !isFileSystemAccessSupported;

// IndexedDB utilities
let dbPromise = null;

const initIndexedDB = () => {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const request = window.indexedDB.open('myAppDB', 2);
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains('files')) {
          db.createObjectStore('files', { keyPath: 'path' });
        }
      };
      request.onsuccess = () => {
        resolve(request.result);
      };
      request.onerror = () => {
        reject(request.error);
      };
    });
  }
  return dbPromise;
};

const dbTransaction = async (storeName, mode) => {
  const db = await initIndexedDB();
  const tx = db.transaction(storeName, mode);
  return tx.objectStore(storeName);
};

const indexedDBGet = async (key) => {
  const store = await dbTransaction('files', 'readonly');
  return new Promise((resolve, reject) => {
    const req = store.get(key);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
};

const indexedDBGetAllKeys = async () => {
  const store = await dbTransaction('files', 'readonly');
  return new Promise((resolve, reject) => {
    const req = store.getAllKeys();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
};

const indexedDBPut = async (record) => {
  const store = await dbTransaction('files', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.put(record);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
};

const indexedDBDelete = async (key) => {
  const store = await dbTransaction('files', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.delete(key);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
};

const indexedDBListByPrefix = async (prefix) => {
  const keys = await indexedDBGetAllKeys();
  return keys.filter(k => k.startsWith(prefix));
};

const readEncryptedFile = async (fileHandleOrPath, isFileAPI = true) => {
  if (useIndexedDB && !isFileAPI) {
    const record = await indexedDBGet(fileHandleOrPath);
    if (!record) {
      const err = new Error('NotFoundError');
      err.name = 'NotFoundError';
      throw err;
    }
    const encryptedContent = record.content;
    const decryptedContent = decryptData(encryptedContent);
    return decryptedContent;
  } else {
    const file = await fileHandleOrPath.getFile();
    const encryptedContent = await file.text();
    const decryptedContent = decryptData(encryptedContent);
    return decryptedContent;
  }
};

const writeEncryptedFile = async (fileHandleOrPath, data, isFileAPI = true) => {
  const encryptedContent = encryptData(data);
  if (useIndexedDB && !isFileAPI) {
    const record = { path: fileHandleOrPath, content: encryptedContent };
    await indexedDBPut(record);
  } else {
    const writable = await fileHandleOrPath.createWritable();
    await writable.write(encryptedContent);
    await writable.close();
  }
};

const conversationFilePath = (conversationName, fileName) => `conversations/${conversationName}/${fileName}`;
const folderFilePath = (folderName, fileName) => `folders/${folderName}/${fileName}`;
const favoritesFilePath = () => `favorites.json`;

const readFile = async (filename, conversationName = null, folderName = null) => {
  if (!useIndexedDB) {
    return '';
  }

  let path;
  if (conversationName) {
    path = conversationFilePath(conversationName, filename);
  } else if (folderName) {
    path = folderFilePath(folderName, filename);
  } else if (filename === 'favorites.json') {
    path = favoritesFilePath();
  } else {
    path = filename;
  }

  try {
    const decryptedContent = await readEncryptedFile(path, false);
    return decryptedContent;
  } catch (err) {
    console.warn(`${filename} not found in IDB. Returning empty content.`);
    return '';
  }
};

const writeFile = async (filename, content, conversationName = null, folderName = null) => {
  if (!useIndexedDB) return;

  let path;
  if (conversationName) {
    path = conversationFilePath(conversationName, filename);
  } else if (folderName) {
    path = folderFilePath(folderName, filename);
  } else if (filename === 'favorites.json') {
    path = favoritesFilePath();
  } else {
    path = filename;
  }

  await writeEncryptedFile(path, content, false);
};

const ChatPage = () => {
  var { user } = useContext(AuthContext);

  if (user === null) {
    user = { id: "777777777", iat: 1733253711 };
  }

  const [prompt, setPrompt] = useState('');
  const [messages, setMessages] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const [isLimitReached, setIsLimitReached] = useState(false);
  const [currentClickCount, setCurrentClickCount] = useState(0);
  const [clickLimit, setClickLimit] = useState(0);

  const [hasDirectorySelected, setHasDirectorySelected] = useState(false);
  const [directoryHandle, setDirectoryHandle] = useState(null);
  const [conversationsHandle, setConversationsHandle] = useState(null);
  const [foldersHandle, setFoldersHandle] = useState(null);
  const [conversations, setConversations] = useState([]);
  const [currentConversation, setCurrentConversation] = useState(null);
  const [uploadedImages, setUploadedImages] = useState([]);
  const fileInputRef = useRef(null);
  const messagesEndRef = useRef(null);
  const iframeRef = useRef(null);
  const uploadFileInputRef = useRef(null);

  const [isCreateFolderModalOpen, setIsCreateFolderModalOpen] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');

  const [isRenameModalOpen, setIsRenameModalOpen] = useState(false);
  const [renameConversation, setRenameConversation] = useState(null);
  const [newConversationName, setNewConversationName] = useState('');

  const [folders, setFolders] = useState([]);
  const [expandedFolders, setExpandedFolders] = useState({});
  const [filesInFolders, setFilesInFolders] = useState({});

  const imagePathToDataURLRef = useRef(new Map());

  const [isLoadingImages, setIsLoadingImages] = useState(false);
  const [indexContent, setIndexContent] = useState(null);
  const [currentUploadFolder, setCurrentUploadFolder] = useState(null);

  const [isConversationsCollapsed, setIsConversationsCollapsed] = useState(false);
  const [displayedConversations, setDisplayedConversations] = useState(7);

  const [isFoldersCollapsed, setIsFoldersCollapsed] = useState(false);
  const [displayedFolders, setDisplayedFolders] = useState(7);

  const [favoriteConversations, setFavoriteConversations] = useState([]);
  const [isFavoriteAppsCollapsed, setIsFavoriteAppsCollapsed] = useState(false);

  const [openaiApiKey, setOpenaiApiKey] = useState(localStorage.getItem('openaiApiKey') || '');
  const [isKeyModalOpen, setIsKeyModalOpen] = useState(false);
  const [keyInput, setKeyInput] = useState('');
  const [hasApiKey, setHasApiKey] = useState(false);

  const [hasShownReviewModal, setHasShownReviewModal] = useState(() => {
    return JSON.parse(localStorage.getItem(`hasShownReviewModal_${user.id}`)) || false;
  });

  const [reviewModalShow, setreviewModalShow] = useState(false);
  const [helpModalShow, sethelpModalShow] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  const shareUrl = 'https://yobino.com';
  const title = 'Check out this awesome app!';
  const description = 'This app does amazing things. You should definitely try it out!';

  const handleOpenReview = () => setreviewModalShow(true);
  const handleCloseReview = () => setreviewModalShow(false);

  const handleOpenHelp = () => sethelpModalShow(true);
  const handleCloseHelp = () => sethelpModalShow(false);

  const conversationCountRef = useRef(0);

  useEffect(() => {
    conversationCountRef.current = conversations.length;
  }, [conversations.length]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    const saveConversation = async () => {
      if (currentConversation) {
        try {
          const originalMessages = messages.map(({ sender, content, timestamp }) => ({
            sender,
            content,
            timestamp,
          }));

          // Read old allowedUsers
          let allowedUsers = [user.id];
          let lastModified = Date.now(); // Default to now

          if (useIndexedDB) {
            const convoContent = await readFile('conversation.json', currentConversation.name);
            if (convoContent && convoContent.trim()) {
              try {
                const existingData = JSON.parse(convoContent);
                allowedUsers = existingData.allowedUsers || [user.id];
                lastModified = existingData.lastModified || Date.now(); // Read existing lastModified
              } catch {}
            }

            const conversationData = {
              allowedUsers,
              messages: originalMessages,
              lastModified: Date.now(), // Update lastModified to now
            };
            await writeFile('conversation.json', JSON.stringify(conversationData, null, 2), currentConversation.name);
          } else {
            const conversationFolderHandle = await conversationsHandle.getDirectoryHandle(currentConversation.name);
            const fileHandle = await conversationFolderHandle.getFileHandle('conversation.json', { create: true });
            try {
              const decryptedContent = await readEncryptedFile(fileHandle);
              if (decryptedContent && decryptedContent.trim()) {
                const existingData = JSON.parse(decryptedContent);
                allowedUsers = existingData.allowedUsers || [user.id];
                lastModified = existingData.lastModified || Date.now();
              }
            } catch (err) {
              console.warn('conversation.json does not exist or is malformed. Initializing allowedUsers.');
            }
            const conversationData = {
              allowedUsers,
              messages: originalMessages,
              lastModified: Date.now(), // Update lastModified to now
            };
            await writeEncryptedFile(fileHandle, JSON.stringify(conversationData, null, 2));
          }
          console.log(`Conversation "${currentConversation.name}" saved automatically.`);

          // Update the lastModified in the conversations state
          setConversations((prevConvos) =>
            prevConvos.map((convo) =>
              convo.name === currentConversation.name ? { ...convo, lastModified: Date.now() } : convo
            )
          );
        } catch (err) {
          console.error('Error auto-saving conversation:', err);
        }
      }
    };

    saveConversation();
  }, [messages, currentConversation, conversationsHandle, user.id]);

  const checkUserLimit = async () => {
    try {
      const response = await api.get('/user/userStatus');
      const { isSubscribed, currentRequestCount, requestLimit, isLimitReached: limitReachedBackend, currentClickCount: clickCountBackend, clickLimit: clickLimitBackend } = response.data;

      setIsLimitReached(limitReachedBackend);
      setCurrentClickCount(clickCountBackend);
      setClickLimit(clickLimitBackend);
    } catch (err) {
      console.error('Error checking user limit:', err);
    }
  };

  useEffect(() => {
    const fetchApiKeyStatus = async () => {
      if (user.id !== "777777777") {
        try {
          const response = await api.get('/user/apiKeyStatus');
          const { hasApiKey: backendHasApiKey } = response.data;
          setHasApiKey(backendHasApiKey);
        } catch (err) {
          console.error('Error fetching API key status:', err);
        }
      }
    };

    fetchApiKeyStatus();
  }, [user.id]);

  const loadFavorites = async (dirHandle, userId) => {
    if (useIndexedDB) {
      const content = await readFile('favorites.json');
      if (!content) {
        setFavoriteConversations([]);
        return;
      }
      const allFavorites = JSON.parse(content);
      if (typeof allFavorites !== 'object' || allFavorites === null) {
        setFavoriteConversations([]);
        return;
      }

      if (userId !== "777777777" && allFavorites["777777777"]) {
        const oldFavorites = Array.isArray(allFavorites["777777777"]) ? allFavorites["777777777"] : [];
        if (!Array.isArray(allFavorites[userId])) {
          allFavorites[userId] = [];
        }
        allFavorites[userId] = Array.from(new Set([...allFavorites[userId], ...oldFavorites]));
        delete allFavorites["777777777"];
        await writeFile('favorites.json', JSON.stringify(allFavorites, null, 2));
      }

      const userFavorites = Array.isArray(allFavorites[userId]) ? allFavorites[userId] : [];
      setFavoriteConversations(userFavorites);
      return;
    }

    try {
      const favoritesFileHandle = await dirHandle.getFileHandle('favorites.json');
      const decryptedContent = await readEncryptedFile(favoritesFileHandle);
      if (!decryptedContent.trim()) {
        setFavoriteConversations([]);
        return;
      }
      const allFavorites = JSON.parse(decryptedContent);

      if (typeof allFavorites !== 'object' || allFavorites === null) {
        setFavoriteConversations([]);
        return;
      }

      if (userId !== "777777777" && allFavorites["777777777"]) {
        const oldFavorites = Array.isArray(allFavorites["777777777"]) ? allFavorites["777777777"] : [];
        if (!Array.isArray(allFavorites[userId])) {
          allFavorites[userId] = [];
        }
        allFavorites[userId] = Array.from(new Set([...allFavorites[userId], ...oldFavorites]));
        delete allFavorites["777777777"];

        await writeEncryptedFile(favoritesFileHandle, JSON.stringify(allFavorites, null, 2));
      }

      const userFavorites = Array.isArray(allFavorites[userId]) ? allFavorites[userId] : [];
      setFavoriteConversations(userFavorites);
    } catch (err) {
      if (err.name === 'NotFoundError') {
        setFavoriteConversations([]);
      } else if (err.message === 'Failed to decrypt data.') {
        console.error('Failed to decrypt favorites.json.');
        alert('Failed to decrypt favorites.json.');
        setFavoriteConversations([]);
      } else {
        console.error('Error loading favorites:', err);
        alert('Failed to load favorites.');
        setFavoriteConversations([]);
      }
    }
  };

  const saveFavorites = async (dirHandle, userId, favorites) => {
    let allFavorites = {};
    if (useIndexedDB) {
      const content = await readFile('favorites.json');
      if (content) {
        try {
          allFavorites = JSON.parse(content);
          if (typeof allFavorites !== 'object' || allFavorites === null) {
            allFavorites = {};
          }
        } catch {
          allFavorites = {};
        }
      }
      allFavorites[userId] = favorites;
      await writeFile('favorites.json', JSON.stringify(allFavorites, null, 2));
      return;
    }

    if (!dirHandle) return;
    try {
      let favoritesFileHandle;
      try {
        favoritesFileHandle = await dirHandle.getFileHandle('favorites.json');
        const decryptedContent = await readEncryptedFile(favoritesFileHandle);
        if (decryptedContent && decryptedContent.trim()) {
          allFavorites = JSON.parse(decryptedContent);
          if (typeof allFavorites !== 'object' || allFavorites === null) {
            allFavorites = {};
          }
        } else {
          allFavorites = {};
        }
      } catch (err) {
        allFavorites = {};
      }

      allFavorites[userId] = favorites;
      favoritesFileHandle = await dirHandle.getFileHandle('favorites.json', { create: true });
      await writeEncryptedFile(favoritesFileHandle, JSON.stringify(allFavorites, null, 2));
    } catch (err) {
      console.error('Error saving favorites:', err);
      alert('Failed to save favorites.');
    }
  };

  const toggleFavoriteConversation = async (conversation) => {
    const isFavorite = favoriteConversations.includes(conversation.name);
    let updatedFavorites;

    if (isFavorite) {
      updatedFavorites = favoriteConversations.filter((favName) => favName !== conversation.name);
    } else {
      updatedFavorites = [...favoriteConversations, conversation.name];
    }

    setFavoriteConversations(updatedFavorites);

    if (useIndexedDB) {
      await saveFavorites(null, user.id, updatedFavorites);
    } else if (directoryHandle) {
      await saveFavorites(directoryHandle, user.id, updatedFavorites);
    }
  };

  const removeFavoriteConversation = async (conversationName) => {
    const updatedFavorites = favoriteConversations.filter((favName) => favName !== conversationName);
    setFavoriteConversations(updatedFavorites);

    if (useIndexedDB) {
      await saveFavorites(null, user.id, updatedFavorites);
    } else if (directoryHandle) {
      await saveFavorites(directoryHandle, user.id, updatedFavorites);
    }
  };

  const loadConversations = async (conversationsDirHandle) => {
    if (useIndexedDB) {
      const allKeys = await indexedDBListByPrefix('conversations/');
      const convoNames = new Set(allKeys.map(k => {
        const parts = k.split('/');
        return parts.length > 1 ? parts[1] : null;
      }).filter(Boolean));

      const convs = [];
      for (const convoName of convoNames) {
        const convoContent = await readFile('conversation.json', convoName);
        if (!convoContent || !convoContent.trim()) continue;
        try {
          const convoData = JSON.parse(convoContent);
          let shouldInclude = false;
          if (convoData.allowedUsers && convoData.allowedUsers.includes(user.id)) {
            shouldInclude = true;
          } else if (convoData.allowedUsers && convoData.allowedUsers.includes("777777777")) {
            convoData.allowedUsers = convoData.allowedUsers.map(uid => uid === "777777777" ? user.id : uid);
            await writeFile('conversation.json', JSON.stringify(convoData, null, 2), convoName);
            shouldInclude = true;
          }

          if (shouldInclude) {
            const lastModified = convoData.lastModified || Date.now(); // Read lastModified from data
            convs.push({
              name: convoName,
              folderHandle: null,
              lastModified,
            });
          }
        } catch {
          console.warn(`conversation.json malformed for ${convoName}. Skipping.`);
        }
      }

      convs.sort((a, b) => b.lastModified - a.lastModified); // Sort by lastModified descending
      setConversations(convs);
      setDisplayedConversations(7);
      return;
    }

    // File System
    try {
      const convs = [];
      for await (const entry of conversationsDirHandle.values()) {
        if (entry.kind === 'directory') {
          try {
            const convoFolderHandle = entry;
            const convoFileHandle = await convoFolderHandle.getFileHandle('conversation.json');
            const decryptedContent = await readEncryptedFile(convoFileHandle);
            if (!decryptedContent.trim()) continue;
            const convoData = JSON.parse(decryptedContent);

            let shouldInclude = false;

            if (convoData.allowedUsers && convoData.allowedUsers.includes(user.id)) {
              shouldInclude = true;
            } else if (convoData.allowedUsers && convoData.allowedUsers.includes("777777777")) {
              convoData.allowedUsers = convoData.allowedUsers.map(uid => uid === "777777777" ? user.id : uid);
              await writeEncryptedFile(convoFileHandle, JSON.stringify(convoData, null, 2));
              shouldInclude = true;
            }

            if (shouldInclude) {
              const convoFile = await convoFileHandle.getFile();
              const lastModified = convoFile.lastModified; 
              convs.push({
                name: entry.name,
                folderHandle: convoFolderHandle,
                lastModified,
              });
            }
          } catch (err) {
            console.warn(`conversation.json not found or malformed for ${entry.name}. Skipping.`);
          }
        }
      }
      convs.sort((a, b) => b.lastModified - a.lastModified); // Sort by lastModified descending
      setConversations(convs);
      setDisplayedConversations(7);
    } catch (err) {
      console.error('Error loading conversations:', err);
      alert('Failed to load conversations.');
    }
  };

  const loadUploadedImages = async (foldersDirHandle) => {
    if (useIndexedDB) {
      const imageKeys = await indexedDBListByPrefix('folders/images/');
      const images = [];
      for (const imgKey of imageKeys) {
        const record = await indexedDBGet(imgKey);
        if (!record) continue;
        const decrypted = decryptData(record.content);
        const relativePath = `/${imgKey.replace('folders/', '')}`;
        images.push({ name: imgKey.split('/').pop(), path: relativePath, url: decrypted });
        imagePathToDataURLRef.current.set(relativePath, decrypted);
      }
      return { images };
    }

    try {
      let imagesDirHandle;
      try {
        imagesDirHandle = await foldersDirHandle.getDirectoryHandle('images');
      } catch (err) {
        console.warn("'images' directory does not exist. Creating it.");
        imagesDirHandle = await foldersDirHandle.getDirectoryHandle('images', { create: true });
      }

      const imageFiles = [];
      for await (const entry of imagesDirHandle.values()) {
        if (entry.kind === 'file' && entry.name.match(/\.(jpg|jpeg|png|gif|bmp|webp)$/i)) {
          imageFiles.push(entry);
        }
      }

      const images = [];

      for (const fileHandle of imageFiles) {
        try {
          const file = await fileHandle.getFile();
          const dataURL = await readFileAsDataURL(file);
          const relativePath = `/images/${file.name}`;
          images.push({ name: file.name, path: relativePath, url: dataURL });
          imagePathToDataURLRef.current.set(relativePath, dataURL);
        } catch (err) {
          console.error(`Error reading image file ${fileHandle.name}:`, err);
        }
      }

      return { images };
    } catch (err) {
      console.error('Error loading uploaded images:', err);
      alert('Failed to load uploaded images.');
      return { images: [] };
    }
  };

  const loadFolders = async (foldersDirHandle) => {
    if (useIndexedDB) {
      const keys = await indexedDBListByPrefix('folders/');
      const folderNames = new Set(keys.map(k => k.split('/')[1]).filter(name => name && name !== 'images'));
      const folderEntries = [];
      for (const fname of folderNames) {
        const fContent = await readFile('folder.json', null, fname);
        let lastModified = 0;
        if (fContent && fContent.trim()) {
          try {
            const folderData = JSON.parse(fContent);
            lastModified = folderData.lastModified || 0;
          } catch {
            console.warn(`folder.json malformed for ${fname}`);
          }
        }
        folderEntries.push({
          name: fname,
          folderHandle: null,
          lastModified,
        });
      }
      folderEntries.sort((a, b) => b.lastModified - a.lastModified); // Sort by lastModified descending
      setFolders(folderEntries);
      setDisplayedFolders(7);
      return;
    }

    try {
      const folderEntries = [];
      for await (const entry of foldersDirHandle.values()) {
        if (entry.kind === 'directory') {
          try {
            const folderFileHandle = await entry.getFileHandle('folder.json');
            const decryptedContent = await readEncryptedFile(folderFileHandle);
            if (!decryptedContent.trim()) {
              folderEntries.push({
                name: entry.name,
                folderHandle: entry,
                lastModified: 0,
              });
              continue;
            }
            const folderData = JSON.parse(decryptedContent);
            const lastModified = folderData.lastModified || 0;

            folderEntries.push({
              name: entry.name,
              folderHandle: entry,
              lastModified,
            });
          } catch (err) {
            console.warn(`folder.json not found or malformed for ${entry.name}.`);
            folderEntries.push({
              name: entry.name,
              folderHandle: entry,
              lastModified: 0,
            });
          }
        }
      }
      folderEntries.sort((a, b) => b.lastModified - a.lastModified); // Sort by lastModified descending
      setFolders(folderEntries);
      setDisplayedFolders(7);
    } catch (err) {
      console.error('Error loading folders:', err);
      alert('Failed to load folders.');
    }
  };

  const getOrCreateDirectory = async (parentHandle, dirName) => {
    if (useIndexedDB) {
      return null;
    }

    try {
      const dirHandle = await parentHandle.getDirectoryHandle(dirName);
      return dirHandle;
    } catch (err) {
      const newDirHandle = await parentHandle.getDirectoryHandle(dirName, { create: true });
      return newDirHandle;
    }
  };

  const handleSelectDirectory = async () => {
    if (useIndexedDB) {
      await initIndexedDB();
      setHasDirectorySelected(true);

      await loadConversations(null);
      await loadFavorites(null, user.id);

      setIsLoadingImages(true);
      const { images } = await loadUploadedImages(null);
      setUploadedImages(images);
      setIsLoadingImages(false);

      await loadFolders(null);

      await checkUserLimit();
      return;
    }

    if (!window.showDirectoryPicker) {
      alert('File System Access API is not supported. Using IndexedDB fallback.');
      return;
    }

    try {
      const dirHandle = await window.showDirectoryPicker();
      setDirectoryHandle(dirHandle);
      setHasDirectorySelected(true);

      const conversationsDirHandle = await getOrCreateDirectory(dirHandle, 'conversations');
      const foldersDirHandle = await getOrCreateDirectory(dirHandle, 'folders');
      setConversationsHandle(conversationsDirHandle);
      setFoldersHandle(foldersDirHandle);

      await loadConversations(conversationsDirHandle);

      await loadFavorites(dirHandle, user.id);

      await getOrCreateDirectory(foldersDirHandle, 'images');

      setIsLoadingImages(true);
      const { images } = await loadUploadedImages(foldersDirHandle);
      setUploadedImages(images);
      setIsLoadingImages(false);

      await loadFolders(foldersDirHandle);

      await checkUserLimit();
    } catch (err) {
      console.error('Error selecting directory:', err);
      alert('Failed to select directory.');
    }
  };

  useEffect(() => {
    if (conversations.length >= 10 && !hasShownReviewModal) {
      setreviewModalShow(true);
      setHasShownReviewModal(true);
      localStorage.setItem(`hasShownReviewModal_${user.id}`, JSON.stringify(true));
    }
  }, [conversations.length, hasShownReviewModal, user.id]);

  const handleCreateConversation = async () => {
    if (!hasDirectorySelected) {
      alert('Please select a directory first.');
      return;
    }

    const convoName = window.prompt('Enter a name for the new conversation:', `Conversation ${conversations.length + 1}`);
    if (!convoName) {
      alert('Conversation name is required.');
      return;
    }

    const invalidChars = /[<>:"/\\|?*\x00-\x1F]/g;
    if (invalidChars.test(convoName)) {
      alert('Conversation name contains invalid characters.');
      return;
    }

    if (useIndexedDB) {
      const existing = await readFile('conversation.json', convoName);
      if (existing && existing.trim()) {
        alert('A conversation with this name already exists.');
        return;
      }

      const conversationData = {
        allowedUsers: [user.id],
        messages: [],
        lastModified: Date.now(), // Initialize lastModified
      };
      await writeFile('conversation.json', JSON.stringify(conversationData, null, 2), convoName);
      const newConversation = { name: convoName, folderHandle: null, lastModified: Date.now() };
      setConversations((prev) => [newConversation, ...prev]);
      setCurrentConversation(newConversation);
      setMessages([]);
      setIndexContent(null);
      setDisplayedConversations((prev) => prev + 1);
      alert(`Conversation "${convoName}" created successfully.`);

      await checkUserLimit();
      return;
    }

    if (!conversationsHandle) {
      alert('Please select a directory first.');
      return;
    }

    try {
      await conversationsHandle.getDirectoryHandle(convoName, { create: false });
      alert('A conversation with this name already exists.');
      return;
    } catch (err) {
      if (err.name !== 'NotFoundError') {
        console.error('Error checking conversation existence:', err);
        alert('Failed to create conversation.');
        return;
      }
    }

    try {
      const folderHandle = await conversationsHandle.getDirectoryHandle(convoName, { create: true });

      const conversationData = {
        allowedUsers: [user.id],
        messages: [],
        lastModified: Date.now(), // Initialize lastModified
      };

      const fileHandle = await folderHandle.getFileHandle('conversation.json', { create: true });
      await writeEncryptedFile(fileHandle, JSON.stringify(conversationData, null, 2));

      const newConversation = {
        name: convoName,
        folderHandle: folderHandle,
        lastModified: Date.now(),
      };
      setConversations((prev) => [newConversation, ...prev]);
      setCurrentConversation(newConversation);
      setMessages([]);
      setIndexContent(null);
      setDisplayedConversations((prev) => prev + 1);
      alert(`Conversation "${convoName}" created successfully.`);

      await checkUserLimit();
    } catch (err) {
      console.error('Error creating conversation:', err);
      alert('Failed to create conversation.');
    }
  };

  const openRenameConversationModal = (conversation) => {
    setRenameConversation(conversation);
    setNewConversationName(conversation.name);
    setIsRenameModalOpen(true);
  };

  const closeRenameConversationModal = () => {
    setIsRenameModalOpen(false);
    setRenameConversation(null);
    setNewConversationName('');
  };

  const handleRenameConversation = async () => {
    if (!newConversationName.trim()) {
      alert('Conversation name cannot be empty.');
      return;
    }

    const invalidChars = /[<>:"/\\|?*\x00-\x1F]/g;
    if (invalidChars.test(newConversationName)) {
      alert('Conversation name contains invalid characters.');
      return;
    }

    if (useIndexedDB) {
      const oldName = renameConversation.name;
      const newName = newConversationName.trim();
      const existing = await readFile('conversation.json', newName);
      if (existing && existing.trim()) {
        alert('A conversation with this name already exists.');
        return;
      }

      const keys = await indexedDBListByPrefix(`conversations/${oldName}/`);
      for (const key of keys) {
        const oldRecord = await indexedDBGet(key);
        const newKey = key.replace(`conversations/${oldName}/`, `conversations/${newName}/`);
        await indexedDBPut({ path: newKey, content: oldRecord.content });
      }

      for (const key of keys) {
        await indexedDBDelete(key);
      }

      if (favoriteConversations.includes(oldName)) {
        const updatedFavorites = favoriteConversations.map((fav) => (fav === oldName ? newName : fav));
        setFavoriteConversations(updatedFavorites);
        await saveFavorites(null, user.id, updatedFavorites);
      }

      setConversations((prevConvos) =>
        prevConvos.map((convo) =>
          convo.name === oldName ? { ...convo, name: newName, lastModified: Date.now() } : convo
        )
      );

      if (currentConversation && currentConversation.name === oldName) {
        setCurrentConversation({ ...currentConversation, name: newName });
      }

      alert(`Conversation renamed from "${oldName}" to "${newName}" successfully.`);
      closeRenameConversationModal();
      await checkUserLimit();
      return;
    }

    if (!conversationsHandle) {
      alert('Please select a directory first.');
      return;
    }
    try {
      await conversationsHandle.getDirectoryHandle(newConversationName, { create: false });
      alert('A conversation with this name already exists.');
      return;
    } catch (err) {
      if (err.name !== 'NotFoundError') {
        console.error('Error checking conversation existence:', err);
        alert('Failed to rename conversation.');
        return;
      }
    }

    try {
      const oldName = renameConversation.name;
      const newName = newConversationName.trim();

      const newFolderHandle = await conversationsHandle.getDirectoryHandle(newName, { create: true });

      const copyDirectoryRecursively = async (sourceHandle, destinationHandle) => {
        for await (const entry of sourceHandle.values()) {
          if (entry.kind === 'file') {
            const file = await entry.getFile();
            const newFileHandle = await destinationHandle.getFileHandle(entry.name, { create: true });
            const writable = await newFileHandle.createWritable();
            await writable.write(file);
            await writable.close();
          } else if (entry.kind === 'directory') {
            const newSubDirHandle = await destinationHandle.getDirectoryHandle(entry.name, { create: true });
            await copyDirectoryRecursively(entry, newSubDirHandle);
          }
        }
      };

      await copyDirectoryRecursively(renameConversation.folderHandle, newFolderHandle);

      await conversationsHandle.removeEntry(oldName, { recursive: true });

      setConversations((prevConvos) =>
        prevConvos.map((convo) =>
          convo.name === oldName ? { ...convo, name: newName, folderHandle: newFolderHandle, lastModified: Date.now() } : convo
        )
      );

      if (favoriteConversations.includes(oldName)) {
        const updatedFavorites = favoriteConversations.map((fav) => (fav === oldName ? newName : fav));
        setFavoriteConversations(updatedFavorites);
        if (directoryHandle) {
          await saveFavorites(directoryHandle, user.id, updatedFavorites);
        }
      }

      if (currentConversation && currentConversation.name === oldName) {
        setCurrentConversation({ ...currentConversation, name: newName, folderHandle: newFolderHandle });
      }

      alert(`Conversation renamed from "${oldName}" to "${newName}" successfully.`);
      closeRenameConversationModal();

      await checkUserLimit();
    } catch (err) {
      console.error('Error renaming conversation:', err);
      alert('Failed to rename conversation.');
    }
  };

  const handleDeleteConversation = async (conversation) => {
    if (!window.confirm(`Are you sure you want to delete the conversation "${conversation.name}"?`)) {
      return;
    }

    if (useIndexedDB) {
      const keys = await indexedDBListByPrefix(`conversations/${conversation.name}/`);
      for (const key of keys) {
        await indexedDBDelete(key);
      }

      setConversations((prevConvos) => prevConvos.filter((convo) => convo.name !== conversation.name));

      if (favoriteConversations.includes(conversation.name)) {
        const updatedFavorites = favoriteConversations.filter((fav) => fav !== conversation.name);
        setFavoriteConversations(updatedFavorites);
        await saveFavorites(null, user.id, updatedFavorites);
      }

      if (currentConversation && currentConversation.name === conversation.name) {
        setCurrentConversation(null);
        setMessages([]);
        setIndexContent(null);
      }

      alert(`Conversation "${conversation.name}" deleted successfully.`);
      await checkUserLimit();
      return;
    }

    try {
      await conversationsHandle.removeEntry(conversation.name, { recursive: true });
      setConversations((prevConvos) => prevConvos.filter((convo) => convo.name !== conversation.name));

      if (favoriteConversations.includes(conversation.name)) {
        const updatedFavorites = favoriteConversations.filter((fav) => fav !== conversation.name);
        setFavoriteConversations(updatedFavorites);
        if (directoryHandle) {
          await saveFavorites(directoryHandle, user.id, updatedFavorites);
        }
      }

      if (currentConversation && currentConversation.name === conversation.name) {
        setCurrentConversation(null);
        setMessages([]);
        setIndexContent(null);
      }

      alert(`Conversation "${conversation.name}" deleted successfully.`);
      await checkUserLimit();
    } catch (err) {
      console.error('Error deleting conversation:', err);
      alert('Failed to delete conversation.');
    }
  };

  const handleLoadConversation = async (conversation) => {
    try {
      let convoData;
      if (useIndexedDB) {
        const convoContent = await readFile('conversation.json', conversation.name);
        if (!convoContent || !convoContent.trim()) {
          alert('Conversation not found or malformed.');
          return;
        }
        convoData = JSON.parse(convoContent);
      } else {
        const conversationFolderHandle = conversation.folderHandle;
        const fileHandle = await conversationFolderHandle.getFileHandle('conversation.json');
        const decryptedContent = await readEncryptedFile(fileHandle);
        if (!decryptedContent.trim()) {
          alert('Conversation not found or malformed.');
          return;
        }
        convoData = JSON.parse(decryptedContent);
      }

      if (!convoData.allowedUsers || !convoData.allowedUsers.includes(user.id)) {
        alert('You are not authorized to access this conversation.');
        return;
      }

      const loadedMessages = convoData.messages;
      if (!Array.isArray(loadedMessages)) {
        throw new Error('Invalid conversation format.');
      }

      const mappedMessages = loadedMessages.map((msg) => {
        if (msg.sender === 'assistant') {
          const modifiedDisplayContent = msg.content;
          return { ...msg, displayContent: modifiedDisplayContent };
        }
        return { ...msg, displayContent: msg.content };
      });

      setIndexContent(null); // Reset index content before loading new conversation
      setMessages(mappedMessages);
      setCurrentConversation(conversation);
      setError(null);

      await getConversationIndexContent(conversation);
    } catch (err) {
      console.error('Error loading conversation:', err);
      alert('Failed to load conversation.');
      setIndexContent(null);
    }
  };

  const handleSelectConversation = async (conversation, index) => {
    if (isLimitReached && index >= 3) {
      return;
    }
    await handleLoadConversation(conversation);
  };

  const handleSend = async () => {
    if (!prompt.trim()) {
      setError('Please enter a valid prompt.');
      return;
    }

    if (!currentConversation) {
      setError('Please select or create a conversation first.');
      return;
    }

    if (
      (user.id === "777777777" && !openaiApiKey) ||
      (user.id !== "777777777" && !hasApiKey)
    ) {
      setIsKeyModalOpen(true);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const lastExchange = [];
      if (messages.length >= 2) {
        const lastUserMessage = messages[messages.length - 2];
        const lastAssistantMessage = messages[messages.length - 1];
        if (lastUserMessage.sender === 'user' && lastAssistantMessage.sender === 'assistant') {
          lastExchange.push(
            { ...lastUserMessage, content: lastUserMessage.content },
            { ...lastAssistantMessage, content: lastAssistantMessage.content }
          );
        }
      }

      const userMessageContent = prompt;
      const requestPayload = {
        prompt: userMessageContent,
        messages: lastExchange,
        conversationName: currentConversation.name,
      };

      if (user.id === "777777777") {
        requestPayload.k = openaiApiKey;
      }

      const response = await api.post('/request', requestPayload);

      const assistantCode = response.data.code;

      const assistantMessage = {
        sender: 'assistant',
        content: assistantCode,
        displayContent: assistantCode,
        timestamp: new Date().toISOString(),
      };
      const userMessage = {
        sender: 'user',
        content: userMessageContent,
        displayContent: userMessageContent,
        timestamp: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, userMessage, assistantMessage]);

      await saveAssistantCode(assistantCode);
      await getConversationIndexContent(currentConversation);

      await checkUserLimit();

      setPrompt('');
    } catch (err) {
      if (err.response) {
        const errorMsg = err.response.data.error || 'An error occurred. Please try again.';
        setError(errorMsg);
        if (errorMsg === 'Request limit reached. Upgrade your account.') {
          setIsLimitReached(true);
        }
      } else if (err.request) {
        setError('No response from server. Please try again later.');
      } else {
        setError('An unexpected error occurred.');
      }
    } finally {
      setLoading(false);
    }
  };

  const extractImagePaths = (htmlContent) => {
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlContent, 'text/html');
    const images = doc.querySelectorAll('img');
    const imagePaths = [];

    images.forEach((img) => {
      let src = img.getAttribute('src');
      if (src && !src.startsWith('data:') && !src.startsWith('http')) {
        src = decodeURIComponent(src);
        imagePaths.push(src);
      }
    });

    return imagePaths;
  };

  const saveAssistantCode = async (codeContent) => {
    if (!hasDirectorySelected) {
      alert('Please select a directory first.');
      return;
    }

    if (!currentConversation) {
      alert('Please select or create a conversation first.');
      return;
    }

    try {
      let modifiedCodeContent = codeContent;
      const imagePaths = extractImagePaths(codeContent);

      if (useIndexedDB) {
        for (const imagePath of imagePaths) {
          const record = await indexedDBGet(`folders${imagePath}`);
          if (record) {
            const dataURL = decryptData(record.content);
            const escapedImagePath = imagePath.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            const regex = new RegExp(escapedImagePath, 'g');
            modifiedCodeContent = modifiedCodeContent.replace(regex, dataURL);
          } else {
            console.error(`Image file ${imagePath} not found in IndexedDB.`);
          }
        }

        await writeFile('index.html', modifiedCodeContent, currentConversation.name);

        // Update lastModified after saving
        setConversations((prevConvos) =>
          prevConvos.map((convo) =>
            convo.name === currentConversation.name ? { ...convo, lastModified: Date.now() } : convo
          )
        );
        return;
      }

      if (foldersHandle) {
        const imagesDirHandle = await foldersHandle.getDirectoryHandle('images');
        for (const imagePath of imagePaths) {
          try {
            const imageFileName = decodeURIComponent(imagePath.split('/').pop());
            const imageFileHandle = await imagesDirHandle.getFileHandle(imageFileName);
            const imageFile = await imageFileHandle.getFile();
            const dataURL = await readFileAsDataURL(imageFile);
            const escapedImagePath = imagePath.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            const regex = new RegExp(escapedImagePath, 'g');
            modifiedCodeContent = modifiedCodeContent.replace(regex, dataURL);
          } catch (err) {
            console.error(`Image file ${imagePath} not found in 'folders/images' directory.`);
          }
        }
      }

      const conversationFolderHandle = await conversationsHandle.getDirectoryHandle(currentConversation.name, { create: true });
      const indexFileHandle = await conversationFolderHandle.getFileHandle('index.html', { create: true });
      await writeEncryptedFile(indexFileHandle, modifiedCodeContent);

      // Update lastModified after saving
      setConversations((prevConvos) =>
        prevConvos.map((convo) =>
          convo.name === currentConversation.name ? { ...convo, lastModified: Date.now() } : convo
        )
      );
    } catch (err) {
      console.error('Error saving code:', err);
      alert('Failed to save code.');
    }
  };

  const handleResetConversation = () => {
    if (window.confirm('Are you sure you want to reset the current conversation?')) {
      setMessages([]);
      setIndexContent(null);
      checkUserLimit();
    }
  };

  const handleUpgrade = () => {
    navigate('/subscribe');
    setIsLimitReached(false);
  };

  const openCreateFolderModal = () => {
    setNewFolderName('');
    setIsCreateFolderModalOpen(true);
  };

  const closeCreateFolderModal = () => {
    setIsCreateFolderModalOpen(false);
  };

  const handleCreateFolder = async () => {
    if (!hasDirectorySelected) {
      alert('Please select a directory first.');
      return;
    }

    if (!newFolderName.trim()) {
      alert('Folder name cannot be empty.');
      return;
    }

    const invalidChars = /[<>:"/\\|?*\x00-\x1F]/g;
    if (invalidChars.test(newFolderName)) {
      alert('Folder name contains invalid characters.');
      return;
    }

    if (newFolderName.toLowerCase() === 'images') {
      alert('A folder named "images" already exists and is reserved for image uploads.');
      return;
    }

    if (useIndexedDB) {
      const existingKeys = await indexedDBListByPrefix(`folders/${newFolderName}/`);
      if (existingKeys.length > 0) {
        alert('A folder with this name already exists.');
        return;
      }

      const folderMetadata = {
        name: newFolderName,
        createdAt: Date.now(),
        lastModified: Date.now(),
      };
      await writeFile('folder.json', JSON.stringify(folderMetadata, null, 2), null, newFolderName);

      const newFolder = { name: newFolderName, folderHandle: null, lastModified: folderMetadata.lastModified };
      setFolders((prev) => [newFolder, ...prev]);
      alert(`Folder "${newFolderName}" created successfully.`);
      closeCreateFolderModal();
      setDisplayedFolders((prev) => prev + 1);
      return;
    }

    if (!foldersHandle) {
      alert('Folders directory handle is missing.');
      return;
    }

    try {
      try {
        await foldersHandle.getDirectoryHandle(newFolderName);
        alert('A folder with this name already exists.');
        return;
      } catch (err) {}
  
      const newFolderHandle = await foldersHandle.getDirectoryHandle(newFolderName, { create: true });
      const folderMetadata = {
        name: newFolderName,
        createdAt: Date.now(),
        lastModified: Date.now(),
      };
      const metadataFileHandle = await newFolderHandle.getFileHandle('folder.json', { create: true });
      await writeEncryptedFile(metadataFileHandle, JSON.stringify(folderMetadata, null, 2));

      const newFolder = { name: newFolderName, folderHandle: newFolderHandle, lastModified: folderMetadata.lastModified };
      setFolders((prev) => [newFolder, ...prev]);
      alert(`Folder "${newFolderName}" created successfully.`);
      closeCreateFolderModal();
      setDisplayedFolders((prev) => prev + 1);
    } catch (err) {
      console.error('Error creating folder:', err);
      alert('Failed to create folder.');
    }
  };

  const toggleFolderExpansion = async (folderName) => {
    setExpandedFolders((prev) => ({
      ...prev,
      [folderName]: !prev[folderName],
    }));

    if (!expandedFolders[folderName] && !filesInFolders[folderName]) {
      if (useIndexedDB) {
        const keys = await indexedDBListByPrefix(`folders/${folderName}/`);
        const files = keys.map(k => k.split('/').pop()).filter(f => f !== 'folder.json');
        setFilesInFolders((prev) => ({
          ...prev,
          [folderName]: files,
        }));
        return;
      }

      try {
        const folderHandle = await foldersHandle.getDirectoryHandle(folderName);
        const files = [];
        for await (const entry of folderHandle.values()) {
          if (entry.kind === 'file') {
            files.push(entry.name);
          }
        }
        setFilesInFolders((prev) => ({
          ...prev,
          [folderName]: files,
        }));
      } catch (err) {
        console.error(`Error loading files for folder "${folderName}":`, err);
        alert(`Failed to load files for folder "${folderName}".`);
      }
    }
  };

  const handleSelectFile = (folderName, fileName) => {
    const relativePath = `/${folderName}/${fileName}`;
    insertAtCursor('"' + relativePath + '" ');
  };

  const insertAtCursor = (insertText) => {
    const textarea = document.getElementById('prompt-textarea');
    if (!textarea) return;

    const startPos = textarea.selectionStart;
    const endPos = textarea.selectionEnd;
    const before = prompt.substring(0, startPos);
    const after = prompt.substring(endPos, prompt.length);
    const newText = before + insertText + after;
    setPrompt(newText);

    setTimeout(() => {
      textarea.selectionStart = textarea.selectionEnd = startPos + insertText.length;
      textarea.focus();
    }, 0);
  };

  const handleTextareaKeyDown = (e) => {
    if (e.key === '/' && !e.ctrlKey && !e.altKey && !e.metaKey) {
      e.preventDefault();
    }
  };

  const getConversationIndexContent = async (conversation) => {
    if (!conversation) {
      setIndexContent(null);
      return;
    }

    if (useIndexedDB) {
      const idxContent = await readFile('index.html', conversation.name);
      if (idxContent && idxContent.trim()) {
        setIndexContent(idxContent);
      } else {
        setIndexContent(null);
      }
      return;
    }

    if (!conversationsHandle) {
      setIndexContent(null);
      return;
    }

    try {
      const conversationFolderHandle = await conversationsHandle.getDirectoryHandle(conversation.name);
      const indexFileHandle = await conversationFolderHandle.getFileHandle('index.html');
      const encryptedContent = await indexFileHandle.getFile().then(file => file.text());
      const decryptedContent = decryptData(encryptedContent);
      if (decryptedContent && decryptedContent.trim()) {
        setIndexContent(decryptedContent);
      } else {
        setIndexContent(null);
      }
    } catch (err) {
      console.error('Error getting index.html content:', err);
      setIndexContent(null);
    }
  };

  useEffect(() => {
    const handleMessage = async (event) => {
      if (iframeRef.current && event.source === iframeRef.current.contentWindow) {
        const { type, payload } = event.data;

        switch (type) {
          case 'READ_FILE':
            try {
              const data = await readFile(payload.filename, currentConversation?.name || null);
              event.source.postMessage({ type: 'FILE_CONTENT', payload: { filename: payload.filename, content: data } }, '*');
            } catch (err) {
              console.error(`Error reading file ${payload.filename}:`, err);
              event.source.postMessage({ type: 'ERROR', payload: `Failed to read file ${payload.filename}.` }, '*');
            }
            break;
          case 'WRITE_FILE':
            try {
              await writeFile(payload.filename, payload.content, currentConversation?.name || null);
              event.source.postMessage({ type: 'WRITE_SUCCESS', payload: { filename: payload.filename } }, '*');
            } catch (err) {
              console.error(`Error writing to file ${payload.filename}:`, err);
              event.source.postMessage({ type: 'ERROR', payload: `Failed to write file ${payload.filename}.` }, '*');
            }
            break;
          case 'iframe-click':
            handleClick();
            break;
          default:
            console.warn('Unknown message type:', type);
            break;
        }
      }
    };

    window.addEventListener('message', handleMessage);
    return () => {
      window.removeEventListener('message', handleMessage);
    };
  }, [currentConversation]);

  const lastAssistantMessage = messages.slice().reverse().find((msg) => msg.sender === 'assistant');

  const handlePerFolderFileUpload = async (event) => {
    const files = event.target.files;
    if (files.length === 0 || !currentUploadFolder) return;

    if (useIndexedDB) {
      for (const file of files) {
        let fileName = file.name;
        const keys = await indexedDBListByPrefix(`folders/${currentUploadFolder}/`);
        while (keys.includes(`folders/${currentUploadFolder}/${fileName}`)) {
          const nameParts = fileName.split('.');
          const extension = nameParts.pop();
          const baseName = nameParts.join('.');
          fileName = `${baseName}(1).${extension}`;
        }
        const dataURL = await readFileAsDataURL(file);
        await writeFile(fileName, dataURL, null, currentUploadFolder);
        if (currentUploadFolder === 'images') {
          imagePathToDataURLRef.current.set(`/images/${fileName}`, dataURL);
        }
      }

      if (currentUploadFolder === 'images') {
        setIsLoadingImages(true);
        const { images } = await loadUploadedImages(null);
        setUploadedImages(images);
        setIsLoadingImages(false);
      }

      const keys = await indexedDBListByPrefix(`folders/${currentUploadFolder}/`);
      const filesList = keys.map(k => k.split('/').pop()).filter(f => f !== 'folder.json');
      setFilesInFolders((prev) => ({
        ...prev,
        [currentUploadFolder]: filesList,
      }));

      alert('Files uploaded successfully!');
      setCurrentUploadFolder(null);
      if (uploadFileInputRef.current) {
        uploadFileInputRef.current.value = '';
      }
      return;
    }

    try {
      const folderHandle = await foldersHandle.getDirectoryHandle(currentUploadFolder, { create: true });
      const newUploadedFiles = [];

      for (const file of files) {
        let fileName = file.name;
        let counter = 1;
        while (true) {
          try {
            await folderHandle.getFileHandle(fileName);
            const nameParts = fileName.split('.');
            const extension = nameParts.pop();
            const baseName = nameParts.join('.');
            fileName = `${baseName}(${counter}).${extension}`;
            counter += 1;
          } catch (err) {
            break;
          }
        }

        const newFileHandle = await folderHandle.getFileHandle(fileName, { create: true });
        const writable = await newFileHandle.createWritable();
        await writable.write(file);
        await writable.close();

        const dataURL = await readFileAsDataURL(file);
        const relativePath = `/${currentUploadFolder}/${fileName}`;
        newUploadedFiles.push({ name: fileName, path: relativePath, url: dataURL });
        imagePathToDataURLRef.current.set(relativePath, dataURL);
      }

      setUploadedImages((prev) => [...prev, ...newUploadedFiles]);
      setFilesInFolders((prev) => ({
        ...prev,
        [currentUploadFolder]: [...(prev[currentUploadFolder] || []), ...newUploadedFiles.map(file => file.name)],
      }));

      alert('Files uploaded successfully!');
    } catch (err) {
      console.error('Error uploading files:', err);
      alert('Failed to upload files.');
    } finally {
      setCurrentUploadFolder(null);
      if (uploadFileInputRef.current) {
        uploadFileInputRef.current.value = '';
      }
    }
  };

  const toggleConversationsCollapse = () => {
    setIsConversationsCollapsed(!isConversationsCollapsed);
  };

  const toggleFoldersCollapse = () => {
    setIsFoldersCollapsed(!isFoldersCollapsed);
  };

  const toggleFavoriteAppsCollapse = () => {
    setIsFavoriteAppsCollapsed(!isFavoriteAppsCollapsed);
  };

  const [isSendingClicks, setIsSendingClicks] = useState(false);
  const isSendingClicksRef = useRef(false);

  useEffect(() => {
    isSendingClicksRef.current = isSendingClicks;
  }, [isSendingClicks]);

  useEffect(() => {
    const sendSourceToBackend = async (source) => {
      try {
        await api.post('/visit', { source: JSON.stringify(source), userId: user.id });
      } catch (error) {
        console.error('Error sending source to backend:', error);
      }
    };

    const getUTMParams = () => {
      const params = new URLSearchParams(location.search);
      const utm_source = params.get('utm_source');
      const utm_medium = params.get('utm_medium');
      const utm_campaign = params.get('utm_campaign');
      return { utm_source, utm_medium, utm_campaign };
    };

    const determineSource = () => {
      const { utm_source, utm_medium, utm_campaign } = getUTMParams();
      if (utm_source) {
        return { utm_source, utm_medium, utm_campaign };
      } else if (document.referrer) {
        try {
          const referrerUrl = new URL(document.referrer);
          return {
            URL: referrerUrl.toString(),
            hash: referrerUrl.hash,
            host: referrerUrl.host,
            hostname: referrerUrl.hostname,
            href: referrerUrl.href,
            origin: referrerUrl.origin,
            password: referrerUrl.password,
            pathname: referrerUrl.pathname,
            port: referrerUrl.port,
            protocol: referrerUrl.protocol,
            search: referrerUrl.search,
            searchParams: Object.fromEntries(referrerUrl.searchParams.entries()),
            username: referrerUrl.username,
          };
        } catch (err) {
          console.error('Error parsing referrer URL:', err);
          return null;
        }
      }
      return null;
    };

    const sourceSentFlag = `sourceSent_${user.id}`;
    if (!localStorage.getItem(sourceSentFlag)) {
      const source = determineSource();
      if (source) {
        sendSourceToBackend(source).then(() => {
          localStorage.setItem(sourceSentFlag, 'true');
        });
      }
    }
  }, [location.search, user.id]);

  const sendClickCountToBackend = async (userId, clickCount, conversationCount, favoriteCount) => {
    try {
      await api.post('/clicks', { userId, clickCount, conversationCount, favoriteCount });
    } catch (error) {
      console.error('Failed to send click count and conversation count:', error);
      throw error;
    }
  };

  const handleClick = () => {
    if (!hasDirectorySelected) return;

    const CLICK_THRESHOLD = 20;
    const userId = user.id;

    const currentCount = parseInt(localStorage.getItem('clickCount_' + userId)) || 0;
    const newCount = currentCount + 1;
    localStorage.setItem('clickCount_' + userId, newCount);

    if (newCount >= CLICK_THRESHOLD && !isSendingClicksRef.current) {
      setIsSendingClicks(true);
      isSendingClicksRef.current = true;

      const currentConversationCount = conversationCountRef.current;
      const currentFavoriteCount = favoriteConversations.length;

      sendClickCountToBackend(userId, CLICK_THRESHOLD, currentConversationCount, currentFavoriteCount)
        .then(() => {
          const latestCount = parseInt(localStorage.getItem('clickCount_' + userId)) || 0;
          const updatedCount = latestCount - CLICK_THRESHOLD;
          localStorage.setItem('clickCount_' + userId, updatedCount < 0 ? 0 : updatedCount);
          checkUserLimit();
        })
        .catch((error) => {
          console.error('Error sending click count to backend:', error);
        })
        .finally(() => {
          setIsSendingClicks(false);
          isSendingClicksRef.current = false;
        });
    }
  };

  useEffect(() => {
    if (hasDirectorySelected) {
      const handlePageClick = (event) => {
        const iframeElement = iframeRef.current;
        if (iframeElement && iframeElement.contains(event.target)) {
          return;
        }
        handleClick();
      };

      document.addEventListener('click', handlePageClick);

      const handleMessageFromIframe = (event) => {
        if (event.data && event.data.type === 'iframe-click') {
          // already handled in the message event
        }
      };

      window.addEventListener('message', handleMessageFromIframe);

      return () => {
        document.removeEventListener('click', handlePageClick);
        window.removeEventListener('message', handleMessageFromIframe);
      };
    }
  }, [hasDirectorySelected, user.id, favoriteConversations.length]);

  const openKeyModal = () => {
    if (user.id === "777777777") {
      setKeyInput(openaiApiKey);
    } else {
      setKeyInput('');
    }
    setIsKeyModalOpen(true);
  };

  const closeKeyModal = () => {
    setIsKeyModalOpen(false);
    setKeyInput('');
  };

  const handleSaveKey = async () => {
    if (!keyInput.trim()) {
      alert('API key cannot be empty.');
      return;
    }

    if (user.id === "777777777") {
      setOpenaiApiKey(keyInput.trim());
      localStorage.setItem('openaiApiKey', keyInput.trim());
      setIsKeyModalOpen(false);
      setKeyInput('');
      alert('OpenAI API key saved successfully.');
    } else {
      try {
        await api.post('/user/apiKey', { apiKey: keyInput.trim() });
        setHasApiKey(true);
        setIsKeyModalOpen(false);
        setKeyInput('');
        alert('OpenAI API key saved successfully.');
      } catch (err) {
        console.error('Error saving API key:', err);
        alert('Failed to save API key.');
      }
    }
  };

  const importSingleFileInputRef = useRef(null);

  const handleExportSingleConversation = async (conversation) => {
    if (!conversation) {
      alert('No conversation selected.');
      return;
    }

    try {
      const gatherFiles = async (convoName) => {
        if (useIndexedDB) {
          const keys = await indexedDBListByPrefix(`conversations/${convoName}/`);
          const files = [];
          for (const key of keys) {
            const record = await indexedDBGet(key);
            const content = record.content;
            if (key.endsWith('conversation.json')) {
              const decrypted = decryptData(content);
              const convoData = JSON.parse(decrypted);
              convoData.allowedUsers = ["777777777"];
              const newContent = JSON.stringify(convoData, null, 2);
              const reEncrypted = encryptData(newContent);
              files.push({ type: 'file', name: 'conversation.json', content: reEncrypted });
            } else {
              const name = key.split('/').pop();
              files.push({ type: 'file', name, content });
            }
          }
          return {
            type: 'directory',
            name: conversation.name,
            entries: files
          };
        } else {
          const recursivelyReadDirectory = async (dirHandle) => {
            const data = { type: 'directory', name: dirHandle.name, entries: [] };
            for await (const entry of dirHandle.values()) {
              if (entry.kind === 'file') {
                const file = await entry.getFile();
                const fileContent = await file.text();
                if (entry.name === 'conversation.json') {
                  const decrypted = decryptData(fileContent);
                  const convoData = JSON.parse(decrypted);
                  convoData.allowedUsers = ["777777777"];
                  const newContent = JSON.stringify(convoData, null, 2);
                  const encrypted = encryptData(newContent);
                  data.entries.push({ type: 'file', name: entry.name, content: encrypted });
                } else {
                  data.entries.push({ type: 'file', name: entry.name, content: fileContent });
                }
              } else if (entry.kind === 'directory') {
                const subDirData = await recursivelyReadDirectory(entry);
                data.entries.push(subDirData);
              }
            }
            return data;
          };

          return await recursivelyReadDirectory(conversation.folderHandle);
        }
      };

      const conversationDirData = await gatherFiles(conversation.name);
      const jsonString = JSON.stringify(conversationDirData);
      const packageEncrypted = encryptData(jsonString);
      const blob = new Blob([packageEncrypted], { type: 'application/octet-stream' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${conversation.name}_conversation.bin`;
      a.click();
      URL.revokeObjectURL(url);

      alert(`Exported conversation "${conversation.name}" successfully!`);
    } catch (err) {
      console.error('Error exporting single conversation:', err);
      alert('Failed to export single conversation.');
    }
  };

  const importSingleConversation = async (data) => {
    if (useIndexedDB) {
      const processDir = async (directory, prefix) => {
        for (const entry of directory.entries) {
          if (entry.type === 'file') {
            const path = `${prefix}/${entry.name}`;
            await indexedDBPut({ path, content: entry.content });
          } else if (entry.type === 'directory') {
            await processDir(entry, `${prefix}/${entry.name}`);
          }
        }
      };

      await processDir(data, `conversations/${data.name}`);
      return;
    } else {
      const recursivelyCreateDirectory = async (parentHandle, data) => {
        if (data.type === 'directory') {
          const dirHandle = await parentHandle.getDirectoryHandle(data.name, { create: true });
          for (const entry of data.entries) {
            await recursivelyCreateDirectory(dirHandle, entry);
          }
        } else if (data.type === 'file') {
          const fileHandle = await parentHandle.getFileHandle(data.name, { create: true });
          const writable = await fileHandle.createWritable();
          await writable.write(data.content);
          await writable.close();
        }
      };
      await recursivelyCreateDirectory(conversationsHandle, data);
    }
  };

  const getUniqueConversationName = async (baseName) => {
    let uniqueName = baseName;
    const convoNames = conversations.map(c => c.name);
    if (convoNames.includes(uniqueName)) {
      let counter = 2;
      while (convoNames.includes(`${baseName}(${counter})`)) {
        counter++;
      }
      uniqueName = `${baseName}(${counter})`;
    }
    return uniqueName;
  };

  const handleImportSingleConversation = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    if (!hasDirectorySelected) {
      alert('Please select a directory first.');
      if (importSingleFileInputRef.current) {
        importSingleFileInputRef.current.value = '';
      }
      return;
    }

    try {
      const fileContent = await file.text();
      const decrypted = decryptData(fileContent);
      const data = JSON.parse(decrypted);

      const uniqueName = await getUniqueConversationName(data.name);
      data.name = uniqueName;

      await importSingleConversation(data);

      alert(`Imported conversation successfully as "${data.name}"!`);
      await loadConversations(useIndexedDB ? null : conversationsHandle);
    } catch (err) {
      console.error('Error importing single conversation:', err);
      alert('Failed to import single conversation.');
    } finally {
      if (importSingleFileInputRef.current) {
        importSingleFileInputRef.current.value = '';
      }
    }
  };

  return (
    <div className="chat-page">
      {isLimitReached && (
        <div className="limit-reached-bar">
          <span>You reached limits to continue using all features.</span>
          <button onClick={handleUpgrade} className="upgrade-account-btn">
            Upgrade Account
          </button>
        </div>
      )}

      <div className="usage-info">
        <p>Click Count: {currentClickCount} / {clickLimit}</p>
      </div>

      <div className="sidebar">
        <div className="openai-key-section">
          {user.id === "777777777" ? (
            openaiApiKey ? (
              <button className="key-present" onClick={openKeyModal}>OpenAI Key</button>
            ) : (
              <button className="add-key" onClick={openKeyModal}>Add OpenAI Key</button>
            )
          ) : (
            hasApiKey ? (
              <button className="key-present" onClick={openKeyModal}>OpenAI Key</button>
            ) : (
              <button className="add-key" onClick={openKeyModal}>Add OpenAI Key</button>
            )
          )}
        </div>

        <div className="sidebar-section conversations-section">
          <button variant="primary" onClick={handleOpenReview} className="btn review-btn">Write a Review</button>
          <ReviewModal show={reviewModalShow} handleClose={handleCloseReview} />

          <button variant="primary" onClick={handleOpenHelp} className="btn help-btn">Help</button>
          <HelpModal show={helpModalShow} handleClose={handleCloseHelp} />

          <button onClick={() => setIsShareModalOpen(true)} className="share-button btn">
            Share This App
          </button>
          <ShareModal
            isOpen={isShareModalOpen}
            onRequestClose={() => setIsShareModalOpen(false)}
            shareUrl={shareUrl}
            title={title}
            description={description}
          />

          <button onClick={handleSelectDirectory} className="btn" disabled={isLimitReached}>Select Directory</button>
          <button onClick={handleCreateConversation} className="btn" disabled={isLimitReached}>New Conversation</button>

          <button
            onClick={() => {
              if (importSingleFileInputRef.current) {
                importSingleFileInputRef.current.click();
              }
            }}
            className="btn"
            disabled={!hasDirectorySelected || isLimitReached}
          >
            Import Single Conversation
          </button>
          <input
            type="file"
            ref={importSingleFileInputRef}
            style={{ display: 'none' }}
            onChange={handleImportSingleConversation}
            disabled={isLimitReached}
          />

          <div
            className="conversations-header"
            onClick={toggleConversationsCollapse}
            style={{ cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '10px', marginBottom: '5px' }}
          >
            <h2>Conversations</h2>
            <button className="collapse-btn" style={{ background: 'none', border: 'none', fontSize: '1.2em' }}>
              {isConversationsCollapsed ? '+' : '-'}
            </button>
          </div>

          {!isConversationsCollapsed && (
            <>
              {conversations.length > 0 ? (
                <>
                  <ul className="conversation-list">
                    {conversations.slice(0, displayedConversations).map((convo, index) => (
                      <li
                        key={index}
                        className={`conversation-item ${
                          currentConversation && currentConversation.name === convo.name ? 'active' : ''
                        } ${isLimitReached && index >= 3 ? 'disabled-conversation' : ''}`}
                        onClick={() => handleSelectConversation(convo, index)}
                        style={isLimitReached && index >= 3 ? { pointerEvents: 'none', opacity: 0.5 } : {}}
                      >
                        <span>{convo.name}</span>
                        <div className="conversation-actions">
                          {!isLimitReached && (
                            <>
                              <button
                                className="save-favorite-btn"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  toggleFavoriteConversation(convo);
                                }}
                                title={favoriteConversations.includes(convo.name) ? 'Remove from Favorites' : 'Save to Favorites'}
                              >
                                {favoriteConversations.includes(convo.name) ? '★' : '☆'}
                              </button>
                              <button
                                className="rename-conversation-btn"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  openRenameConversationModal(convo);
                                }}
                                title="Rename Conversation"
                              >
                                ✏️
                              </button>
                              <button
                                className="delete-conversation-btn"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeleteConversation(convo);
                                }}
                                title="Delete Conversation"
                              >
                                🗑️
                              </button>
                              <button
                                className="export-conversation-btn"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleExportSingleConversation(convo);
                                }}
                                title="Export This Conversation"
                              >
                                ⬇️
                              </button>
                            </>
                          )}
                        </div>
                      </li>
                    ))}
                  </ul>
                  {displayedConversations < conversations.length && (
                    <button onClick={() => setDisplayedConversations((prev) => prev + 7)} className="btn load-more-btn" style={{ marginTop: '5px' }}>
                      Load More
                    </button>
                  )}
                </>
              ) : (
                <p>No conversations available.</p>
              )}
            </>
          )}
        </div>

        <div className="sidebar-section favorite-apps-section">
          <div
            className="favorite-apps-header"
            onClick={toggleFavoriteAppsCollapse}
            style={{ cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '10px', marginBottom: '5px' }}
          >
            <h2>Favorite Apps</h2>
            <button className="collapse-btn" style={{ background: 'none', border: 'none', fontSize: '1.2em' }}>
              {isFavoriteAppsCollapsed ? '+' : '-'}
            </button>
          </div>

          {!isFavoriteAppsCollapsed && (
            <>
              {favoriteConversations.length > 0 ? (
                <ul className="favorite-apps-list">
                  {favoriteConversations
                    .map((favName) => conversations.find(c => c.name === favName))
                    .filter(convo => convo !== undefined)
                    .map((convo, index) => (
                      <li
                        key={index}
                        className={`favorite-conversation-item ${
                          currentConversation && currentConversation.name === convo.name ? 'active' : ''
                        }`}
                        onClick={() => handleSelectConversation(convo, conversations.indexOf(convo))}
                        style={isLimitReached && conversations.indexOf(convo) >= 3 ? { pointerEvents: 'none', opacity: 0.5 } : {}}
                      >
                        {convo.name}
                        {!isLimitReached && (
                          <button
                            className="remove-favorite-btn"
                            onClick={(e) => {
                              e.stopPropagation();
                              removeFavoriteConversation(convo.name);
                            }}
                            title="Remove from Favorites"
                          >
                            ✖️
                          </button>
                        )}
                      </li>
                    ))}
                </ul>
              ) : (
                <p>No favorite apps.</p>
              )}
            </>
          )}
        </div>

        <div className="sidebar-section folders-section">
          <button onClick={openCreateFolderModal} className="btn" disabled={isLimitReached}>
            Create New Folder
          </button>

          <div
            className="folders-header"
            onClick={toggleFoldersCollapse}
            style={{ cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '10px', marginBottom: '5px' }}
          >
            <h2>Folders</h2>
            <button className="collapse-btn" style={{ background: 'none', border: 'none', fontSize: '1.2em' }}>
              {isFoldersCollapsed ? '+' : '-'}
            </button>
          </div>

          {!isFoldersCollapsed && (
            <>
              {folders.length > 0 ? (
                <>
                  <ul className="folder-list">
                    {folders.slice(0, displayedFolders).map((folder, index) => (
                      <li key={index} className="folder-item">
                        <div className="folder-header" onClick={() => toggleFolderExpansion(folder.name)}>
                          <span className="folder-name">
                            {folder.name.toLowerCase() === 'images' ? `${folder.name} 📷` : folder.name}
                          </span>
                          <span className="folder-toggle">{expandedFolders[folder.name] ? '-' : '+'}</span>
                        </div>
                        {expandedFolders[folder.name] && (
                          <div className="folder-actions">
                            <button
                              onClick={() => {
                                setCurrentUploadFolder(folder.name);
                                if (uploadFileInputRef.current) {
                                  uploadFileInputRef.current.click();
                                }
                              }}
                              className="btn upload-btn"
                              disabled={isLimitReached}
                            >
                              Upload Files
                            </button>
                            <ul className="file-list">
                              {filesInFolders[folder.name] ? (
                                filesInFolders[folder.name].length > 0 ? (
                                  filesInFolders[folder.name].map((file, idx) => (
                                    <li key={idx} className="file-item">
                                      <button onClick={() => handleSelectFile(folder.name, file)} className="btn file-btn">
                                        {file}
                                      </button>
                                    </li>
                                  ))
                                ) : (
                                  <li className="no-files">No files in this folder.</li>
                                )
                              ) : (
                                <li className="loading-files">Loading files...</li>
                              )}
                            </ul>
                          </div>
                        )}
                      </li>
                    ))}
                  </ul>
                  {displayedFolders < folders.length && (
                    <button
                      onClick={() => setDisplayedFolders((prev) => prev + 7)}
                      className="btn load-more-btn"
                      style={{ marginTop: '5px' }}
                    >
                      Load More
                    </button>
                  )}
                </>
              ) : (
                <p>No folders available.</p>
              )}
            </>
          )}
        </div>
      </div>

      <div className="main-chat">
        <h1>Chat Interface</h1>

        {isLoadingImages && (
          <div className="loading-indicator">
            <p>Loading images...</p>
          </div>
        )}

        <div className="messages-container">
          {messages.map((msg, index) => (
            <div key={index} className={`message ${msg.sender}`}>
              {msg.sender === 'user' ? (
                <div className="message-content">{msg.content}</div>
              ) : null}
            </div>
          ))}

          {lastAssistantMessage && indexContent && (
            <div className={`message assistant`}>
              <iframe
                ref={iframeRef}
                title={`Rendered Output`}
                className="rendered-iframe"
                srcDoc={indexContent}
                sandbox="allow-scripts allow-same-origin allow-downloads allow-popups allow-modals allow-forms"
              ></iframe>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        <div className="input-area">
          <textarea
            id="prompt-textarea"
            placeholder="Enter your request (e.g., I want a landing page)... Type '/' to insert a file path."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={handleTextareaKeyDown}
            disabled={!currentConversation || loading || isLimitReached}
          />
          <div className="buttons">
            <button
              onClick={handleSend}
              disabled={loading || !currentConversation || isLimitReached}
              className="btn send-btn"
            >
              {loading ? 'Generating...' : 'Send'}
            </button>
            {currentConversation && (
              <button onClick={handleResetConversation} disabled={loading || isLimitReached} className="btn reset-btn">
                Reset
              </button>
            )}
          </div>
        </div>

        <Modal
          isOpen={isCreateFolderModalOpen}
          onRequestClose={closeCreateFolderModal}
          contentLabel="Create New Folder"
          className="image-modal"
          overlayClassName="image-modal-overlay"
          ariaHideApp={false}
        >
          <div className="modal-content">
            <h2>Create New Folder</h2>
            <input
              type="text"
              placeholder="Enter folder name"
              value={newFolderName}
              onChange={(e) => setNewFolderName(e.target.value)}
              className="folder-input"
              disabled={isLimitReached}
            />
            <div className="modal-buttons">
              <button onClick={handleCreateFolder} className="btn create-folder-btn" disabled={isLimitReached}>
                Create
              </button>
              <button onClick={closeCreateFolderModal} className="btn close-modal-btn">
                Cancel
              </button>
            </div>
          </div>
        </Modal>

        <Modal
          isOpen={isRenameModalOpen}
          onRequestClose={closeRenameConversationModal}
          contentLabel="Rename Conversation"
          className="image-modal"
          overlayClassName="image-modal-overlay"
          ariaHideApp={false}
        >
          <div className="modal-content">
            <h2>Rename Conversation</h2>
            <input
              type="text"
              placeholder="Enter new conversation name"
              value={newConversationName}
              onChange={(e) => setNewConversationName(e.target.value)}
              className="folder-input"
              disabled={isLimitReached}
            />
            <div className="modal-buttons">
              <button onClick={handleRenameConversation} className="btn rename-conversation-btn" disabled={isLimitReached}>
                Rename
              </button>
              <button onClick={closeRenameConversationModal} className="btn close-modal-btn">
                Cancel
              </button>
            </div>
          </div>
        </Modal>

        <Modal
          isOpen={isKeyModalOpen}
          onRequestClose={closeKeyModal}
          contentLabel="Add OpenAI API Key"
          className="key-modal"
          overlayClassName="key-modal-overlay"
          ariaHideApp={false}
        >
          <div className="modal-content">
            <h2>{user.id === "777777777" ? (openaiApiKey ? 'Update OpenAI API Key' : 'Add OpenAI API Key') : (hasApiKey ? 'Update OpenAI API Key' : 'Add OpenAI API Key')}</h2>
            <input
              type="text"
              placeholder="Enter your OpenAI API key"
              value={keyInput}
              onChange={(e) => setKeyInput(e.target.value)}
              className="key-input"
            />
            <div className="modal-buttons">
              <button onClick={handleSaveKey} className="btn save-key-btn">
                Save
              </button>
              <button onClick={closeKeyModal} className="btn close-modal-btn">
                Cancel
              </button>
            </div>
          </div>
        </Modal>

        <input
          type="file"
          multiple
          ref={uploadFileInputRef}
          style={{ display: 'none' }}
          onChange={handlePerFolderFileUpload}
          disabled={isLimitReached}
        />

        {error && (
          <div className="error-message">
            <p>{error}</p>
            {error === 'Request limit reached. Upgrade your account.' && (
              <button onClick={handleUpgrade} className="btn upgrade-btn">
                Upgrade Account
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatPage;
