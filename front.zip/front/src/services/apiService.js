// src/services/apiService.js
import axios from 'axios';

var API_URL = 'http://localhost:4000/api/v1';
// API_URL = 'https://a99a-105-77-67-179.ngrok-free.app/api/v1';

const api = axios.create({
  baseURL: API_URL,
});

export default api;
