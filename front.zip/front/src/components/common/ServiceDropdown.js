// src/components/common/ServiceDropdown.js

import React, { useRef, useEffect } from 'react';
import './ServiceDropdown.css'; // Ensure this path is correct
import { FaCheckCircle } from "react-icons/fa";
import { MdOutlineKeyboardDoubleArrowDown } from "react-icons/md";
import { SiGooglegemini } from "react-icons/si";
import { SiAnthropic } from "react-icons/si";
import { SiOpenai } from "react-icons/si";
import { FaM } from "react-icons/fa6";

const MIcon = ({ size = 24, color = 'currentColor', ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 100 100"
    fill={color}
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <text
      x="50%"
      y="50%"
      textAnchor="middle"
      dominantBaseline="central"
      fontSize="80"
      fontFamily="Arial, Helvetica, sans-serif"
    >
      M
    </text>
  </svg>
);



const ServiceIcon={"OpenAI":<SiOpenai />,"Claude":<SiAnthropic />,"Gemini":<SiGooglegemini />,"Mistralai":<FaM />}


const ServiceDropdown = ({
  supportedServices,
  apiKeyStatus,
  serviceKeyMap,
  selectedService,
  setSelectedService,
  onAddOrUpdate,
  isLimitReached,
  isOpen, // Controlled by parent
  setIsOpen, // Function to control from parent
}) => {

  
  const dropdownRef = useRef(null);

  // Close dropdown if user clicks outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [setIsOpen]);

  const handleToggleDropdown = () => {
    // Check if there's only one service and no API key added
    if (
      supportedServices.length === 1 &&
      !apiKeyStatus[serviceKeyMap[supportedServices[0]]]
    ) {
      // Directly trigger the popup to add the API key
      onAddOrUpdate(supportedServices[0]);
    } else {
      // Toggle the dropdown as usual
      if (!isLimitReached) {
        setIsOpen((prev) => !prev);
      }
    }
  };

  // Closes the dropdown, sets the selected service
  const handleSelectService = (service) => {
    setSelectedService(service);
    setIsOpen(false);
  };

  // Select the service but DO NOT close the dropdown
  // (used by the checkbox so it won't close)
  const handleCheckboxChange = (e, service) => {
    e.stopPropagation(); // Prevent row click
    setSelectedService(service);
    // Do NOT close the dropdown here
  };

  return (
    <div className="service-dropdown" ref={dropdownRef}>
      <div
        className="service-dropdown-header"
        style={{
          backgroundColor: apiKeyStatus[serviceKeyMap[selectedService]] ? '#beffbe' : '#ff7f7f',
          borderColor: apiKeyStatus[serviceKeyMap[selectedService]] ? '#beffbe' : '#c10d0d',
          color: apiKeyStatus[serviceKeyMap[selectedService]] ? '#003f01' : '#3f0000'
        }}
        onClick={handleToggleDropdown}
      >
        <span>
          {apiKeyStatus[serviceKeyMap[selectedService]]
            ? (selectedService ? "Api Key : " + selectedService : 'Select a service')
            : 'Add Api Key : '+ selectedService
          }
        </span>

        <span className="dropdown-arrow">
          {apiKeyStatus[serviceKeyMap[selectedService]] ? <FaCheckCircle /> : ''}  
          <MdOutlineKeyboardDoubleArrowDown />
        </span>
      </div>

      {isOpen && (
        <div className="service-dropdown-menu">
          {supportedServices.map((service) => {
            const hasKey = apiKeyStatus[serviceKeyMap[service]];
            return (
              <div
                key={service}
                className="service-dropdown-item"
                // Now clicking anywhere (except the checkbox) does BOTH:
                // 1) selects the service & closes the dropdown
                // 2) calls onAddOrUpdate (like clicking Add/Update button)
                onClick={() => {
                  handleSelectService(service);
                  // onAddOrUpdate(service);
                }}
              >
                <div className='div-label-checkbox'>
                <input
                  type="checkbox"
                  checked={selectedService === service}
                  onChange={(e) => handleCheckboxChange(e, service)}
                  onClick={(e) => e.stopPropagation()} 
                />
                <span className='service-icon'>
                {ServiceIcon[service]}
                </span>
                <span className="service-label">
                  {service}
                  <span className="service-status">
                    {hasKey ? <FaCheckCircle /> : ''}
                  </span>
                </span>
                </div>
                

                <button
                  className="add-update-btn"
                  onClick={(e) => {
                    e.stopPropagation(); 
                    onAddOrUpdate(service);
                  }}
                  disabled={isLimitReached}
                >
                  {hasKey ? 'Edit Key' : 'Add Key'}
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default ServiceDropdown;
