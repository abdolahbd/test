const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const SubscriptionPageVisit = sequelize.define('SubscriptionPageVisit', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: true, // Or false if you require a user to be logged in
  },
  ip: { // New IP field added
    type: DataTypes.STRING(4550), // Supports IPv6
    // allowNull: false,
  } ,
  subscription_status: { 
    type: DataTypes.STRING(4550)
  } 
}, {
  tableName: 'SubscriptionPageVisit',
  timestamps: true, // will add createdAt and updatedAt fields
});

module.exports = SubscriptionPageVisit;
