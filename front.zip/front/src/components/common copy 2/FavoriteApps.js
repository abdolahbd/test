import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { IoIosArrowDropdown, IoIosArrowDropup } from "react-icons/io";
import './FavoriteApps.css'; // Ensure you import the CSS

const FavoriteApps = ({
  favoriteConversations,
  conversations,
  currentConversation,
  isLimitReached,
  removeFavoriteConversation,
  handleSelectConversation,
}) => {
  const [isFavoriteAppsCollapsed, setIsFavoriteAppsCollapsed] = useState(false);

  const toggleFavoriteAppsCollapse = () => {
    setIsFavoriteAppsCollapsed(!isFavoriteAppsCollapsed);
  };

  return (
    <div className="sidebar-section favorite-apps-section">
      <div className="favorite-apps-header" onClick={toggleFavoriteAppsCollapse}>
        <h2 className='section-collapse'>
          <span>✨ Favorite Apps</span>
          <span className='section-collapse-icon'>
            {isFavoriteAppsCollapsed ? <IoIosArrowDropdown /> : <IoIosArrowDropup />}
          </span>
        </h2>
      </div>

      {/* Smooth expand/collapse for the entire favorite apps list */}
      <div className={`favorite-apps-container ${isFavoriteAppsCollapsed ? '' : 'open'}`}>
        {favoriteConversations.length > 0 ? (
          <ul className="favorite-apps-list">
            {favoriteConversations
              .map((favId) => conversations.find((c) => c.id === favId))
              .filter((convo) => convo !== undefined)
              .map((convo, index) => {
                const convoIndex = conversations.findIndex(c => c.id === convo.id);
                return (
                  <li
                    key={convo.id}
                    className={`favorite-conversation-item ${currentConversation && currentConversation.id === convo.id ? 'active' : ''}`}
                    onClick={() => handleSelectConversation(convo, convoIndex)}
                    style={
                      isLimitReached && convoIndex >= 3
                        ? { pointerEvents: 'none', opacity: 0.5 }
                        : {}
                    }
                  >
                    <span className="conversation-name" title={convo.name}>
                      {convo.name}
                    </span>
                    {!isLimitReached && (
                      <button
                        className="remove-favorite-btn"
                        onClick={(e) => {
                          e.stopPropagation();
                          removeFavoriteConversation(convo.id);
                        }}
                        title="Remove from Favorites"
                      >
                        🗑️
                      </button>
                    )}
                  </li>
                );
              })}
          </ul>
        ) : (
          <p className="no-favorites-message">No favorite apps.</p>
        )}
      </div>
    </div>
  );
};

FavoriteApps.propTypes = {
  favoriteConversations: PropTypes.arrayOf(PropTypes.string).isRequired,
  conversations: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    lastModified: PropTypes.number,
  })).isRequired,
  currentConversation: PropTypes.shape({
    id: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    lastModified: PropTypes.number,
  }),
  isLimitReached: PropTypes.bool.isRequired,
  removeFavoriteConversation: PropTypes.func.isRequired,
  handleSelectConversation: PropTypes.func.isRequired,
};

export default FavoriteApps;
