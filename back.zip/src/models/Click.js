// models/Click.js

const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./User'); // Import User model

const Click = sequelize.define('Click', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  user_id: { // Ensure this field exists
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'users', // Adjust if your User table has a different name
      key: 'id',
    },
    onDelete: 'CASCADE',
  },
  clickCount: { 
    type: DataTypes.INTEGER, 
    allowNull: false,
    defaultValue: 0 
  },
  conversationCount: { 
    type: DataTypes.INTEGER, 
    allowNull: false,
    defaultValue: 0 
  },
  favoriteCount: { 
    type: DataTypes.INTEGER, 
    allowNull: false,
    defaultValue: 0 
  },
  isLimitReached: { 
    type: DataTypes.TEXT
  } ,
  ip: { // New IP field added
    type: DataTypes.STRING(4500), // Supports IPv6
    // allowNull: false,
  } ,
  timestamp: { 
    type: DataTypes.DATE, 
    allowNull: false, 
    defaultValue: DataTypes.NOW 
  },
}, {
  tableName: 'clicks',
  timestamps: false, // Disable Sequelize's automatic timestamps
});

// Define association: Click belongs to User
Click.belongsTo(User, { foreignKey: 'user_id' });
User.hasMany(Click, { foreignKey: 'user_id' });

module.exports = Click;
