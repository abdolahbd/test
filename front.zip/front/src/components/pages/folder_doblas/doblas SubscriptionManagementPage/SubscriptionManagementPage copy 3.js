import React, { useEffect, useState, useContext } from 'react';
import api from '../../services/apiService';
import { useNavigate } from 'react-router-dom';
import { loadStripe } from '@stripe/stripe-js';
import './SubscriptionManagementPage.css';
import { AuthContext } from '../../contexts/AuthContext';
import { FaTools, FaLightbulb, FaExchangeAlt, FaFolderOpen, FaStar } from 'react-icons/fa';

const stripePromise = loadStripe(process.env.REACT_APP_STRIPE);

const SubscriptionManagementPage = () => {
  const [subscription, setSubscription] = useState(null);
  const [hasRecorded, setHasRecorded] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadingSubscriptionAndCancel, setLoadingSubscriptionAndCancel] = useState(false);
  const [error, setError] = useState(null);

  const { user } = useContext(AuthContext);
  const [invoices, setInvoices] = useState([]);

  const navigate = useNavigate();

  useEffect(() => {
    const fetchInvoices = async () => {
      try {
        const response = await api.get('/user/invoices'); 
        setInvoices(response.data);
      } catch (error) {
        console.error('Error fetching invoices:', error);
      } finally {
        setLoading(false);
      }
    };

    if (user) {
      fetchInvoices();
    }
  }, [user]);

  useEffect(() => {
    const fetchSubscription = async () => {
      try {
        const response = await api.get('/subscription');
        setSubscription(response.data.subscription);
      } catch (err) {
        if (err.response && err.response.status === 404) {
          setSubscription(null);
        } else {
          console.error('Error fetching subscription:', err);
          setError('Failed to load subscription data.');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchSubscription();
  }, []);

  useEffect(() => {
    const recordVisit = async () => {
      try {
        if (!hasRecorded) {
          await api.post('/subscription/record-subscription-page-visit');
          setHasRecorded(true);
        }
      } catch (err) {
        console.error('Error recording subscription page visit:', err);
      }
    };

    recordVisit();
  }, [hasRecorded]);

  const handleCancelSubscription = async () => {
    if (window.confirm('Are you sure you want to cancel your subscription?')) {
      const reason = window.prompt('Please enter your reason for cancellation:', '');
      if (reason !== null) {
        try {
          setLoadingSubscriptionAndCancel(true);
          await api.post('/subscription/cancel', { reason });
          setLoadingSubscriptionAndCancel(false);
          alert('Your subscription has been scheduled for cancellation.');
          const updatedSubscription = await api.get('/subscription');
          setSubscription(updatedSubscription.data.subscription);
        } catch (err) {
          console.error('Error cancelling subscription:', err);
          alert('Failed to cancel subscription. Please try again.');
        }
      }
    }
  };

  const handleSubscribe = async () => {
    try {
      setLoadingSubscriptionAndCancel(true);
      const response = await api.post('/payment/create-checkout-session');
      setLoadingSubscriptionAndCancel(false);

      const { sessionId } = response.data;
      const stripe = await stripePromise;
      await stripe.redirectToCheckout({ sessionId });
    } catch (err) {
      console.error('Error during subscription:', err);
      alert('Failed to initiate subscription process. Please try again.');
    }
  };

  if (loading) {
    return (
      <div className="subscription-management-container">
        <div className="loading-subscription-cancel">
          Loading...
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="subscription-management-container">
        <p>Error: {error}</p>
      </div>
    );
  }

  return (
    <div className="subscription-management-container">
      {subscription ? (
        <div>
          <h1>Manage Your Subscription</h1>
          {loadingSubscriptionAndCancel && (
            <div className="loading-subscription-cancel">
              Loading...
            </div>
          )}
          {subscription.status === 'active' && subscription.cancelAtPeriodEnd && subscription.endDate ? (
            <div>
              <p>
                Your subscription is scheduled to be canceled on{' '}
                {new Date(subscription.endDate).toLocaleDateString('en-GB')}.
              </p>
              <p>You can continue to use our services until then.</p>
            </div>
          ) : subscription.status === 'active' ? (
            <div>
              <p>Status: Active</p>
              <button className="cancel-button" onClick={handleCancelSubscription}>
                Cancel Subscription
              </button>
            </div>
          ) : subscription.status === 'canceled' ? (
            <div>
              <h1>Upgrade Your Account</h1>
              <button onClick={handleSubscribe}>Subscribe Now</button>
            </div>
          ) : (
            <div>
              <p>Status: {subscription.status === 'incomplete' ? 'Active' : subscription.status}</p>
              {subscription.status !== 'canceled' && (
                <button className="cancel-button" onClick={handleCancelSubscription}>
                  Cancel Subscription
                </button>
              )}
            </div>
          )}
        </div>
      ) : (
        <div>
          <h1>Upgrade Your Account</h1>
          {/* Pro Plan Section */}
          <div className="pro-plan">
            <div className="pro-plan-header">
              <h2>Pro Plan</h2>
              <div className="pro-plan-price">               
                <span className="price-amount"><span className="dollar-sign">$</span>24</span>
                <span className="per-month">per month</span>
              </div>
            </div>
            <ul className="pro-plan-features">
              <li>
                <FaTools className="feature-icon" />
                Unlimited tools creation
              </li>
              <li>
                <FaLightbulb className="feature-icon" />
                Unlimited prompts
              </li>
              <li>
                <FaExchangeAlt className="feature-icon" />
                Unlimited exports/imports
              </li>
              <li>
                <FaFolderOpen className="feature-icon" />
                Unlimited folders/files
              </li>
              <li>
                <FaStar className="feature-icon" />
                Access to all future features
              </li>
            </ul>
            <button onClick={handleSubscribe} className="subscribe-button">Subscribe Now</button>
          </div>
          {loadingSubscriptionAndCancel && (
            <div className="loading-subscription-cancel">
              Loading...
            </div>
          )}
        </div>
      )}

      <div className="payment-history-page">
        <h2>Payment History</h2>
        {invoices.length === 0 ? (
          <p>No invoices found.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Invoice Date</th>
                <th>Amount Paid</th>
                <th>Status</th>
                <th>PDF</th>
              </tr>
            </thead>
            <tbody>
              {invoices.map((invoice) => (
                <tr key={invoice.id}>
                  <td data-label="Invoice Date">{new Date(invoice.invoiceDate).toLocaleDateString('en-GB')}</td>
                  <td data-label="Amount Paid">${invoice.amountPaid.toFixed(2)}</td>
                  <td data-label="Status">{invoice.status}</td>
                  <td data-label="PDF">
                    {invoice.pdfUrl ? (
                      <a href={invoice.pdfUrl} target="_blank" rel="noopener noreferrer">
                        Download PDF
                      </a>
                    ) : (
                      'No PDF available'
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default SubscriptionManagementPage;
