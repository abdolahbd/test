// models/Review.js

const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./User'); // Ensure the User model exists

const Review = sequelize.define('Review', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  user_id: { // Foreign key to User
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'users', // Adjust if your User table has a different name
      key: 'id',
    },
    onDelete: 'CASCADE',
  },
  name: { // User's name
    type: DataTypes.STRING,
    allowNull: true,
  },
  stars: { // Star rating (1-5)
    type: DataTypes.INTEGER,
    allowNull: false,
    validate: {
      min: 1,
      max: 5,
    },
  },
  text: { // Review text
    type: DataTypes.TEXT,
    allowNull: true,
  },
  timestamp: { // When the review was created
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW,
  },
}, {
  tableName: 'reviews',
  timestamps: false, // Disable Sequelize's automatic timestamps
});

// Define association: Review belongs to User
Review.belongsTo(User, { foreignKey: 'user_id' });
User.hasMany(Review, { foreignKey: 'user_id' });

module.exports = Review;
