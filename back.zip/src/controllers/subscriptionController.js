// src/controllers/subscriptionController.js

const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const Subscription = require('../models/Subscription');
const Cancel = require('../models/Cancel');
const User = require('../models/User');
const SubscriptionPageVisit = require('../models/SubscriptionPageVisit');
const { Op } = require('sequelize');
const geoip = require('geoip-lite');



const getClientIP  = (req) => {
  // Extract the IP address
  const forwarded = req.headers['x-forwarded-for'];
  let ip;

  if (forwarded) {
    // 'x-forwarded-for' may return multiple IP addresses in the format: "client IP, proxy 1 IP, proxy 2 IP"
    const forwardedIps = forwarded.split(',').map(ip => ip.trim());
    ip = forwardedIps[0];
  } else {
    ip = req.connection.remoteAddress || req.socket.remoteAddress || req.ip;
  }

  // Handle IPv6 addresses that are IPv4 mapped (e.g., ::ffff:127.0.0.1)
  const cleanIp = ip.startsWith('::ffff:') ? ip.substring(7) : ip;

  // Lookup the geolocation data
  const geo = geoip.lookup(cleanIp);

  // Extract the country code or set to 'Unknown' if not found
  const country = geo ? geo.country : 'Unknown';

  return JSON.stringify({ ip: cleanIp, country });
};


exports.getSubscription = async (req, res) => {
  try {
    const userId = req.user.id;

    // Fetch the active or incomplete subscription, if any
    let subscription = await Subscription.findOne({
      where: {
        user_id:userId,
        status: { [Op.in]: ['active', 'incomplete'] },
      },
      order: [['createdAt', 'DESC']],
    });

    if (!subscription) {
      // If no active or incomplete subscription, fetch the latest subscription (e.g., canceled)
      subscription = await Subscription.findOne({
        where: { user_id:userId },
        order: [['createdAt', 'DESC']],
      });
    }

    // Instead of returning 404, return subscription as null
    return res.status(200).json({ subscription });
  } catch (err) {
    console.error('Error fetching subscription:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
};



exports.cancelSubscription = async (req, res) => {
  try {
    const userId = req.user.id;
    console.log(req.body.reason);
    

    // Fetch the latest active subscription
    const subscription = await Subscription.findOne({
      where: {
        user_id:userId,
        status: { [Op.in]: ['active','incomplete'] },
      },
      order: [['createdAt', 'DESC']],
    });

    if (!subscription) {
      return res.status(404).json({ error: 'Active subscription not found' });
    }

    // Retrieve the Stripe subscription ID
    const stripeSubscriptionId = subscription.stripeSubscriptionId;

    // Cancel the subscription at period end
    const canceledSubscription = await stripe.subscriptions.update(
      stripeSubscriptionId,
      { cancel_at_period_end: true }
    );

    // Update the subscription status in your database
    subscription.status = canceledSubscription.status;
    subscription.cancelAtPeriodEnd = canceledSubscription.cancel_at_period_end;
    await subscription.save();

    const reason=req.body.reason;
 // Record the cancellation action
 await Cancel.create({
  user_id: userId,
  canceledAt: new Date(), // Optional: you can omit this if default is set
  reason
});

    res.json({ message: 'Subscription has been scheduled for cancellation.' });
  } catch (err) {
    console.error('Error cancelling subscription:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
};

exports.resubscribe = async (req, res) => {
  try {
    const userId = req.user.id;

    // Fetch the latest active or incomplete subscription
    const subscription = await Subscription.findOne({
      where: {
        userId,
        status: { [Op.in]: ['active', 'incomplete'] },
      },
      order: [['createdAt', 'DESC']],
    });

    if (!subscription) {
      return res.status(404).json({ error: 'Subscription not found' });
    }

    // Reactivate the subscription
    const reactivatedSubscription = await stripe.subscriptions.update(
      subscription.stripeSubscriptionId,
      { cancel_at_period_end: false }
    );

    // Update the subscription status in your database
    subscription.status = reactivatedSubscription.status;
    subscription.cancelAtPeriodEnd = reactivatedSubscription.cancel_at_period_end;
    await subscription.save();

    res.json({ message: 'Subscription reactivated successfully.' });
  } catch (err) {
    console.error('Error reactivating subscription:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
};


exports.recordSubscriptionPageVisit = async (req, res) => {
  try {
    const userId = req.user ? req.user.id : null;
    const ip = getClientIP(req);
   const subscription = await Subscription.findOne({
          where: { 
            user_id:userId,
          },
          order: [['createdAt', 'DESC']],
        });


       const subscription_status= subscription != null 
        ? subscription.status + 
          (subscription.status === 'active' && subscription.cancelAtPeriodEnd ? ' and cancel At Period End' : '') 
        : 'free'

    console.log('*********subscription*************');
    console.log(subscription);
    console.log(subscription_status);
     console.log('*********subscription*************');

    
    await SubscriptionPageVisit.create({ user_id:userId,ip,subscription_status});
    res.status(200).json({ message: 'Subscription page visit recorded.' });
  } catch (err) {
    console.error('Error in recordSubscriptionPageVisit:', err);
    res.status(500).json({ error: 'Failed to record subscription page visit.' });
  }
};