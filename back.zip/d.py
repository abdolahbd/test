import os

# Define the directory structure for both backend and frontend
structure = {
    "backend": [
        "src/controllers/",
        "src/models/",
        "src/routes/",
        "src/services/",
        "src/middleware/",
        "src/utils/",
        "src/config/",
        "src/validations/",
        "src/app.js",
        "src/server.js",
        ".env",
        "package.json"
    ],
    "frontend": [
        "src/components/common/",
        "src/components/layout/",
        "src/components/pages/",
        "src/hooks/",
        "src/contexts/",
        "src/services/",
        "src/utils/",
        "src/assets/",
        "src/routes/",
        "src/App.js",
        "src/index.js",
        "package.json"
    ]
}

# Function to create the structure
def create_structure(base_path, structure):
    for folder, files in structure.items():
        folder_path = os.path.join(base_path, folder)
        os.makedirs(folder_path, exist_ok=True)
        for file in files:
            file_path = os.path.join(base_path, folder, file)
            if file.endswith("/"):
                os.makedirs(file_path, exist_ok=True)
            else:
                with open(file_path, 'w') as f:
                    if folder == "backend":
                        if file == "package.json":
                            f.write(
                                """{
  "name": "backend",
  "version": "1.0.0",
  "main": "src/server.js",
  "scripts": {
    "start": "node src/server.js",
    "dev": "nodemon src/server.js"
  },
  "dependencies": {},
  "devDependencies": {}
}"""
                            )
                        elif file == ".env":
                            f.write("# Environment variables for the backend\n")
                        elif file == "src/app.js":
                            f.write(
                                """const express = require('express');
const app = express();

// Middleware
app.use(express.json());

// Routes
// app.use('/api', require('./routes'));

// Export app
module.exports = app;"""
                            )
                        elif file == "src/server.js":
                            f.write(
                                """const app = require('./app');
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});"""
                            )
                    elif folder == "frontend":
                        if file == "package.json":
                            f.write(
                                """{
  "name": "frontend",
  "version": "1.0.0",
  "main": "src/index.js",
  "scripts": {
    "start": "react-scripts start",
    "build": "react-scripts build",
    "test": "react-scripts test",
    "eject": "react-scripts eject"
  },
  "dependencies": {},
  "devDependencies": {}
}"""
                            )
                        elif file == "src/App.js":
                            f.write(
                                """import React from 'react';

function App() {
  return (
    <div className="App">
      <h1>Welcome to the Frontend</h1>
    </div>
  );
}

export default App;"""
                            )
                        elif file == "src/index.js":
                            f.write(
                                """import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);"""
                            )

# Generate the structure
base_path = os.getcwd()
create_structure(base_path, structure)

print(f"Backend and Frontend structures created at {base_path}")
