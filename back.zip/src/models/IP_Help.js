// src/models/IP_Help.js

const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const IP_Help = sequelize.define('IP_Help', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  ipAddress: { 
    type: DataTypes.STRING,
    allowNull: false,
  },
  text: { // JSON string representing an array of help messages
    type: DataTypes.TEXT,
    allowNull: false,
  },
  timestamp: { 
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW,
  },
}, {
  tableName: 'ip_helps',
  timestamps: false, 
});

module.exports = IP_Help;
