// testSubscription.js
const Subscription = require('./src/models/Subscription');
const User = require('./src/models/User');

(async () => {
  try {
    // Find a user to test with
    const user = await User.findOne();
    if (!user) {
      console.error('No user found in the database.');
      return;
    }

    console.log('User found:', user.email);

    // Create a new subscription
    const subscription = await Subscription.create({
      userId: user.id,
      status: 'active',
      startDate: new Date(),
      stripeSubscriptionId: 'test_subscription_id',
    });

    console.log('Subscription created:', subscription);
  } catch (err) {
    console.error('Error creating subscription:', err);
  }
})();
