// src/models/Checkout.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Checkout = sequelize.define('Checkout', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  checkoutAt: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW,
  },
  ip: { // New IP field added
    type: DataTypes.STRING(45), // Supports IPv6
    // allowNull: false,
  } 
}, {
  tableName: 'Checkouts',
  timestamps: false // or true if you want createdAt/updatedAt
});

module.exports = Checkout;
