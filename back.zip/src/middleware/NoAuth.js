// src/middleware/auth.js
const jwt = require('jsonwebtoken');
require('dotenv').config();

const Noauth = (req, res, next) => {
 
  try {
    
    next();
  } catch (err) {
    res.status(400).send('Invalid token.');
  }
};

module.exports = Noauth;
