// src/models/Subscription.js

const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Subscription = sequelize.define('Subscription', {
  id: { 
    type: DataTypes.INTEGER, 
    autoIncrement: true, 
    primaryKey: true 
  },
  user_id: { 
    type: DataTypes.INTEGER, 
    allowNull: false 
  },
  stripeSubscriptionId: { 
    type: DataTypes.STRING(191), 
    allowNull: false, 
    unique: true 
  },
  status: { 
    type: DataTypes.STRING, 
    allowNull: false, 
    defaultValue: 'inactive' 
  },
  startDate: { 
    type: DataTypes.DATE, 
    allowNull: true 
  },
  endDate: { 
    type: DataTypes.DATE, 
    allowNull: true 
  },
  cancelAtPeriodEnd: { 
    type: DataTypes.BOOLEAN, 
    allowNull: false, 
    defaultValue: false 
  },
});

Subscription.associate = (models) => {
  Subscription.belongsTo(models.User, { foreignKey: 'user_id' });
};

module.exports = Subscription;
