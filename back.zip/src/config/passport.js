// src/config/passport.js
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const User = require('../models/User');
require('dotenv').config();

passport.use(
  new GoogleStrategy(
    {
      clientID: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
      callbackURL: '/api/v1/auth/google/callback',
    },
    async (accessToken, refreshToken, profile, done) => {
      try {
        // This is line 17 where the error occurs
        let user = await User.findOne({ where: { googleId: profile.id } });

        if (user) {
          return done(null, user);
        }

// console.log('-*-*-*-*-*-*-*-*-*-*-*');
// console.log(profile)
// console.log('-*-*-*-*-*-*-*-*-*-*-*');



        // Create new user if not found
        user = await User.create({
          email: profile.emails[0].value,
          name: profile.displayName+' ('+profile.name.familyName+' '+profile.name.givenName+')',
          googleId: profile.id,
          apiKey: `{}`,
        });

        done(null, user);
      } catch (err) {
        done(err, null);
      }
    }
  )
);

// Serialize and deserialize user instances
passport.serializeUser((user, done) => {
  done(null, user.id);
});

passport.deserializeUser(async (id, done) => {
  try {
    const user = await User.findByPk(id);
    done(null, user);
  } catch (err) {
    done(err, null);
  }
});

module.exports = passport;
