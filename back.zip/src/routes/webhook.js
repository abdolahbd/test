// src/routes/webhook.js
const express = require('express');
const router = express.Router();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const User = require('../models/User');
const Subscription = require('../models/Subscription');
const Invoice = require('../models/Invoice');
const { Op } = require('sequelize');
require('dotenv').config();

router.post(
  '/',
  express.raw({ type: 'application/json' }),
  async (req, res) => {
    const sig = req.headers['stripe-signature'];
    const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;

    let event;

    try {
      event = stripe.webhooks.constructEvent(req.body, sig, endpointSecret);
      console.log('✅ Webhook event received:', event.type);
    } catch (err) {
      console.error('❌ Webhook signature verification failed.', err.message);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    try {
      switch (event.type) {
        case 'invoice.payment_succeeded':
        case 'invoice.payment_failed':
          console.log(`Processing ${event.type} event`);
          const invoice = event.data.object;
          await handleInvoicePaymentEvent(invoice, event.type);
          break;

        case 'customer.subscription.created':
        case 'customer.subscription.updated':
        case 'customer.subscription.deleted':
          console.log(`Processing ${event.type} event`);
          const subscription = event.data.object;
          await handleSubscriptionEvent(subscription);
          break;

        default:
          console.log(`Unhandled event type ${event.type}`);
      }

      res.json({ received: true });
    } catch (err) {
      console.error('Error handling webhook event:', err);
      res.status(500).send('Internal Server Error');
    }
  }
);

const handleInvoicePaymentEvent = async (invoice, eventType) => {
  try {
    const customerId = invoice.customer;
    const subscriptionId = invoice.subscription;
    const stripeInvoiceId = invoice.id;
    const amountDue = invoice.amount_due / 100;
    const amountPaid = invoice.amount_paid / 100;
    let status;

    if (eventType === 'invoice.payment_succeeded') {
      status = 'paid';
    } else if (eventType === 'invoice.payment_failed') {
      status = 'payment_failed'; // You can define custom statuses as needed
    }

    const invoiceDate = new Date(invoice.created * 1000);
    const dueDate = invoice.due_date ? new Date(invoice.due_date * 1000) : null;
    const pdfUrl = invoice.invoice_pdf || null; // Extract PDF URL

    console.log('Customer ID:', customerId);
    console.log('Invoice ID:', stripeInvoiceId);
    console.log('Subscription ID:', subscriptionId);
    console.log('Invoice status:', status);
    console.log('Invoice PDF URL:', pdfUrl);

    // Find the user by Stripe customer ID
    const user = await User.findOne({ where: { stripeCustomerId: customerId } });
    if (!user) {
      console.error('User not found for customer ID:', customerId);
      return;
    }

    console.log('User found:', user.email);

    // Find the subscription by Stripe subscription ID
    const subscriptionRecord = await Subscription.findOne({
      where: { stripeSubscriptionId: subscriptionId },
    });
    if (!subscriptionRecord) {
      console.error('Subscription not found for subscription ID:', subscriptionId);
      return;
    }

    // Upsert the invoice record
    const [invoiceRecord, created] = await Invoice.upsert(
      {
        user_id: user.id,
        subscriptionId: subscriptionRecord.id,
        stripeInvoiceId: stripeInvoiceId,
        amountDue: amountDue,
        amountPaid: amountPaid,
        status: status,
        invoiceDate: invoiceDate,
        dueDate: dueDate,
        pdfUrl: pdfUrl // Store the PDF URL
      },
      { where: { stripeInvoiceId: stripeInvoiceId } }
    );

    console.log(`Invoice ${created ? 'created' : 'updated'}:`, invoiceRecord.toJSON());
  } catch (err) {
    console.error('Error in handleInvoicePaymentEvent:', err);
  }
};

const handleSubscriptionEvent = async (subscription) => {
  try {
    const customerId = subscription.customer;
    const stripeSubscriptionId = subscription.id;
    const status = subscription.status;
    const startDate = new Date(subscription.start_date * 1000);
    const endDate = new Date(subscription.current_period_end * 1000);
    const cancelAtPeriodEnd = subscription.cancel_at_period_end;

    console.log('Customer ID:', customerId);
    console.log('Subscription ID:', stripeSubscriptionId);
    console.log('Subscription status:', status);
    console.log('Cancel at period end:', cancelAtPeriodEnd);

    // Find the user by Stripe customer ID
    const user = await User.findOne({ where: { stripeCustomerId: customerId } });
    if (!user) {
      console.error('User not found for customer ID:', customerId);
      return;
    }
    console.log('User found:', user.email);

    if (status === 'active') {
      // Deactivate any other active subscriptions for the user
      await Subscription.update(
        { status: 'inactive' },
        {
          where: {
            user_id: user.id,
            status: 'active',
            stripeSubscriptionId: { [Op.ne]: stripeSubscriptionId },
          },
        }
      );
    }

    const [sub, created] = await Subscription.upsert(
      {
        user_id: user.id,
        stripeSubscriptionId: stripeSubscriptionId,
        status: status,
        startDate: startDate,
        endDate: endDate,
        cancelAtPeriodEnd: cancelAtPeriodEnd,
      },
      {
        returning: true, 
      }
    );

    console.log(`Subscription ${created ? 'created' : 'updated'}:`, sub.toJSON());
  } catch (err) {
    console.error('Error in handleSubscriptionEvent:', err);
  }
};

module.exports = router;
