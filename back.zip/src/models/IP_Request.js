// src/models/IP_Request.js

const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const IP_Request = sequelize.define('IP_Request', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  ipAddress: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true // Each IP has a single aggregate row
  },
  requestCount: {
    type: DataTypes.INTEGER,
    defaultValue: 0,
  },
  timestamp: { 
    type: DataTypes.DATE, 
    allowNull: false, 
    defaultValue: DataTypes.NOW 
  },
}, {
  tableName: 'ip_requests',
  timestamps: false,
  indexes: [
    {
      unique: true,
      fields: ['ipAddress']
    }
  ]
});

module.exports = IP_Request;

