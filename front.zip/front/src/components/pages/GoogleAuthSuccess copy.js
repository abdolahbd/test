import React, { useEffect, useContext, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { AuthContext } from '../../contexts/AuthContext';
import api from '../../services/apiService';
import {jwtDecode} from 'jwt-decode';

const GoogleAuthSuccess = () => {
  const { search } = useLocation();
  const navigate = useNavigate();
  const { setUser } = useContext(AuthContext);

  // 1. Parse the key map from .env (unchanged)
  const serviceKeyMap = process.env.REACT_APP_SERVICE_KEY_MAP
    ? JSON.parse(process.env.REACT_APP_SERVICE_KEY_MAP)
    : {};

 // 2. Add a local state flag to prevent multiple POSTs
 const [hasSavedKeys, setHasSavedKeys] = useState(false);

  useEffect(() => {
   // 3. If we’ve already saved the keys, do nothing
   if (hasSavedKeys) return;

    const query = new URLSearchParams(search);
    const token = query.get('token');

    if (token) {
      localStorage.setItem('token', token);
      api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      const decoded = jwtDecode(token);
      setUser(decoded);

      // Gather any existing API keys from localStorage according to serviceKeyMap
      const collectedKeys = {};
      Object.entries(serviceKeyMap).forEach(([serviceName, storageKey]) => {
        const val = localStorage.getItem(storageKey);
        if (val) {
          collectedKeys[storageKey] = val;
        }
      });

      if (Object.keys(collectedKeys).length > 0) {
        api
          .post('/auth/google/save-keys', { apiKeys: collectedKeys })
          .then(() => {
            // Remove them from localStorage
            Object.values(serviceKeyMap).forEach((keyName) => {
              localStorage.removeItem(keyName);
            });
           // 4. Mark that we have saved keys
           setHasSavedKeys(true);
            navigate('/chat');
          })
          .catch((err) => {
            console.error('Failed to save API keys:', err);
           setHasSavedKeys(true);
            navigate('/chat');
          });
      } else {
       setHasSavedKeys(true);
        navigate('/chat');
      }
    } else {
      navigate('/login');
    }
  // 5. Include hasSavedKeys in the dependency array so once it’s true, effect bails out
 }, [search, navigate, setUser, serviceKeyMap, hasSavedKeys]);

  return <div>Logging in...</div>;
};

export default GoogleAuthSuccess;
