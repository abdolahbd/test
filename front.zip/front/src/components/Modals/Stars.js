// src/components/Stars.js

import React from 'react';
import PropTypes from 'prop-types';

const Stars = ({
  count = 5,
  value = 0,
  onChange = () => {},
  size = 40,
  activeColor = '#ffc107',
  isHalf = false,
  name = '',
  ariaLabel = 'Star Rating',
}) => {
  const [hoverValue, setHoverValue] = React.useState(undefined);

  const handleClick = (rating) => {
    onChange(rating);
  };

  const handleMouseOver = (rating) => {
    setHoverValue(rating);
  };

  const handleMouseLeave = () => {
    setHoverValue(undefined);
  };

  return (
    <div
      style={{ display: 'flex', flexDirection: 'row', cursor: 'pointer' }}
      role="radiogroup"
      aria-label={ariaLabel}
      name={name}
    >
      {Array.from({ length: count }, (_, i) => {
        const ratingValue = i + 1;
        return (
          <svg
            key={i}
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 576 512"
            width={size}
            height={size}
            fill={
              (hoverValue || value) >= ratingValue ? activeColor : '#989ea3'
            }
            onClick={() => handleClick(ratingValue)}
            onMouseOver={() => handleMouseOver(ratingValue)}
            onMouseLeave={handleMouseLeave}
            aria-checked={value === ratingValue}
            role="radio"
          >
            <path d="M287.9 17.8L354 150.2 499.5 171.5C518.3 173.4 526.6 196.3 513.8 208.3L405.1 318.1 429.5 464.6C432.4 483.4 412.1 497.3 398.4 488.3L288 439.6 177.6 488.3C163.9 497.3 143.6 483.4 146.5 464.6L171 318.1 62.2 208.3C49.4 196.3 57.7 173.4 76.5 171.5L222 150.2 288.1 17.8C296.4 0.4 319.6 0.4 327.9 17.8H287.9z" />
          </svg>
        );
      })}
    </div>
  );
};

Stars.propTypes = {
  count: PropTypes.number,
  value: PropTypes.number,
  onChange: PropTypes.func,
  size: PropTypes.number,
  activeColor: PropTypes.string,
  isHalf: PropTypes.bool,
  name: PropTypes.string,
  ariaLabel: PropTypes.string,
};

export default Stars;
