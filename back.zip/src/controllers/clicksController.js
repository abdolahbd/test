// src/controllers/clicksController.js

const Click = require('../models/Click');
const IP_Click = require('../models/IP_Click'); // Import the IP_Click model
const User = require('../models/User');
const geoip = require('geoip-lite');

/**
 * Helper function to extract the client's IP address.
 * This considers possible proxy headers.
 */
const getClientIP  = (req) => {
  // Extract the IP address
  const forwarded = req.headers['x-forwarded-for'];
  let ip;

  if (forwarded) {
    // 'x-forwarded-for' may return multiple IP addresses in the format: "client IP, proxy 1 IP, proxy 2 IP"
    const forwardedIps = forwarded.split(',').map(ip => ip.trim());
    ip = forwardedIps[0];
  } else {
    ip = req.connection.remoteAddress || req.socket.remoteAddress || req.ip;
  }

  // Handle IPv6 addresses that are IPv4 mapped (e.g., ::ffff:127.0.0.1)
  const cleanIp = ip.startsWith('::ffff:') ? ip.substring(7) : ip;

  // Lookup the geolocation data
  const geo = geoip.lookup(cleanIp);

  // Extract the country code or set to 'Unknown' if not found
  const country = geo ? geo.country : 'Unknown';

  return JSON.stringify({ ip: cleanIp, country });
};

/**
 * Records click counts, conversation counts, and favorite counts for the authenticated user or based on IP for unauthenticated users.
 * - clickCount: Accumulated (incremented)
 * - conversationCount & favoriteCount: Set to incoming values
 * Sends back a success message upon successful recording.
 */
const recordClicks = async (req, res) => {
  try {
    const { clickCount, conversationCount, favoriteCount, isLimitReached} = req.body;

    // const isLimitReached=String(req.body.isLimitReached)
    console.log('------------------------------');
    console.log({ clickCount, conversationCount, favoriteCount ,isLimitReached});
    console.log('------------------------------');

    // Input validation
    const isValidNumber = (num) => typeof num === 'number' && num >= 0;

    if (
      !isValidNumber(clickCount) ||
      !isValidNumber(conversationCount) ||
      !isValidNumber(favoriteCount)
    ) {
      return res.status(400).json({
        error:
          'Invalid input. clickCount, conversationCount, and favoriteCount must be non-negative numbers.',
      });
    }

    if (!req.user) {
      // Handle unauthenticated user by tracking via IP
      const ipAddress = getClientIP(req);
      console.log(`Client IP Address: ${ipAddress}`);
      console.log(
        `Incoming Counts: Clicks=${clickCount}, Conversations=${conversationCount}, Favorites=${favoriteCount}`
      );

      // Find existing IP_Click record for the IP
      let ipClick = await IP_Click.findOne({ where: { ipAddress } });

      if (ipClick) {
        // **Accumulate** clickCount
        ipClick.clickCount += clickCount;

        // **Set** conversationCount and favoriteCount to incoming values
        ipClick.conversationCount = conversationCount;
        ipClick.favoriteCount = favoriteCount;
        ipClick.isLimitReached=isLimitReached

        await ipClick.save();

        console.log(
          `Updated Counts for IP ${ipAddress}: Clicks=${ipClick.clickCount}, Conversations=${ipClick.conversationCount}, Favorites=${ipClick.favoriteCount}`
        );

        return res.status(200).json({
          message: 'Counts updated successfully for IP.',
          data: {
            clickCount: ipClick.clickCount,
            conversationCount: ipClick.conversationCount,
            favoriteCount: ipClick.favoriteCount,
            isLimitReached: ipClick.isLimitReached,
          },
        });
      } else {
        // Create a new IP_Click record with incoming values
        ipClick = await IP_Click.create({
          ipAddress,
          clickCount,
          conversationCount,
          favoriteCount,
          isLimitReached,
          timestamp: new Date(),
        });

        console.log(
          `Created Counts for IP ${ipAddress}: Clicks=${ipClick.clickCount}, Conversations=${ipClick.conversationCount}, Favorites=${ipClick.favoriteCount}`
        );

        return res.status(201).json({
          message: 'Counts recorded successfully for IP.',
          data: {
            clickCount: ipClick.clickCount,
            conversationCount: ipClick.conversationCount,
            favoriteCount: ipClick.favoriteCount,
            isLimitReached: ipClick.isLimitReached,
          },
        });
      }
    } else {
      // Handle authenticated user
      const userId = req.user.id; // Assuming auth middleware sets req.user
      console.log('*************');
      console.log(`User ID: ${userId}`);
      console.log(
        `Incoming Counts: Clicks=${clickCount}, Conversations=${conversationCount}, Favorites=${favoriteCount}, isLimitReached=${isLimitReached}`
      );
      console.log('*************');

      // Check if user exists
      const user = await User.findByPk(userId);
      if (!user) {
        return res.status(404).json({ error: 'User not found.' });
      }

      // Find existing Click record for the user
      let userClick = await Click.findOne({ where: { user_id: userId } });

      if (userClick) {
        const ip = getClientIP(req);

        // **Accumulate** clickCount
        userClick.clickCount += clickCount;

        // **Set** conversationCount and favoriteCount to incoming values
        userClick.conversationCount = conversationCount;
        userClick.favoriteCount = favoriteCount;
        userClick.isLimitReached = isLimitReached;
        userClick.ip = ip;


        await userClick.save();

        console.log(
          `Updated Counts for User ID ${userId}: Clicks=${userClick.clickCount}, Conversations=${userClick.conversationCount}, Favorites=${userClick.favoriteCount}`
        );

        return res.status(200).json({
          message: 'Counts updated successfully for user.',
          data: {
            clickCount: userClick.clickCount,
            conversationCount: userClick.conversationCount,
            favoriteCount: userClick.favoriteCount,
            isLimitReached: userClick.isLimitReached,
          },
        });
      } else {
        const ip = getClientIP(req);
        // Create a new Click record with incoming values
        userClick = await Click.create({
          user_id: userId,
          clickCount,
          conversationCount,
          favoriteCount,
          isLimitReached,
          ip,
          timestamp: new Date(),
        });

        console.log(
          `Created Counts for User ID ${userId}: Clicks=${userClick.clickCount}, Conversations=${userClick.conversationCount}, Favorites=${userClick.favoriteCount}`
        );

        return res.status(201).json({
          message: 'Counts recorded successfully for user.',
          data: {
            clickCount: userClick.clickCount,
            conversationCount: userClick.conversationCount,
            favoriteCount: userClick.favoriteCount,
            isLimitReached: userClick.isLimitReached,
          },
        });
      }
    }
  } catch (error) {
    console.error('Error recording counts:', error);
    return res.status(500).json({ error: 'Internal server error.' });
  }
};

/**
 * (Optional) Retrieves the total counts for the authenticated user or by IP for unauthenticated users.
 */
const getUserClicks = async (req, res) => {
  try {
    if (!req.user) {
      // Retrieve counts based on IP
      const ipAddress = getClientIP(req);
      const ipClick = await IP_Click.findOne({ where: { ipAddress } });

      if (!ipClick) {
        return res.status(404).json({ message: 'No click data found for this IP.' });
      }

      return res.status(200).json({
        data: {
          clickCount: ipClick.clickCount,
          conversationCount: ipClick.conversationCount,
          favoriteCount: ipClick.favoriteCount,
          timestamp: ipClick.timestamp,
        },
      });
    } else {
      // Retrieve counts for authenticated user
      const userId = req.user.id; // Assuming auth middleware sets req.user

      // Fetch the Click record for the user
      const userClick = await Click.findOne({ where: { user_id: userId } });

      if (!userClick) {
        return res.status(404).json({ message: 'No click data found for this user.' });
      }

      return res.status(200).json({
        data: {
          clickCount: userClick.clickCount,
          conversationCount: userClick.conversationCount,
          favoriteCount: userClick.favoriteCount,
          timestamp: userClick.timestamp,
        },
      });
    }
  } catch (error) {
    console.error('Error fetching user counts:', error);
    return res.status(500).json({ error: 'Internal server error.' });
  }
};

module.exports = {
  recordClicks,
  getUserClicks,
};
