// routes/reviews.js

const express = require('express');
const router = express.Router();
const reviewsController = require('../controllers/reviewsController');
const auth = require('../middleware/auth'); // Authentication middleware
const NoAuth = require('../middleware/NoAuth'); // No Authentication middleware

/**
 * @route   POST /api/reviews
 * @desc    Submit a review
 * @access  Public or Private based on LMARHALA
 */
if (process.env.LMARHALA == 0) {
  // If LMARHALA is 0, use NoAuth middleware
  router.post('/', NoAuth, reviewsController.submitReview);
  router.get('/', NoAuth, reviewsController.getAllReviews);
  router.get('/my-reviews', NoAuth, reviewsController.getUserReviews); // Optional
} else {
  // Otherwise, use Auth middleware
  router.post('/', auth, reviewsController.submitReview);
  router.get('/', auth, reviewsController.getAllReviews);
  router.get('/my-reviews', auth, reviewsController.getUserReviews); // Optional
}

module.exports = router;
