// src/utils/fileSystem.js
export const saveFile = async (data, fileName) => {
    const handle = await window.showSaveFilePicker({
      suggestedName: fileName,
      types: [
        {
          description: 'JSON Files',
          accept: { 'application/json': ['.json'] },
        },
      ],
    });
    const writable = await handle.createWritable();
    await writable.write(JSON.stringify(data));
    await writable.close();
  };
  
  export const loadFile = async () => {
    const [handle] = await window.showOpenFilePicker({
      types: [
        {
          description: 'JSON Files',
          accept: { 'application/json': ['.json'] },
        },
      ],
    });
    const file = await handle.getFile();
    const contents = await file.text();
    return JSON.parse(contents);
  };
  