import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { FaSquareCheck } from "react-icons/fa6";
import { BsInfoSquareFill } from "react-icons/bs";
import { AiFillCloseSquare } from "react-icons/ai";

// Create the Toast Context
const ToastContext = createContext(null);

// ToastProvider Component
export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const [isSmallScreen, setIsSmallScreen] = useState(window.innerWidth <= 600);

  // Handler to update screen size
  const handleResize = useCallback(() => {
    setIsSmallScreen(window.innerWidth <= 600);
  }, []);

  useEffect(() => {
    // Add event listener
    window.addEventListener('resize', handleResize);
    // Initial check
    handleResize();
    // Cleanup
    return () => window.removeEventListener('resize', handleResize);
  }, [handleResize]);

  // Function to show a toast
  const showToast = useCallback((message, duration = 5000) => { // Default duration 5 seconds
    // Parse the message to extract type and text
    const regex = /^#(info|success|error):(.+)$/;
    const match = message.match(regex);

    let type = 'info'; // default type
    let text = message;

    if (match) {
      type = match[1];
      text = match[2].trim();

      // Remove trailing period if it exists
      if (text.endsWith('.')) {
        text = text.slice(0, -1);
      }
    }

    const id = Date.now();

    // Add a new toast with type and text
    setToasts((prev) => [...prev, { id, type, text }]);

    // Remove it after `duration` milliseconds
    const timer = setTimeout(() => {
      setToasts((prev) => prev.filter((toast) => toast.id !== id));
    }, duration);

    // Cleanup in case the toast is removed manually before timeout
    return () => clearTimeout(timer);
  }, []);

  // Override the native window.alert
  useEffect(() => {
    const originalAlert = window.alert;
    window.alert = function overrideAlert(msg) {
      showToast(msg);
    };

    // Clean up on unmount: restore original alert
    return () => {
      window.alert = originalAlert;
    };
  }, [showToast]);

  // Function to manually remove a toast
  const removeToast = (id) => {
    setToasts((prev) => prev.filter((toast) => toast.id !== id));
  };

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      {createPortal(
        <div style={styles.toastContainer}>
          {toasts.map((t) => (
            <div
              key={t.id}
              style={{
                ...styles.toast,
                ...getToastStyle(t.type),
                maxWidth: isSmallScreen ? '90%' : '350px', // Adjust maxWidth based on screen size
                width: '100%',
              }}
            >
              {/* Close Button */}
              <button onClick={() => removeToast(t.id)} style={styles.closeButton}>
                &times;
              </button>

              {/* Toast Content */}
              <div style={styles.toastContent}>
                <div style={styles.iconAndText}>
                  {getIcon(t.type)}
                  <div style={styles.textContainer}>
                    <span style={styles.typeText}>{capitalize(t.type)}</span>
                    <span style={styles.messageText}>{t.text}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>,
        document.body
      )}
    </ToastContext.Provider>
  );
}

// Custom hook to use the Toast context
export function useToast() {
  return useContext(ToastContext);
}

// Helper function to get styles based on toast type
const getToastStyle = (type) => {
  switch (type) {
    case 'success':
      return {
        border: '2px solid #18b24e',
        backgroundColor: '#f4fef5', // Light Green
        color: '#18b24e',
      };
    case 'error':
      return {
        border: '2px solid #F44336',
        backgroundColor: '#fffcfc', // Light Red
        color: '#c62828',
      };
    case 'info':
    default:
      return {
        border: '2px solid #2196F3',
        backgroundColor: '#edf2f6', // Light Blue
        color: '#1565c0',
      };
  }
};

// Helper function to capitalize the first letter
const capitalize = (s) => s.charAt(0).toUpperCase() + s.slice(1);

// Helper function to get the icon based on toast type
const getIcon = (type) => {
  const iconStyle = styles.icon;
  switch (type) {
    case 'success':
      return <FaSquareCheck style={iconStyle} />;
    case 'error':
      return <AiFillCloseSquare style={iconStyle} />;
    case 'info':
    default:
      return <BsInfoSquareFill style={iconStyle} />;
  }
};

// Inline styles for the component
const styles = {
  toastContainer: {
    position: 'fixed',
    top: '1rem',
    left: '50%',
    transform: 'translateX(-50%)',
    zIndex: 9999,
    display: 'flex',
    flexDirection: 'column',
    gap: '0.5rem',
    maxWidth: '90%',
    width: '100%',
    padding: '0 1rem', // Add some horizontal padding for small screens
    boxSizing: 'border-box',
    alignItems: 'center', // Ensure the container centers its children
  },
  toast: {
    position: 'relative', // To position the close button absolutely within the toast
    padding: '0.75rem 1rem',
    borderRadius: '8px',
    boxShadow: 'rgba(0, 0, 0, 0.2) 0px 4px 6px',
    display: 'flex',
    flexDirection: 'column',
    wordWrap: 'break-word',
    transition: 'all 0.3s ease-in-out',
    // Ensure the toast itself is centered
    alignSelf: 'center',
  },
  closeButton: {
    position: 'absolute',
    top: '0.5rem',
    right: '0.75rem',
    background: 'transparent',
    border: 'none',
    color: 'inherit',
    fontSize: '1.2rem',
    cursor: 'pointer',
    lineHeight: '1',
    padding: '0',
  },
  toastContent: {
    display: 'flex',
    alignItems: 'flex-start',
  },
  iconAndText: {
    display: 'flex',
    alignItems: 'flex-start',
    gap: '0.5rem',
  },
  textContainer: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'flex-end',
    color: 'black',
    marginLeft: '10px',
  },
  typeText: {
    fontWeight: 600,
    fontSize: '1rem',
    lineHeight: '1.2',
    marginBottom: '4px',
  },
  messageText: {
    fontSize: '0.9rem',
    lineHeight: '1.2',
  },
  icon: {
    flexShrink: 0,
    fontSize: '1.5rem',
  },
};
