// src/controllers/helpsController.js

const Help = require('../models/Help');
const IP_Help = require('../models/IP_Help');
const User = require('../models/User');
const geoip = require('geoip-lite');

/**
 * Helper function to extract the client's IP address.
 * This considers possible proxy headers.
 */
const getClientIP  = (req) => {
  // Extract the IP address
  const forwarded = req.headers['x-forwarded-for'];
  let ip;

  if (forwarded) {
    // 'x-forwarded-for' may return multiple IP addresses in the format: "client IP, proxy 1 IP, proxy 2 IP"
    const forwardedIps = forwarded.split(',').map(ip => ip.trim());
    ip = forwardedIps[0];
  } else {
    ip = req.connection.remoteAddress || req.socket.remoteAddress || req.ip;
  }

  // Handle IPv6 addresses that are IPv4 mapped (e.g., ::ffff:127.0.0.1)
  const cleanIp = ip.startsWith('::ffff:') ? ip.substring(7) : ip;

  // Lookup the geolocation data
  const geo = geoip.lookup(cleanIp);

  // Extract the country code or set to 'Unknown' if not found
  const country = geo ? geo.country : 'Unknown';

  return JSON.stringify({ ip: cleanIp, country });
};

/**
 * Submit a help request
 * - For authenticated users, create a new Help row.
 * - For unauthenticated users, create a new IP_Help row.
 * Each request becomes a new record instead of appending to an existing one.
 */
const submitHelp = async (req, res) => {
  try {
    const { text } = req.body;

    // Input validation
    if (!text || typeof text !== 'string' || text.trim().length === 0) {
      return res.status(400).json({ error: 'Text is required and must be a non-empty string.' });
    }

    const trimmedText = text.trim();

    if (req.user) {
      // Authenticated user
      const userId = req.user.id;
      console.log(`Authenticated User ID: ${userId}`);

      const user = await User.findByPk(userId);
      if (!user) {
        return res.status(404).json({ error: 'User not found.' });
      }

      // Create a new Help entry for each message
      const help = await Help.create({
        user_id: userId,
        text: trimmedText,
      });

      console.log(`Help created for User ID ${userId}:`, help.toJSON());

      return res.status(201).json({
        message: 'Help submitted successfully.',
        data: help,
      });

    } else {
      // Unauthenticated user, track by IP
      const ipAddress = getClientIP(req);
      console.log(`Unauthenticated User IP: ${ipAddress}`);

      // Create a new IP_Help entry for each message
      const ipHelp = await IP_Help.create({
        ipAddress: ipAddress,
        text: trimmedText,
      });

      console.log(`Help created for IP ${ipAddress}:`, ipHelp.toJSON());

      return res.status(201).json({
        message: 'Help submitted successfully.',
        data: ipHelp,
      });
    }
  } catch (error) {
    console.error('Error submitting help:', error);
    // If you previously had a unique constraint on ipAddress, remove it from your model and DB.
    return res.status(500).json({ error: 'Internal server error.' });
  }
};

/**
 * Retrieves all help requests, combining authenticated and unauthenticated entries.
 */
const getAllHelps = async (req, res) => {
  try {
    // Fetch all authenticated user helps
    const authenticatedHelps = await Help.findAll({
      include: [{
        model: User,
        attributes: ['id', 'name'], // Include user details if needed
      }],
      order: [['timestamp', 'DESC']],
    });

    // Fetch all unauthenticated user helps
    const ipHelps = await IP_Help.findAll({
      order: [['timestamp', 'DESC']],
    });

    // Combine both
    const allHelps = [
      ...authenticatedHelps.map(help => ({
        id: help.id,
        user_id: help.user_id,
        userName: help.User ? help.User.name : null,
        text: help.text, // Single message
        timestamp: help.timestamp,
        authenticated: true,
      })),
      ...ipHelps.map(help => ({
        id: help.id,
        ipAddress: help.ipAddress,
        text: help.text, // Single message
        timestamp: help.timestamp,
        authenticated: false,
      })),
    ];

    return res.status(200).json({
      data: allHelps,
    });
  } catch (error) {
    console.error('Error fetching helps:', error);
    return res.status(500).json({ error: 'Internal server error.' });
  }
};

/**
 * Retrieve all help requests for the authenticated user or by IP for unauthenticated users.
 */
const getUserHelps = async (req, res) => {
  try {
    if (req.user) {
      // Authenticated user
      const userId = req.user.id;

      const userHelps = await Help.findAll({
        where: { user_id: userId },
        include: [{
          model: User,
          attributes: ['id', 'name'],
        }],
        order: [['timestamp', 'DESC']],
      });

      const parsedUserHelps = userHelps.map(help => help.toJSON());

      return res.status(200).json({
        data: parsedUserHelps,
      });
    } else {
      // Unauthenticated user, fetch by IP
      const ipAddress = getClientIP(req);

      const ipHelps = await IP_Help.findAll({
        where: { ipAddress: ipAddress },
        order: [['timestamp', 'DESC']],
      });

      const parsedIpHelps = ipHelps.map(help => help.toJSON());

      return res.status(200).json({
        data: parsedIpHelps,
      });
    }
  } catch (error) {
    console.error('Error fetching user helps:', error);
    return res.status(500).json({ error: 'Internal server error.' });
  }
};

module.exports = {
  submitHelp,
  getAllHelps,
  getUserHelps,
};
