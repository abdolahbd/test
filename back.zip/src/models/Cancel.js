// src/models/Cancel.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Cancel = sequelize.define('Cancel', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'Users', // Ensure this matches your Users table name
      key: 'id',
    },
    onDelete: 'CASCADE',
  },
  canceledAt: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW,
  },
  reason: { 
    type: DataTypes.STRING(4500), 
    } 
}, {
  tableName: 'Cancels',
  timestamps: false, // Set to true if you want `createdAt` and `updatedAt` fields
});

module.exports = Cancel;
