// useConfirm.js
import React, { useState } from 'react';

export function useConfirm() {
  const [confirmState, setConfirmState] = useState({
    isOpen: false,
    message: '',
    resolve: null, // we'll store the promise's resolve here
  });

  /**
   * Opens the modal with the given message, returning a promise that
   * resolves true or false based on user action.
   */
  const confirm = (message) => {
    return new Promise((resolve) => {
      setConfirmState({
        isOpen: true,
        message,
        resolve, // store the resolve function so we can call it later
      });
    });
  };

  // When user clicks "Yes"
  const handleConfirm = () => {
    setConfirmState((prev) => {
      prev.resolve(true);
      return { ...prev, isOpen: false };
    });
  };

  // When user clicks "No"
  const handleCancel = () => {
    setConfirmState((prev) => {
      prev.resolve(false);
      return { ...prev, isOpen: false };
    });
  };

  /**
   * The actual ConfirmModal component
   */
  const ConfirmModal = () => {
    if (!confirmState.isOpen) return null;
    return (
      <div style={modalOverlayStyle}>
        <div style={modalStyle}>
          <p>{confirmState.message}</p>
          <button onClick={handleConfirm}>Yes</button>
          <button onClick={handleCancel}>No</button>
        </div>
      </div>
    );
  };

  return {
    confirm,
    ConfirmModal,
  };
}

/* Just some inline styles for the example */
const modalOverlayStyle = {
  position: 'fixed',
  top: 0, left: 0,
  width: '100vw', height: '100vh',
  backgroundColor: 'rgba(0,0,0,0.3)',
  display: 'flex', alignItems: 'center', justifyContent: 'center',
};

const modalStyle = {
  background: '#fff',
  padding: '1rem',
  borderRadius: '5px',
  minWidth: '200px',
};
