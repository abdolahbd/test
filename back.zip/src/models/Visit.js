const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
// Removed unused import of User if not needed
// const User = require('./User');

const Visit = sequelize.define('Visit', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  source: {
    type: DataTypes.STRING(2550),
    allowNull: false,
  },
  ip: { // New IP field added
    type: DataTypes.STRING(4500), // Supports IPv6
    allowNull: false,
  },
}, {
  timestamps: true, // Automatically adds createdAt and updatedAt fields
  updatedAt: false, // We only need createdAt
  tableName: 'visits', // Explicitly define table name
});

// If you’re adding a new field to an existing table, make sure to run the necessary migrations.
// For Sequelize CLI, you can create a migration file to add the 'ip' column.

module.exports = Visit;
