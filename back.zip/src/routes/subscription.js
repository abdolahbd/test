// src/routes/subscription.js

const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const subscriptionController = require('../controllers/subscriptionController');

router.get('/', auth, subscriptionController.getSubscription);
router.post('/cancel', auth, subscriptionController.cancelSubscription);
router.post('/resubscribe', auth, subscriptionController.resubscribe); // Add this if you have resubscription feature
router.post('/record-subscription-page-visit', auth, subscriptionController.recordSubscriptionPageVisit);


module.exports = router;
 