// src/components/pages/SignupPage.js

import React, { useState, useContext } from 'react';
import { AuthContext } from '../../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import api from '../../services/apiService';
import CryptoJS from 'crypto-js';

// Same environment vars as before
const encryptionKey = process.env.REACT_APP_ENCRYPTION_KEY;
const encryptionEnabledFlag = process.env.REACT_APP_ENCRYPTION_ENABLED === '1';

/**
 * If encryption enabled, hash the key; else plain key.
 */
function maybeHashKey(key) {
  if (encryptionEnabledFlag) {
    return CryptoJS.SHA256(key).toString();
  } else {
    return key;
  }
}

const encryptLocalData = (plainText) => {
  if (!encryptionKey) {
    throw new Error('Encryption key is missing. Please set REACT_APP_ENCRYPTION_KEY in your .env file.');
  }
  return CryptoJS.AES.encrypt(plainText, encryptionKey).toString();
};

const decryptLocalData = (cipherText) => {
  if (!encryptionKey) {
    throw new Error('Encryption key is missing. Please set REACT_APP_ENCRYPTION_KEY in your .env file.');
  }
  const bytes = CryptoJS.AES.decrypt(cipherText, encryptionKey);
  return bytes.toString(CryptoJS.enc.Utf8);
};

const secureLocalStorage = {
  setItem: (key, value) => {
    if (!key) return;
    const storageKey = maybeHashKey(key);
    if (encryptionEnabledFlag) {
      const encryptedValue = encryptLocalData(value);
      localStorage.setItem(storageKey, encryptedValue);
    } else {
      localStorage.setItem(storageKey, value);
    }
  },
  getItem: (key) => {
    if (!key) return null;
    const storageKey = maybeHashKey(key);
    const storedValue = localStorage.getItem(storageKey);
    if (!storedValue) return null;
    if (encryptionEnabledFlag) {
      try {
        return decryptLocalData(storedValue);
      } catch (err) {
        console.error('Failed to decrypt localStorage value:', err);
        return null;
      }
    } else {
      return storedValue;
    }
  },
  removeItem: (key) => {
    if (!key) return;
    const storageKey = maybeHashKey(key);
    localStorage.removeItem(storageKey);
  },
  clear: () => {
    localStorage.clear();
  },
};

const SignupPage = () => {
  console.log(212);

  const { login } = useContext(AuthContext);
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    email: '',
    password: '',
    apiKey: '',
  });
  const [error, setError] = useState(null);

  const { email, password, apiKey } = formData;

  const onChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await api.post('/auth/register', {
        email,
        password,
        apiKey,
      });
      const { token } = response.data;

      // Use secureLocalStorage instead of localStorage
      secureLocalStorage.setItem('token', token);

      api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      login(); // Update auth context
      navigate('/chat');
    } catch (err) {
      setError(err.response?.data?.error || 'Registration failed');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="email"
        placeholder="Email"
        name="email"
        value={email}
        onChange={onChange}
      />
      <input
        type="password"
        placeholder="Password"
        name="password"
        value={password}
        onChange={onChange}
      />
      <input
        type="text"
        placeholder="OpenAI API Key"
        name="apiKey"
        value={apiKey}
        onChange={onChange}
      />
      {error && <div style={{ color: 'red' }}>{error}</div>}
      <button type="submit">Sign Up</button>
      <div>
        <a href="http://localhost:4000/api/v1/auth/google">
          Sign Up with Google
        </a>
      </div>
    </form>
  );
};

export default SignupPage;
