// src/components/pages/HomePage.js

import { Link } from 'react-router-dom';
// import './HomePage.css'; // Optional: For styling
import React, { useEffect, useContext } from 'react';
import { AuthContext } from '../../contexts/AuthContext'; // Import AuthContext
import { useLocation } from 'react-router-dom';
import api from '../../services/apiService';
import CryptoJS from 'crypto-js';

// ===== New: environment-based encryption toggle + key =====
const encryptionKey = process.env.REACT_APP_ENCRYPTION_KEY;
const encryptionEnabledFlag = process.env.REACT_APP_ENCRYPTION_ENABLED === '1';

// ===== New: maybeHashKey for keys + AES if encryption is enabled =====
function maybeHashKey(key) {
  if (encryptionEnabledFlag) {
    return CryptoJS.SHA256(key).toString();
  } else {
    return key;
  }
}

const encryptLocalData = (plainText) => {
  if (!encryptionKey) {
    throw new Error('Encryption key is missing. Please set REACT_APP_ENCRYPTION_KEY in your .env file.');
  }
  return CryptoJS.AES.encrypt(plainText, encryptionKey).toString();
};

const decryptLocalData = (cipherText) => {
  if (!encryptionKey) {
    throw new Error('Encryption key is missing. Please set REACT_APP_ENCRYPTION_KEY in your .env file.');
  }
  const bytes = CryptoJS.AES.decrypt(cipherText, encryptionKey);
  return bytes.toString(CryptoJS.enc.Utf8);
};

const secureLocalStorage = {
  setItem: (key, value) => {
    if (!key) return;
    const storageKey = maybeHashKey(key);
    if (encryptionEnabledFlag) {
      const encryptedValue = encryptLocalData(value);
      localStorage.setItem(storageKey, encryptedValue);
    } else {
      localStorage.setItem(storageKey, value);
    }
  },
  getItem: (key) => {
    if (!key) return null;
    const storageKey = maybeHashKey(key);
    const storedValue = localStorage.getItem(storageKey);
    if (!storedValue) return null;

    if (encryptionEnabledFlag) {
      try {
        return decryptLocalData(storedValue);
      } catch (err) {
        console.error('Failed to decrypt localStorage value:', err);
        return null;
      }
    } else {
      return storedValue;
    }
  },
  removeItem: (key) => {
    if (!key) return;
    const storageKey = maybeHashKey(key);
    localStorage.removeItem(storageKey);
  },
  clear: () => {
    localStorage.clear();
  },
};

function HomePage() {
  const location = useLocation(); 
  const { user, loading } = useContext(AuthContext); 

  useEffect(() => {
    if (loading) {
      // Wait until authentication status is determined
      return;
    }

    // Determine the current user ID or fallback
    const userId = user ? user.id : "777777777";

    // Define the sourceSent flag based on the user ID
    const sourceSentFlag = `sourceSentHome_${userId}`;
    const fromExample = `fromExample`;
    const exampleURL = `exampleURL`;

    // Check if the source has already been sent for this user
    if (!secureLocalStorage.getItem(sourceSentFlag)) {
      // Function to send source to backend
      const sendSourceToBackend = async (source) => {
        try {
          await api.post('/visit', { source: JSON.stringify(source), userId });
          console.log('Source sent to backend:', source);
        } catch (error) {
          console.error('Error sending source to backend:', error);
        }
      };

      // Function to extract UTM parameters
      const getUTMParams = () => {
        const params = new URLSearchParams(location.search);
        const utm_source = params.get('utm_source');
        const utm_medium = params.get('utm_medium');
        const utm_campaign = params.get('utm_campaign');
        return { utm_source, utm_medium, utm_campaign };
      };

      // Function to determine source
      const determineSource = () => {
        const { utm_source, utm_medium, utm_campaign } = getUTMParams();
        if (utm_source) {
          return { utm_source, utm_medium, utm_campaign };
        } else if (document.referrer) {
          try {
            const referrerUrl = new URL(document.referrer);
            return {
              visitedPage: 'Home page',
              fromExample: secureLocalStorage.getItem(fromExample),
              exampleURL: secureLocalStorage.getItem(exampleURL),
              URL: referrerUrl.toString(),
              hash: referrerUrl.hash,
              host: referrerUrl.host,
              hostname: referrerUrl.hostname,
              href: referrerUrl.href,
              origin: referrerUrl.origin,
              password: referrerUrl.password,
              pathname: referrerUrl.pathname,
              port: referrerUrl.port,
              protocol: referrerUrl.protocol,
              search: referrerUrl.search,
              searchParams: Object.fromEntries(referrerUrl.searchParams.entries()),
              username: referrerUrl.username,
            };
          } catch (err) {
            console.error('Error parsing referrer URL:', err);
            return null;
          }
        }
        return null;
      };

      // Determine the source
      const source = determineSource();

      if (source) {
        console.log('Source:', source);
        sendSourceToBackend(source).then(() => {
          secureLocalStorage.setItem(sourceSentFlag, 'true');
        });
      } else {
        console.log('Source is empty or invalid.');
        sendSourceToBackend({
          visitedPage: "Home page",
          fromExample: secureLocalStorage.getItem(fromExample),
          exampleURL: secureLocalStorage.getItem(exampleURL),
        }).then(() => {
          secureLocalStorage.setItem(sourceSentFlag, 'true');
        });
      }
    } else {
      console.log(`Source already sent for user ID: ${userId}`);
    }
  }, [location.search, user, loading]);

  return (
    <div className="home-page">
      <header className="home-header">
        <h1>Welcome to MyApp</h1>
        <p>Your gateway to seamless communication.</p>
        <div className="home-buttons">
          {!user && (
            <>
              <Link to="/login" className="btn btn-primary">Login</Link>
              <Link to="/signup" className="btn btn-secondary">Sign Up</Link>
            </>
          )}
          {user && (
            <Link to="/chat" className="btn btn-primary">Go to Chat</Link>
          )}
        </div>
      </header>
    </div>
  );
}

export default HomePage;
