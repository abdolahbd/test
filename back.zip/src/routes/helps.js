// src/routes/helps.js

const express = require('express');
const router = express.Router();
const helpsController = require('../controllers/helpsController');
const auth = require('../middleware/auth'); // Authentication middleware
const NoAuth = require('../middleware/NoAuth'); // No Authentication middleware

/**
 * If you have logic similar to LMARHALA for deciding if endpoints are public or private,
 * you can replicate it here. Otherwise, by default:
 * 
 * - POST /api/v1/helps could be public (NoAuth) to handle unauthenticated requests.
 * - GET /api/v1/helps also public or private based on your needs.
 * - GET /api/v1/helps/my-helps to get user-specific helps.
 */

// Example: If you want the same logic as reviews, just replicate:
if (process.env.LMARHALA == 0) {
  router.post('/', NoAuth, helpsController.submitHelp);
  router.get('/', NoAuth, helpsController.getAllHelps);
  router.get('/my-helps', NoAuth, helpsController.getUserHelps);
} else {
  router.post('/', auth, helpsController.submitHelp);
  router.get('/', auth, helpsController.getAllHelps);
  router.get('/my-helps', auth, helpsController.getUserHelps);
}

module.exports = router;