// src/components/common/ServiceDropdown.js

import React, { useRef, useEffect } from 'react';
import './ServiceDropdown.css'; // Ensure this path is correct
import { FaCheckCircle } from "react-icons/fa";
import { MdOutlineKeyboardDoubleArrowDown } from "react-icons/md";

const ServiceDropdown = ({
  supportedServices,
  apiKeyStatus,
  serviceKeyMap,
  selectedService,
  setSelectedService,
  onAddOrUpdate,
  isLimitReached,
  isOpen, // Controlled by parent
  setIsOpen, // Function to control from parent
}) => {
  const dropdownRef = useRef(null);

  // Close dropdown if user clicks outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [setIsOpen]);

  const handleToggleDropdown = () => {
    if (!isLimitReached) {
      setIsOpen((prev) => !prev);
    }
  };

  // Closes the dropdown, sets the selected service
  const handleSelectService = (service) => {
    setSelectedService(service);
    setIsOpen(false);
  };

  // Select the service but DO NOT close the dropdown
  // (used by the checkbox so it won't close)
  const handleCheckboxChange = (e, service) => {
    e.stopPropagation(); // Prevent row click
    setSelectedService(service);
    // Do NOT close the dropdown here
  };

  return (
    <div className="service-dropdown" ref={dropdownRef}>
      <div
        className="service-dropdown-header"
        style={{
          backgroundColor: apiKeyStatus[serviceKeyMap[selectedService]] ? '#beffbe' : '#ff7f7f',
          borderColor: apiKeyStatus[serviceKeyMap[selectedService]] ? '#beffbe' : '#c10d0d',
          color: apiKeyStatus[serviceKeyMap[selectedService]] ? '#003f01' : '#3f0000'
        }}
        onClick={handleToggleDropdown}
      >
        <span>
          {apiKeyStatus[serviceKeyMap[selectedService]]
            ? (selectedService ? "Api Key : " + selectedService : 'Select a service')
            : 'Add Api Key'
          }
        </span>

        <span className="dropdown-arrow">
          {apiKeyStatus[serviceKeyMap[selectedService]] ? <FaCheckCircle /> : ''}  
          <MdOutlineKeyboardDoubleArrowDown />
        </span>
      </div>

      {isOpen && (
        <div className="service-dropdown-menu">
          {supportedServices.map((service) => {
            const hasKey = apiKeyStatus[serviceKeyMap[service]];
            return (
              <div
                key={service}
                className="service-dropdown-item"
                // Now clicking anywhere (except the checkbox) does BOTH:
                // 1) selects the service & closes the dropdown
                // 2) calls onAddOrUpdate (like clicking Add/Update button)
                onClick={() => {
                  handleSelectService(service);
                  // onAddOrUpdate(service);
                }}
              >
                <input
                  type="checkbox"
                  checked={selectedService === service}
                  onChange={(e) => handleCheckboxChange(e, service)}
                  onClick={(e) => e.stopPropagation()} 
                />

                <span className="service-label">
                  {service}
                  <span className="service-status">
                    {hasKey ? <FaCheckCircle /> : ''}
                  </span>
                </span>

                <button
                  className="add-update-btn"
                  onClick={(e) => {
                    e.stopPropagation(); 
                    onAddOrUpdate(service);
                  }}
                  disabled={isLimitReached}
                >
                  {hasKey ? 'Update' : 'Add'}
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default ServiceDropdown;
