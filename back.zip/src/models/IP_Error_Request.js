// src/models/IP_Error_Request.js

const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const IP_Error_Request = sequelize.define('IP_Error_Request', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  ipAddress: { // Store the IP address
    type: DataTypes.STRING,
    allowNull: false,
  },
  error: {
    type: DataTypes.TEXT, // Store full error stack or message
    allowNull: false,
  },
  createdAt: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW,
  },
}, {
  tableName: 'ip_error_requests',
  timestamps: false,
  indexes: [
    {
      fields: ['ipAddress'],
    },
  ],
});

module.exports = IP_Error_Request;
