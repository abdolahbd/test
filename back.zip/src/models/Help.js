// src/models/Help.js

const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./User');

const Help = sequelize.define('Help', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  user_id: { // Foreign key to User
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'users', // Ensure that 'users' matches your Users table
      key: 'id',
    },
    onDelete: 'CASCADE',
  },
  text: { // JSON string representing an array of help messages
    type: DataTypes.TEXT,
    allowNull: false,
  },
  timestamp: { 
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW,
  },
}, {
  tableName: 'helps',
  timestamps: false, 
});

// Define association: Help belongs to User
Help.belongsTo(User, { foreignKey: 'user_id' });
User.hasMany(Help, { foreignKey: 'user_id' });

module.exports = Help;
