// routes/clicks.js

const express = require('express');
const router = express.Router();
const clicksController = require('../controllers/clicksController');
const auth = require('../middleware/auth'); // Authentication middleware
const Noauth = require('../middleware/NoAuth');

/**
 * @route   POST /api/clicks
 * @desc    Record click counts for the authenticated user
 * @access  Private
 */

if (process.env.LMARHALA==0) {
    router.post('/', Noauth, clicksController.recordClicks);
    router.get('/', Noauth, clicksController.getUserClicks);

}

else {
    router.post('/', auth, clicksController.recordClicks);
    router.get('/', auth, clicksController.getUserClicks);

}







module.exports = router;
