// migrations/xxxxxx-alter-user-apikey.js

'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('Users', 'apiKey', {
      type: Sequelize.TEXT,
      allowNull: true,
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('Users', 'apiKey', {
      type: Sequelize.STRING(191),
      allowNull: true,
    });
  }
};
