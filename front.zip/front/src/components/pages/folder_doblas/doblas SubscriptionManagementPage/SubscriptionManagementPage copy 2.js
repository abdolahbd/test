// src/components/pages/SubscriptionManagementPage.js

import React, { useEffect, useState,useContext } from 'react';
import api from '../../services/apiService';
import { useNavigate} from 'react-router-dom';
import { loadStripe } from '@stripe/stripe-js';
import './SubscriptionManagementPage.css';
import { AuthContext } from '../../contexts/AuthContext';

const stripePromise = loadStripe(process.env.REACT_APP_STRIPE);

const SubscriptionManagementPage = () => {
  const [subscription, setSubscription] = useState(null);
  const [hasRecorded, setHasRecorded] = useState(false);
  const [loading, setLoading] = useState(true); // New state to manage loading
  const [loadingSubscriptionAndCancel, setLoadingSubscriptionAndCancel] = useState(false);
  const [error, setError] = useState(null); // New state to manage errors

  const { user } = useContext(AuthContext);
  const [invoices, setInvoices] = useState([]);

  const navigate = useNavigate();






  useEffect(() => {
    const fetchInvoices = async () => {
      try {
        const response = await api.get('/user/invoices'); 
        console.log(response.data);
        setInvoices(response.data);
      } catch (error) {
        console.error('Error fetching invoices:', error);
      } finally {
        setLoading(false);
      }
    };

    if (user) {
      fetchInvoices();
    }
  }, [user]);






  useEffect(() => {
    const fetchSubscription = async () => {
      try {
        const response = await api.get('/subscription');
        setSubscription(response.data.subscription);
      } catch (err) {
        if (err.response && err.response.status === 404) {
          // If backend still returns 404, treat as no subscription
          setSubscription(null);
        } else {
          console.error('Error fetching subscription:', err);
          setError('Failed to load subscription data.');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchSubscription();
  }, []);

  useEffect(() => {
    const recordVisit = async () => {
      try {
        if (!hasRecorded) {
          await api.post('/subscription/record-subscription-page-visit');
          setHasRecorded(true);
        }
      } catch (err) {
        console.error('Error recording subscription page visit:', err);
      }
    };

    recordVisit();
  }, [hasRecorded]);

  const handleCancelSubscription = async () => {
    if (window.confirm('Are you sure you want to cancel your subscription?')) {
      // Prompt the user for a cancellation reason
      const reason = window.prompt('Please enter your reason for cancellation:', '');
      // If user doesn't click "Cancel" on the prompt (meaning reason !== null),
      // proceed with the cancellation call.
      if (reason !== null) {
        try {
          setLoadingSubscriptionAndCancel(true)
          // Send reason to backend
          await api.post('/subscription/cancel', { reason });

          setLoadingSubscriptionAndCancel(false)
          alert('Your subscription has been scheduled for cancellation.');
          // Refresh the subscription status
          const updatedSubscription = await api.get('/subscription');
          setSubscription(updatedSubscription.data.subscription);
        } catch (err) {
          console.error('Error cancelling subscription:', err);
          alert('Failed to cancel subscription. Please try again.');
        }
      }
    }
  };

  const handleSubscribe = async () => {
    try {
      console.log('setLoadingSubscriptionAndCancel(true)');
      
      setLoadingSubscriptionAndCancel(true)
      // Call backend to create the Checkout Session
      const response = await api.post('/payment/create-checkout-session');
      setLoadingSubscriptionAndCancel(false)

      const { sessionId } = response.data;

      const stripe = await stripePromise;
      // Redirect to Stripe Checkout
      await stripe.redirectToCheckout({ sessionId });
    } catch (err) {
      console.error('Error during subscription:', err);
      alert('Failed to initiate subscription process. Please try again.');
    }
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  // If subscription is null, user has no subscription
  if (!subscription) {
    return (
      <div>
        {loadingSubscriptionAndCancel && (
      <div className="loading-subscription-cancel">
                {/* <div className="spinner"></div> */}
                loading aritdwaaar
      </div>
    )}
        <h1>Upgrade Your Account------------</h1>
        <button onClick={handleSubscribe}>Subscribe Now</button>
      </div>
    );
  }

  const { status, cancelAtPeriodEnd, endDate } = subscription;

  return (
    
    <div>
      
      <h1>Manage Your Subscription</h1>
      {loadingSubscriptionAndCancel && (
      <div className="loading-subscription-cancel">
                {/* <div className="spinner"></div> */}
                loading aritdwaaar
      </div>
    )}
      {status === 'active' && cancelAtPeriodEnd && endDate ? (
        <div>
          <p>
            Your subscription is scheduled to be canceled on{' '}
            {new Date(endDate).toLocaleDateString('en-GB')}.
          </p>
          <p>You can continue to use our services until then.</p>
        </div>
      ) : status === 'active' ? (
        <div>
          <p>Status: Active</p>
          <button onClick={handleCancelSubscription}>Cancel Subscription</button>
        </div>
      ) : status === 'canceled' ? (
        <div>
          <h1>Upgrade Your Account-----------------</h1>
          <button onClick={handleSubscribe}>Subscribe Now</button>
        </div>
      ) : (
        <div>
          <p>Status: {status==='incomplete'?'active':status}</p>
          {status !== 'canceled' && (
            <button onClick={handleCancelSubscription}>Cancel Subscription</button>
          )}
        </div>
      )}












<div className="payment-history-page">
      <h2>Payment History</h2>
      {invoices.length === 0 ? (
        <p>No invoices found.</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Invoice Date</th>
              {/* Removed Amount Due header */}
              <th>Amount Paid</th>
              <th>Status</th>
              <th>PDF</th>
            </tr>
          </thead>
          <tbody>
            {invoices.map((invoice) => (
              <tr key={invoice.id}>
                <td>{new Date(invoice.invoiceDate).toLocaleDateString('en-GB')}</td>
                {/* Removed Amount Due cell */}
                <td>${invoice.amountPaid.toFixed(2)}</td>
                <td>{invoice.status}</td>
                <td>
                  {invoice.pdfUrl ? (
                    <a href={invoice.pdfUrl} target="_blank" rel="noopener noreferrer">
                      Download PDF
                    </a>
                  ) : (
                    'No PDF available'
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>

    </div>
  );
};

export default SubscriptionManagementPage;
