// src/components/pages/GoogleAuthSuccess.js

import React, { useEffect, useContext, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { AuthContext } from '../../contexts/AuthContext';
import api from '../../services/apiService';
import { jwtDecode } from 'jwt-decode';
import CryptoJS from 'crypto-js';

/* ========= SECURE LOCALSTORAGE LOGIC ========== */
const encryptionKey = process.env.REACT_APP_ENCRYPTION_KEY;
const encryptionEnabledFlag = process.env.REACT_APP_ENCRYPTION_ENABLED === '1';

function maybeHashKey(key) {
  if (encryptionEnabledFlag) {
    return CryptoJS.SHA256(key).toString();
  } else {
    return key;
  }
}

const encryptLocalData = (plainText) => {
  if (!encryptionKey) {
    throw new Error('Encryption key is missing. Please set REACT_APP_ENCRYPTION_KEY in your .env file.');
  }
  return CryptoJS.AES.encrypt(plainText, encryptionKey).toString();
};

const decryptLocalData = (cipherText) => {
  if (!encryptionKey) {
    throw new Error('Encryption key is missing. Please set REACT_APP_ENCRYPTION_KEY in your .env file.');
  }
  const bytes = CryptoJS.AES.decrypt(cipherText, encryptionKey);
  return bytes.toString(CryptoJS.enc.Utf8);
}

const secureLocalStorage = {
  setItem: (key, value) => {
    if (!key) return;
    const storageKey = maybeHashKey(key);

    if (encryptionEnabledFlag) {
      const encryptedValue = encryptLocalData(value);
      localStorage.setItem(storageKey, encryptedValue);
    } else {
      localStorage.setItem(storageKey, value);
    }
  },
  getItem: (key) => {
    if (!key) return null;
    const storageKey = maybeHashKey(key);
    const storedValue = localStorage.getItem(storageKey);
    if (!storedValue) return null;

    if (encryptionEnabledFlag) {
      try {
        return decryptLocalData(storedValue);
      } catch (err) {
        console.error('Failed to decrypt localStorage value:', err);
        return null;
      }
    } else {
      return storedValue;
    }
  },
  removeItem: (key) => {
    if (!key) return;
    const storageKey = maybeHashKey(key);
    localStorage.removeItem(storageKey);
  },
  clear: () => {
    localStorage.clear();
  },
};
/* ============================================= */

const GoogleAuthSuccess = () => {
  const { search } = useLocation();
  const navigate = useNavigate();
  const { setUser } = useContext(AuthContext);

  // 1. Parse the key map from .env (unchanged)
  const serviceKeyMap = process.env.REACT_APP_SERVICE_KEY_MAP
    ? JSON.parse(process.env.REACT_APP_SERVICE_KEY_MAP)
    : {};

  // 2. Add a local state flag to prevent multiple POSTs
  const [hasSavedKeys, setHasSavedKeys] = useState(false);

  useEffect(() => {
    if (hasSavedKeys) return;

    const query = new URLSearchParams(search);
    const token = query.get('token');

    if (token) {
      // Replace localStorage with secureLocalStorage
      secureLocalStorage.setItem('token', token);

      api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      const decoded = jwtDecode(token);
      setUser(decoded);

      // Gather any existing API keys from localStorage according to serviceKeyMap
      const collectedKeys = {};
      Object.entries(serviceKeyMap).forEach(([serviceName, storageKey]) => {
        const val = secureLocalStorage.getItem(storageKey);
        if (val) {
          collectedKeys[storageKey] = val;
        }
      });

      if (Object.keys(collectedKeys).length > 0) {
        api
          .post('/auth/google/save-keys', { apiKeys: collectedKeys })
          .then(() => {
            // Remove them from localStorage
            Object.values(serviceKeyMap).forEach((keyName) => {
              secureLocalStorage.removeItem(keyName);
            });
            setHasSavedKeys(true);
            navigate('/chat');
          })
          .catch((err) => {
            console.error('Failed to save API keys:', err);
            setHasSavedKeys(true);
            navigate('/chat');
          });
      } else {
        setHasSavedKeys(true);
        navigate('/chat');
      }
    } else {
      navigate('/login');
    }
  }, [search, navigate, setUser, serviceKeyMap, hasSavedKeys]);

  return <div>Logging in...</div>;
};

export default GoogleAuthSuccess;
