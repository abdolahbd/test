// src/components/common/ConversationsSection.js

import React from 'react';
import ConversationItem from './ConversationItem';
import { IoIosArrowDropdown, IoIosArrowDropup } from "react-icons/io";

const ConversationsSection = ({
  conversations,
  displayedConversations,
  setDisplayedConversations,
  isConversationsCollapsed,
  toggleConversationsCollapse,
  currentConversation,
  isLimitReached,
  favoriteConversations,
  toggleFavoriteConversation,
  handleDeleteConversation,
  handleExportSingleConversation,
  openRenameConversationModal,
  handleSelectConversation,
}) => {
  return (
    <div className="sidebar-section conversations-section">
      <div className="conversations-header" onClick={toggleConversationsCollapse}>
        <h2 className='section-collapse'>
          <span>💎 Conversations</span>
          <span className='section-collapse-icon'>
            {isConversationsCollapsed ? <IoIosArrowDropdown /> : <IoIosArrowDropup />}
          </span>
        </h2>
      </div>

      {/* Smooth expand/collapse for the entire conversations list */}
      <div className={`conversations-container ${isConversationsCollapsed ? 'collapsed' : 'open'}`}>
        {conversations.length > 0 ? (
          <>
            <ul className="conversation-list">
              {conversations.slice(0, displayedConversations).map((convo, index) => (
                <ConversationItem
                  key={convo.id}
                  convo={convo}
                  isActive={currentConversation && currentConversation.id === convo.id}
                  isLimitReached={isLimitReached && index >= 3}
                  favoriteConversations={favoriteConversations}
                  toggleFavoriteConversation={toggleFavoriteConversation}
                  openRenameConversationModal={openRenameConversationModal}
                  handleDeleteConversation={handleDeleteConversation}
                  handleExportSingleConversation={handleExportSingleConversation}
                  handleSelectConversation={() => handleSelectConversation(convo, index)}
                />
              ))}
            </ul>

            {displayedConversations < conversations.length && (
              <button
                onClick={() => setDisplayedConversations((prev) => prev + 7)}
                className="btn load-more-btn"
              >
                Load More
              </button>
            )}
          </>
        ) : (
          <p className="no-conversations-message">No conversations available.</p>
        )}
      </div>
    </div>
  );
};

export default ConversationsSection;
