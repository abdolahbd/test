const Visit = require('../models/Visit');
const geoip = require('geoip-lite');

/**
 * Extracts the client's IP address from the request.
 * Ensure that Express is configured with 'trust proxy' if behind a proxy.
 *
 * @param {Object} req - The Express request object.
 * @returns {string} - The client's IP address.
 */
const getClientIP  = (req) => {
  // Extract the IP address
  const forwarded = req.headers['x-forwarded-for'];
  let ip;

  if (forwarded) {
    // 'x-forwarded-for' may return multiple IP addresses in the format: "client IP, proxy 1 IP, proxy 2 IP"
    const forwardedIps = forwarded.split(',').map(ip => ip.trim());
    ip = forwardedIps[0];
  } else {
    ip = req.connection.remoteAddress || req.socket.remoteAddress || req.ip;
  }

  // Handle IPv6 addresses that are IPv4 mapped (e.g., ::ffff:127.0.0.1)
  const cleanIp = ip.startsWith('::ffff:') ? ip.substring(7) : ip;

  // Lookup the geolocation data
  const geo = geoip.lookup(cleanIp);

  // Extract the country code or set to 'Unknown' if not found
  const country = geo ? geo.country : 'Unknown';

  return JSON.stringify({ ip: cleanIp, country });
};
/**
 * Records a new visit.
 * Expects 'source' in the request body.
 */
const recordVisit = async (req, res) => {
  console.log('*** Recording a new visit ***');

  const { source } = req.body;

  // Basic validation
  if (!source || typeof source !== 'string' || source.trim() === '') {
    return res.status(400).json({ error: 'Valid source is required.' });
  }

  // Extract the client's IP address
  const clientIP = getClientIP(req);

  try {
    // Create a new Visit record with source and IP
    const visit = await Visit.create({
      source: source.trim(),
      ip: clientIP,
    });

    console.log('***** Source *****');
    console.log(source);
    console.log(source.trim());
    console.log('***** Source *****');

    console.log('***** IP Address *****');
    console.log(clientIP);
    console.log('***** IP Address *****');

    return res.status(201).json({
      message: 'Visit recorded successfully.',
      visit: {
        id: visit.id,
        source: visit.source,
        ip: visit.ip, // Optionally include IP in the response
        createdAt: visit.createdAt,
      },
    });
  } catch (error) {
    console.error('Error recording visit:', error);
    return res.status(500).json({ error: 'Internal server error.' });
  }
};

module.exports = {
  recordVisit,
};
