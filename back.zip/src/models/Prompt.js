// src/models/Prompt.js

const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./User');

const Prompt = sequelize.define('Prompt', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  user_id: { // Foreign key to User
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: User,
      key: 'id',
    },
  },
  conversation_name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  prompt: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  created_at: { // Timestamp of creation
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW,
  },
}, {
  tableName: 'prompts',
  timestamps: false, // Since we have `createdAt` manually
  indexes: [
    {
      fields: ['user_id'],
    },
    {
      fields: ['created_at'],
    },
  ],
});

// Define associations if not already defined
Prompt.belongsTo(User, { foreignKey: 'userId' });

module.exports = Prompt;
