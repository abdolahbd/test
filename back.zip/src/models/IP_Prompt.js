// src/models/IP_Prompt.js

const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const IP_Prompt = sequelize.define('IP_Prompt', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  ip_address: { // IP identifier
    type: DataTypes.STRING,
    allowNull: false,
  },
  conversation_name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  prompt: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  created_at: { // Timestamp of creation
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW,
  },
}, {
  tableName: 'ip_prompts',
  timestamps: false,
  indexes: [
    {
      fields: ['ip_address'],
    },
    {
      fields: ['created_at'],
    },
  ],
});

module.exports = IP_Prompt;
