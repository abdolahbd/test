// src/routes/user.js
const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Subscription = require('../models/Subscription');
const userController = require('../controllers/userController');
const Noauth = require('../middleware/NoAuth');
const { Op } = require('sequelize');
const apiKeyController = require('../controllers/apiKeyController');

router.get('/subscription-status', auth, async (req, res) => {
  try {
    const subscription = await Subscription.findOne({
       where: { user_id: req.user.id,
        status: { [Op.in]: ['active','incomplete'] }
      },
      order: [['createdAt', 'DESC']],
      
      });

    
    const active = subscription && (subscription.status === 'active' || subscription.status === 'incomplete');
    res.json({ active });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch subscription status' });
  }
});



if (process.env.LMARHALA==0) {
  router.get('/userStatus', Noauth, userController.getUserStatus);
}

else {
  router.get('/userStatus', auth, userController.getUserStatus);
}


// Check if the authenticated user has an API key
router.get('/apiKeyStatus', auth, userController.getApiKeyStatus);

// Set or update the authenticated user's API key
router.post('/apiKey', auth, userController.setApiKey);



router.get('/invoices', auth, userController.getUserInvoices);


router.post('/api-keys-non-auth', Noauth, apiKeyController.saveApiKeys);


module.exports = router;
