// src/utils/obfuscate.js

import { parse } from '@babel/parser';
import traverse from '@babel/traverse';
import generate from '@babel/generator';

/**
 * Generates a random string to replace variable names
 */
const generateRandomName = (() => {
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
  return () => {
    let name = '';
    const length = Math.floor(Math.random() * 5) + 3; // Variable names between 3-7 chars
    for (let i = 0; i < length; i++) {
      name += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return name;
  };
})();

/**
 * Obscures JavaScript variable names in the given code string.
 * It parses the JS code, renames variables, and returns the transformed code.
 * 
 * @param {string} jsCode - The JavaScript code to obfuscate.
 * @returns {string} - The obfuscated JavaScript code.
 */
const obscureJavaScript = (jsCode) => {
  // Parse the JavaScript code into an AST
  const ast = parse(jsCode, {
    sourceType: 'module',
    plugins: ['jsx', 'typescript'], // Add other plugins if needed
  });

  const varNameMap = {};

  traverse(ast, {
    // Rename variable declarations
    Identifier(path) {
      const { node, scope, parent } = path;

      // Avoid renaming properties and labels
      if (
        parent.type === 'MemberExpression' &&
        path.key === 'property' &&
        !path.parent.computed
      ) {
        return;
      }

      // Only rename if it's a binding identifier (declared variable)
      if (scope.hasBinding(node.name) && !varNameMap[node.name]) {
        const newName = generateRandomName();
        varNameMap[node.name] = newName;
        path.scope.rename(node.name, newName);
      }
    },
  });

  // Generate the transformed code from the AST
  const { code } = generate(ast);
  return code;
};

/**
 * Obscures the entire HTML content by specifically targeting embedded JavaScript.
 * It assumes that JS is within <script> tags and CSS within <style> tags.
 * Only variable names in JS are obfuscated.
 * 
 * @param {string} htmlContent - The full HTML content as a string.
 * @returns {string} - The obfuscated HTML content.
 */
const obscureHtmlCode = (htmlContent) => {
  // Create a DOMParser instance
  const parser = new DOMParser();
  const doc = parser.parseFromString(htmlContent, 'text/html');

  // Process all <script> tags
  const scripts = Array.from(doc.querySelectorAll('script'));
  scripts.forEach((script) => {
    if (script.src) {
      // If the script is external, skip obfuscation
      return;
    }
    const originalJs = script.textContent;
    if (originalJs.trim() === '') {
      // Skip empty scripts
      return;
    }
    try {
      const obfuscatedJs = obscureJavaScript(originalJs);
      script.textContent = obfuscatedJs;
    } catch (error) {
      console.error('Error obfuscating JavaScript:', error);
      // Optionally, handle the error (e.g., leave the original script)
    }
  });

  // Optionally, process <style> tags if needed

  // Serialize the modified document back to a string
  return '<!DOCTYPE html>\n' + doc.documentElement.outerHTML;
};

export default obscureHtmlCode;
