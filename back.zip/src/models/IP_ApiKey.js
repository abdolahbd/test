// src/models/IP_ApiKey.js

const { DataTypes } = require('sequelize');
const sequelize = require('../config/database'); // Adjust the path as needed

const IP_ApiKey = sequelize.define('IP_ApiKey', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  ip: { 
    type: DataTypes.STRING(45),
    allowNull: false,
    unique: true, // Ensures one record per IP
  },
  api_keys: { // JSON object representing API key statuses
    type: DataTypes.JSON,
    allowNull: false,
  },
  created_at: { 
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW,
  },
}, {
  tableName: 'ip_api_key',
  timestamps: false, 
});

module.exports = IP_ApiKey;
