// SubscriptionManagementPage.js
import React, { useEffect, useState, useContext } from 'react';
import api from '../../services/apiService';
import { useNavigate } from 'react-router-dom';
import { loadStripe } from '@stripe/stripe-js';
import './SubscriptionManagementPage.css';
import { AuthContext } from '../../contexts/AuthContext';
import { FaTools, FaLightbulb, FaExchangeAlt, FaFolderOpen, FaStar } from 'react-icons/fa';

const stripePromise = loadStripe(process.env.REACT_APP_STRIPE);

const SubscriptionManagementPage = ({ onClose }) => {
  const [subscription, setSubscription] = useState(null);
  const [hasRecorded, setHasRecorded] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadingSubscriptionAndCancel, setLoadingSubscriptionAndCancel] = useState(false);
  const [error, setError] = useState(null);

  const { user } = useContext(AuthContext);
  const [invoices, setInvoices] = useState([]);

  const navigate = useNavigate();

  // State for active tab
  const [activeTab, setActiveTab] = useState('subscription');

  // States for modals
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showPromptModal, setShowPromptModal] = useState(false);
  const [cancellationReason, setCancellationReason] = useState('');

  useEffect(() => {
    const fetchInvoices = async () => {
      try {
        const response = await api.get('/user/invoices'); 
        setInvoices(response.data);
      } catch (error) {
        console.error('Error fetching invoices:', error);
      } finally {
        setLoading(false);
      }
    };

    if (user) {
      fetchInvoices();
    }
  }, [user]);

  useEffect(() => {
    const fetchSubscription = async () => {
      try {
        const response = await api.get('/subscription');
        setSubscription(response.data.subscription);
      } catch (err) {
        if (err.response && err.response.status === 404) {
          setSubscription(null);
        } else {
          console.error('Error fetching subscription:', err);
          setError('Failed to load subscription data.');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchSubscription();
  }, []);

  useEffect(() => {
    const recordVisit = async () => {
      try {
        if (!hasRecorded) {
          await api.post('/subscription/record-subscription-page-visit');
          setHasRecorded(true);
        }
      } catch (err) {
        console.error('Error recording subscription page visit:', err);
      }
    };

    recordVisit();
  }, [hasRecorded]);

  const handleCancelSubscription = () => {
    setShowConfirmModal(true);
  };

  const confirmCancel = () => {
    setShowConfirmModal(false);
    setShowPromptModal(true);
  };

  const cancelCancel = () => {
    setShowConfirmModal(false);
  };

  const submitCancellation = async () => {
    // if (cancellationReason.trim() === '') {
    //   alert('Please enter a reason for cancellation.');
    //   return;
    // }

    try {
      setLoadingSubscriptionAndCancel(true);
      await api.post('/subscription/cancel', { reason: cancellationReason });
      // After successful cancellation
      alert('Your subscription has been scheduled for cancellation.');
      const updatedSubscription = await api.get('/subscription');
      setSubscription(updatedSubscription.data.subscription);
      setShowPromptModal(false);
      setCancellationReason('');
      setLoadingSubscriptionAndCancel(false);
    } catch (err) {
      console.error('Error cancelling subscription:', err);
      alert('Failed to cancel subscription. Please try again.');
      setLoadingSubscriptionAndCancel(false);
      setShowPromptModal(false);
    }
  };

  const handleSubscribe = async () => {
    try {
      setLoadingSubscriptionAndCancel(true);
      const response = await api.post('/payment/create-checkout-session');
      const { sessionId } = response.data;
      const stripe = await stripePromise;
      await stripe.redirectToCheckout({ sessionId });
    } catch (err) {
      console.error('Error during subscription:', err);
      alert('Failed to initiate subscription process. Please try again.');
      setLoadingSubscriptionAndCancel(false);
    }
  };


  if (loading) {
    // if (true) {
    return (
      <div className="subscription-management-container">
        <div className="loading-subscription-cancel">
          Loading...
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="subscription-management-container">
        <p>Error: {error}</p>
      </div>
    );
  }

  // Determine if payment history tab should be shown
  const showPaymentHistory = invoices.length > 0;

  // Inline Styles for Confirmation and Prompt Modals
  const modalOverlayStyle = {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    background: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
    backdropFilter: 'blur(5px)',
    padding: '10px',
    height: 'fit-content',
  };

  const modalContentStyle = {
    background: '#fff',
    padding: '30px',
    borderRadius: '12px',
    maxWidth: '500px',
    width: '100%',
    boxShadow: '0 4px 20px rgba(0, 0, 0, 0.2)',
    animation: 'fadeIn 0.3s ease-in-out',
    position: 'relative',
  };

  const modalButtonsContainerStyle = {
    display: 'flex',
    justifyContent: 'flex-end',
    marginTop: '20px',
    gap: '10px',
  };

  const confirmButtonStyle = {
    padding: '10px 20px',
    backgroundColor: '#d9534f', // Bootstrap's danger color
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontWeight: '600',
    transition: 'background-color 0.3s ease',
  };

  const cancelButtonStyle = {
    padding: '10px 20px',
    backgroundColor: '#6c757d', // Bootstrap's secondary color
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontWeight: '600',
    transition: 'background-color 0.3s ease',
  };

  const submitButtonStyle = {
    padding: '10px 20px',
    backgroundColor: '#28a745', // Bootstrap's success color
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontWeight: '600',
    transition: 'background-color 0.3s ease',
  };

  const textareaStyle = {
    width: '100%',
    padding: '10px',
    borderRadius: '6px',
    border: '1px solid #ced4da',
    resize: 'vertical',
    fontSize: '1em',
  };
  
  const xButtonStyle = {
    position: 'absolute',
    top: '-36px',
    right: '0px',
    background: 'transparent',
    border: 'none',
    fontSize: '1.5rem',
    cursor: 'pointer',
    color: 'white',
    zIndex: 1001,
    transition: 'color 0.3s ease',
  };

  const xButtonHoverStyle = {
    color: '#000',
  };

  return (
    <div className="subscription-management-container">

      {/* "X" Button to Close Modal */}
      <button
        onClick={onClose}
        style={xButtonStyle}
        onMouseOver={(e) => e.currentTarget.style.color = xButtonHoverStyle.color}
        onMouseOut={(e) => e.currentTarget.style.color = xButtonStyle.color}
        aria-label="Close Modal"
      >
        &times;
      </button>

      {/* Tabs Navigation */}
      <div className="tabs">
        <button
          className={`tab ${activeTab === 'subscription' ? 'active' : ''}`}
          onClick={() => setActiveTab('subscription')}
        >
          Subscription Status
        </button>
        {showPaymentHistory && (
          <button
            className={`tab ${activeTab === 'paymentHistory' ? 'active' : ''}`}
            onClick={() => setActiveTab('paymentHistory')}
          >
            Payment History
          </button>
        )}
      </div>

      {/* Tab Content */}
      <div className="tab-content">
        {activeTab === 'subscription' && (
          <div className="subscription-content">
            {loadingSubscriptionAndCancel ? (
              <div className="loading-subscription-cancel">
                Loading...
              </div>
            ) : subscription ? (
              <div>
                {subscription.status === 'active' && subscription.cancelAtPeriodEnd && subscription.endDate ? (
                  <div>
                    <p>
                      Your subscription is scheduled to be canceled on{' '}
                      {new Date(subscription.endDate).toLocaleDateString('en-GB')}.
                    </p>
                    <p>You can continue to use our services until then.</p>
                  </div>
                ) : subscription.status === 'active' ? (
                  <div>
                    <p>Status: Active</p>
                    <button className="cancel-button" onClick={handleCancelSubscription}>
                      Cancel Subscription
                    </button>
                  </div>
                ) : subscription.status === 'canceled' ? (
                  <div>
                    <h2>Upgrade Your Account</h2>
                    <button onClick={handleSubscribe}>Subscribe Now</button>
                  </div>
                ) : (
                  <div>
                    <p>Status: {subscription.status === 'incomplete' ? 'Active' : subscription.status}</p>
                    {subscription.status !== 'canceled' && (
                      <button className="cancel-button" onClick={handleCancelSubscription}>
                        Cancel Subscription
                      </button>
                    )}
                  </div>
                )}
              </div>
            ) : (
              <div>
                <h2>Upgrade Your Account</h2>
                {/* Pro Plan Section */}
                <div className="pro-plan">
                  <div className="pro-plan-header">
                    <h3>Pro Plan</h3>
                    <div className="pro-plan-price">               
                      <span className="price-amount"><span className="dollar-sign">$</span>24</span>
                      <span className="per-month">per month</span>
                    </div>
                  </div>
                  <ul className="pro-plan-features">
                    <li>
                      <FaTools className="feature-icon" />
                      Unlimited tools creation
                    </li>
                    <li>
                      <FaLightbulb className="feature-icon" />
                      Unlimited prompts
                    </li>
                    <li>
                      <FaExchangeAlt className="feature-icon" />
                      Unlimited exports/imports
                    </li>
                    <li>
                      <FaFolderOpen className="feature-icon" />
                      Unlimited folders/files
                    </li>
                    <li>
                      <FaStar className="feature-icon" />
                      Access to all future features and updates
                    </li>
                  </ul>
                  <div className='subscribe-button-container'>
                    <button onClick={handleSubscribe} className="subscribe-button">Subscribe Now</button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'paymentHistory' && showPaymentHistory && (
          <div className="payment-history-content">
            <h2>Payment History</h2>
            {invoices.length === 0 ? (
              <p>No invoices found.</p>
            ) : (
              <ul className="payment-history-list">
                {invoices.map((invoice) => (
                  <li key={invoice.id} className="invoice-item">
                    <div className="invoice-details">
                      <div className="invoice-date">
                        <strong>Invoice Date:</strong> {new Date(invoice.invoiceDate).toLocaleDateString('en-GB')}
                      </div>
                      <div className="invoice-amount">
                        <strong>Amount Paid:</strong> ${invoice.amountPaid.toFixed(2)}
                      </div>
                      <div className="invoice-status">
                        <strong>Status:</strong> {invoice.status}
                      </div>
                    </div>
                    <div className="invoice-pdf">
                      {invoice.pdfUrl ? (
                        <a href={invoice.pdfUrl} target="_blank" rel="noopener noreferrer">
                          Download PDF
                        </a>
                      ) : (
                        'No PDF available'
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
      </div>

      {/* Confirm Cancellation Modal */}
      {showConfirmModal && (
        <div style={modalOverlayStyle}>
          <div style={modalContentStyle}>
            <p style={{ fontSize: '1.1em', color: '#333' }}>Are you sure you want to cancel your subscription?</p>
            <div style={modalButtonsContainerStyle}>
              <button
                onClick={confirmCancel}
                style={confirmButtonStyle}
                onMouseOver={(e) => e.target.style.backgroundColor = '#c9302c'}
                onMouseOut={(e) => e.target.style.backgroundColor = '#d9534f'}
              >
                Yes
              </button>
              <button
                onClick={cancelCancel}
                style={cancelButtonStyle}
                onMouseOver={(e) => e.target.style.backgroundColor = '#5a6268'}
                onMouseOut={(e) => e.target.style.backgroundColor = '#6c757d'}
              >
                No
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Prompt for Cancellation Reason Modal */}
      {showPromptModal && (
        <div style={modalOverlayStyle}>
          <div style={modalContentStyle}>          
            {loadingSubscriptionAndCancel ? (
              <div className="loading-subscription-cancel">
                Loading...
              </div>
            ) : (
              <>
                <p style={{ fontSize: '1.1em', color: '#333' }}>Please enter your reason for cancellation:</p>
                <textarea
                  value={cancellationReason}
                  onChange={(e) => setCancellationReason(e.target.value)}
                  rows="4"
                  style={textareaStyle}
                  placeholder="Your reason..."
                />
                <div style={modalButtonsContainerStyle}>
                  <button
                    onClick={submitCancellation}
                    style={submitButtonStyle}
                    onMouseOver={(e) => e.target.style.backgroundColor = '#218838'}
                    onMouseOut={(e) => e.target.style.backgroundColor = '#28a745'}
                  >
                    Submit
                  </button>
                  <button
                    onClick={() => setShowPromptModal(false)}
                    style={cancelButtonStyle}
                    onMouseOver={(e) => e.target.style.backgroundColor = '#5a6268'}
                    onMouseOut={(e) => e.target.style.backgroundColor = '#6c757d'}
                  >
                    Cancel
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default SubscriptionManagementPage;
