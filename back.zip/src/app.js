// src/app.js
const express = require('express');
const app = express();
const session = require('express-session');
const passport = require('./config/passport');
const authRoutes = require('./routes/auth');
const requestRoutes = require('./routes/request');
const paymentRoutes = require('./routes/payment');
const webhookRoutes = require('./routes/webhook');
const subscriptionRoutes = require('./routes/subscription');
const userRoutes = require('./routes/user');
const clicksRoutes = require('./routes/clicks');
const reviewsRoutes = require('./routes/reviews');
const helpsRoutes = require('./routes/helps');
const visitRoutes = require('./routes/visit');





app.set('trust proxy', true);






const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');

// Security and logging middleware
app.use(helmet());
app.use(cors());

app.use(morgan('combined'));

// Configure session middleware
app.use(
  session({
    secret: process.env.SESSION_SECRET || 'your_session_secret', // Add SESSION_SECRET to your .env file
    resave: false,
    saveUninitialized: false,
  })
);

// Initialize Passport and restore authentication state, if any, from the session
app.use(passport.initialize());
app.use(passport.session());

// Place the webhook route before any body-parser middleware
app.use('/api/v1/webhook', webhookRoutes);

// Body parser middleware (express.json and express.urlencoded)
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Define your routes after body parsing middleware
app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/request', requestRoutes);
app.use('/api/v1/payment', paymentRoutes);
app.use('/api/v1/subscription', subscriptionRoutes);
app.use('/api/v1/user', userRoutes);
app.use('/api/v1/clicks', clicksRoutes);
app.use('/api/v1/reviews', reviewsRoutes);
app.use('/api/v1/helps', helpsRoutes);
app.use('/api/v1/visit', visitRoutes);












const users = [
  { id: 1, name: 'Alice' },
  { id: 2, name: 'Bob' },
];

// Define a GET route
app.get('/users', (req, res) => {
  res.status(200).json(users);
});








module.exports = app;