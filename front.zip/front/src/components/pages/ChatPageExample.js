// src/components/pages/ChatPageExample.js

import React, { useState, useRef, useEffect, useContext } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import api from '../../services/apiService';
import Modal from 'react-modal';
// import './ChatPageExample.css';
import { AuthContext } from '../../contexts/AuthContext';
import ReviewModal from '../Modals/ReviewModal';
import HelpModal from '../Modals/HelpModal';
import ShareModal from '../Modals/ShareModal';
import CryptoJS from 'crypto-js';
import { v4 as uuidv4 } from 'uuid';
import { MdFullscreen } from 'react-icons/md';
import { FaTimes } from 'react-icons/fa';
import { AiFillSketchCircle, AiOutlineCodeSandbox } from "react-icons/ai";
import LogoutButton from '../common/LogoutButton';
import PaymentHistoryPage from './PaymentHistoryPage';


// Encryption key from environment variables
const encryptionKey = process.env.REACT_APP_ENCRYPTION_KEY;

// List of supported services
const supportedServices = JSON.parse(process.env.REACT_APP_SUPPORTED_SERVICES);

// Mapping between service names and backend keys
const serviceKeyMap = JSON.parse(process.env.REACT_APP_SERVICE_KEY_MAP);

const initConv = "<html><head></head><body><script>document.addEventListener('click', () => {parent.postMessage({ type: 'iframe-click' }, '*');});</script></body></html>"

/**
 * Existing AES-based encryption/decryption used for IndexedDB content
 * (unchanged).
 */
const encryptData = (data) => {
  if (!encryptionKey) {
    throw new Error('Encryption key is missing. Please set REACT_APP_ENCRYPTION_KEY in your .env file.');
  }
  return CryptoJS.AES.encrypt(data, encryptionKey).toString();
};

const decryptData = (cipherText) => {
  if (!encryptionKey) {
    throw new Error('Encryption key is missing. Please set REACT_APP_ENCRYPTION_KEY in your .env file.');
  }
  try {
    const bytes = CryptoJS.AES.decrypt(cipherText, encryptionKey);
    const decrypted = bytes.toString(CryptoJS.enc.Utf8);
    if (!decrypted) {
      throw new Error('Decryption failed. Invalid ciphertext or encryption key.');
    }
    return decrypted;
  } catch (error) {
    console.error('Error during decryption:', error);
    throw new Error('Failed to decrypt data.');
  }
};

// ====== NEW: Local Storage Encryption/Hashing Logic ======
const encryptionEnabledFlag = process.env.REACT_APP_ENCRYPTION_ENABLED === '1';

/** If encryption is enabled, hash the key (SHA-256). Otherwise, use plain text. */
function maybeHashKey(key) {
  if (encryptionEnabledFlag) {
    return CryptoJS.SHA256(key).toString(); 
  } else {
    return key;
  }
}

/** Reuse same AES method for localStorage values if encryption is enabled. */
const encryptLocalData = (plainText) => encryptData(plainText);
const decryptLocalData = (cipherText) => decryptData(cipherText);

/** A secureLocalStorage wrapper with minimal changes. */
const secureLocalStorage = {
  setItem: (key, value) => {
    if (!key) return;
    const storageKey = maybeHashKey(key);
    if (encryptionEnabledFlag) {
      // Encrypt the value with AES
      const encryptedValue = encryptLocalData(value);
      localStorage.setItem(storageKey, encryptedValue);
    } else {
      // Store in plain text
      localStorage.setItem(storageKey, value);
    }
  },
  getItem: (key) => {
    if (!key) return null;
    const storageKey = maybeHashKey(key);
    const storedValue = localStorage.getItem(storageKey);
    if (!storedValue) return null;
    if (encryptionEnabledFlag) {
      // Decrypt the value
      try {
        return decryptLocalData(storedValue);
      } catch (err) {
        console.error('Failed to decrypt localStorage value:', err);
        return null;
      }
    } else {
      return storedValue;
    }
  },
  removeItem: (key) => {
    if (!key) return;
    const storageKey = maybeHashKey(key);
    localStorage.removeItem(storageKey);
  },
  clear: () => {
    localStorage.clear();
  }
};
// ====== END NEW LOGIC ======


// IndexedDB utilities (unchanged)
let dbPromise = null;
const initIndexedDB = () => {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const request = window.indexedDB.open('WIA-SIGMANOS-GM-TZ', 2);
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains('files')) {
          db.createObjectStore('files', { keyPath: 'path' });
        }
      };
      request.onsuccess = () => {
        resolve(request.result);
      };
      request.onerror = () => {
        reject(request.error);
      };
    });
  }
  return dbPromise;
};
const dbTransaction = async (storeName, mode) => {
  const db = await initIndexedDB();
  const tx = db.transaction(storeName, mode);
  return tx.objectStore(storeName);
};
const indexedDBGet = async (key) => {
  const store = await dbTransaction('files', 'readonly');
  return new Promise((resolve, reject) => {
    const req = store.get(key);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
};
const indexedDBGetAllKeys = async () => {
  const store = await dbTransaction('files', 'readonly');
  return new Promise((resolve, reject) => {
    const req = store.getAllKeys();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
};
const indexedDBPut = async (record) => {
  const store = await dbTransaction('files', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.put(record);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
};
const indexedDBDelete = async (key) => {
  const store = await dbTransaction('files', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.delete(key);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
};
const indexedDBListByPrefix = async (prefix) => {
  const keys = await indexedDBGetAllKeys();
  return keys.filter(k => k.startsWith(prefix));
};
const readEncryptedFile = async (path) => {
  const record = await indexedDBGet(path);
  if (!record) {
    const err = new Error('NotFoundError');
    err.name = 'NotFoundError';
    throw err;
  }
  const encryptedContent = record.content;
  const decryptedContent = decryptData(encryptedContent);
  return decryptedContent;
};
const writeEncryptedFile = async (path, data) => {
  const encryptedContent = encryptData(data);
  const record = { path, content: encryptedContent };
  await indexedDBPut(record);
};
const conversationFilePath = (conversationId, fileName) => `conversations/${conversationId}/${fileName}`;
const folderFilePath = (folderName, fileName) => `folders/${folderName}/${fileName}`;
const favoritesFilePath = () => `favorites.json`;
const sanitizeFileName = (name) => name.replace(/\s+/g, '_');

const ChatPageExample = () => {

  const { user } = useContext(AuthContext);
  const actualUser = user || { id: "777777777", iat: 1733253711 }; // Fallback for unauthenticated users

  // State management
  const [prompt, setPrompt] = useState('');
  const [messages, setMessages] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [loadingImportLink, setLoadingImportLink] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const [isLimitReached, setIsLimitReached] = useState(false);
  const [currentClickCount, setCurrentClickCount] = useState(0);
  const [clickLimit, setClickLimit] = useState(0);

  const [conversations, setConversations] = useState([]);
  const [currentConversation, setCurrentConversation] = useState(null);

  const fileInputRef = useRef(null);
  const messagesEndRef = useRef(null);
  const iframeRef = useRef(null);
  const uploadFileInputRef = useRef(null);

  const [isCreateFolderModalOpen, setIsCreateFolderModalOpen] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');

  const [isRenameModalOpen, setIsRenameModalOpen] = useState(false);
  const [renameConversation, setRenameConversation] = useState(null);
  const [newConversationName, setNewConversationName] = useState('');

  const [folders, setFolders] = useState([]);
  const [expandedFolders, setExpandedFolders] = useState({});
  const [filesInFolders, setFilesInFolders] = useState({});

  const imagePathToDataURLRef = useRef(new Map());
  const [indexContent, setIndexContent] = useState(initConv);
  const [currentUploadFolder, setCurrentUploadFolder] = useState(null);

  const [isConversationsCollapsed, setIsConversationsCollapsed] = useState(false);
  const [displayedConversations, setDisplayedConversations] = useState(7);

  const [isFoldersCollapsed, setIsFoldersCollapsed] = useState(false);
  const [displayedFolders, setDisplayedFolders] = useState(7);

  const [favoriteConversations, setFavoriteConversations] = useState([]);
  const [isFavoriteAppsCollapsed, setIsFavoriteAppsCollapsed] = useState(false);

  // API Key Management
  // State to hold API key statuses
  const [apiKeyStatus, setApiKeyStatus] = useState(() => {
    // Load from secureLocalStorage if available
    const storedStatus = secureLocalStorage.getItem(`apiKeyStatus_${actualUser.id}`);
    return storedStatus ? JSON.parse(storedStatus) : {};
  });

  // API Key Presence Status (True/False)
  const [hasApiKey, setHasApiKey] = useState(() => {
    return Object.values(apiKeyStatus).some(status => status === true);
  });

  // Initialize selectedService from secureLocalStorage or default to first service
  const [selectedService, setSelectedService] = useState(() => {
    const savedService = secureLocalStorage.getItem('selectedService');
    return supportedServices.includes(savedService) ? savedService : supportedServices[0];
  });

  const [isImportDropdownOpen, setIsImportDropdownOpen] = useState(false);
  const [isImportLinkModalOpen, setIsImportLinkModalOpen] = useState(false);
  const [importUrl, setImportUrl] = useState('');

  const [isDataLoading, setIsDataLoading] = useState(true);

  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const [activeModal, setActiveModal] = useState(null); // 'profile','settings','logout',null

  // References for the profile button and dropdown
  const profileButtonRef = useRef(null);
  const dropdownRef = useRef(null);

  const importLinkInputRef = useRef(null);

  const [isKeyModalOpen, setIsKeyModalOpen] = useState(false);
  const [keyInput, setKeyInput] = useState('');

  const [hasShownReviewModal, setHasShownReviewModal] = useState(() => {
    // Load from secureLocalStorage
    const raw = secureLocalStorage.getItem(`hasShownReviewModal_${actualUser.id}`);
    return raw ? JSON.parse(raw) : false;
  });

  const [reviewModalShow, setreviewModalShow] = useState(false);
  const [helpModalShow, sethelpModalShow] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  const shareUrl = 'https://yobino.com';
  const title = 'Check out this awesome app!';
  const description = 'This app does amazing things. You should definitely try it out!';

  const handleOpenReview = () => setreviewModalShow(true);
  const handleCloseReview = () => setreviewModalShow(false);

  const handleOpenHelp = () => sethelpModalShow(true);
  const handleCloseHelp = () => sethelpModalShow(false);

  const conversationCountRef = useRef(0);
  useEffect(() => {
    conversationCountRef.current = conversations.length;
  }, [conversations.length]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Load existing conversations from IndexedDB
  const loadConversations = async () => {
    try {
      const allKeys = await indexedDBListByPrefix('conversations/');
      const conversationIds = new Set(
        allKeys
          .map(k => {
            const parts = k.split('/');
            return parts.length > 1 ? parts[1] : null;
          })
          .filter(Boolean)
      );

      const convs = [];
      for (const convoId of conversationIds) {
        const convoContent = await readFile('conversation.json', convoId);
        if (!convoContent || !convoContent.trim()) continue;
        try {
          const convoData = JSON.parse(convoContent);
          let shouldInclude = false;
          if (convoData.allowedUsers && convoData.allowedUsers.includes(actualUser.id)) {
            shouldInclude = true;
          } else if (convoData.allowedUsers && convoData.allowedUsers.includes("777777777")) {
            convoData.allowedUsers = convoData.allowedUsers.map(uid =>
              uid === "777777777" ? actualUser.id : uid
            );
            await writeFile('conversation.json', JSON.stringify(convoData, null, 2), convoId);
            shouldInclude = true;
          }

          if (shouldInclude) {
            const lastModified = convoData.lastModified || Date.now();
            convs.push({
              id: convoData.id || convoId,
              name: convoData.name || `Conversation ${convs.length + 1}`,
              lastModified,
            });
          }
        } catch {
          console.warn(`conversation.json malformed for ${convoId}. Skipping.`);
        }
      }

      convs.sort((a, b) => b.lastModified - a.lastModified);
      setConversations(convs);
      setDisplayedConversations(7);
      return convs;
    } catch (err) {
      console.error('Error loading conversations:', err);
      alert('Failed to load conversations.');
      return [];
    }
  };

  // Load folders so only owners see them
  const loadFolders = async () => {
    try {
      const keys = await indexedDBListByPrefix('folders/');
      const folderNames = new Set(keys.map(k => k.split('/')[1]).filter(name => name));
      const folderEntries = [];
      for (const fname of folderNames) {
        const fContent = await readFile('folder.json', null, fname);
        let lastModified = 0;
        let shouldInclude = false;
        if (fContent && fContent.trim()) {
          try {
            const folderData = JSON.parse(fContent);
            lastModified = folderData.lastModified || 0;

            // Check allowedUsers
            if (folderData.allowedUsers && folderData.allowedUsers.includes(actualUser.id)) {
              shouldInclude = true;
            } else if (folderData.allowedUsers && folderData.allowedUsers.includes("777777777")) {
              folderData.allowedUsers = folderData.allowedUsers.map(uid =>
                uid === "777777777" ? actualUser.id : uid
              );
              await writeFile('folder.json', JSON.stringify(folderData, null, 2), null, fname);
              shouldInclude = true;
            } else if (!folderData.allowedUsers) {
              folderData.allowedUsers = [actualUser.id];
              await writeFile('folder.json', JSON.stringify(folderData, null, 2), null, fname);
              shouldInclude = true;
            }
          } catch {
            console.warn(`folder.json malformed for ${fname}`);
          }
        }
        if (shouldInclude) {
          folderEntries.push({
            name: fname,
            lastModified,
          });
        }
      }
      folderEntries.sort((a, b) => b.lastModified - a.lastModified);
      setFolders(folderEntries);
      setDisplayedFolders(7);
    } catch (err) {
      console.error('Error loading folders:', err);
      alert('Failed to load folders.');
    }
  };

  // Simple init
  const handleSelectDirectory = async () => {
    try {
      await initIndexedDB();
      await loadConversations();
    } catch (err) {
      console.error('Error initializing IndexedDB:', err);
      alert('Failed to initialize storage.');
    }
  };
  useEffect(() => {
    handleSelectDirectory();
  }, []);

  // Example create conversation
  const handleCreateConversation = async () => {
    const convoName = window.prompt(
      'Enter a name for the new conversation:',
      `Conversation ${conversations.length + 1}`
    );
    if (!convoName) {
      alert('Conversation name is required.');
      return;
    }
    const invalidChars = /[<>:"/\\|?*\x00-\x1F]/g;
    if (invalidChars.test(convoName)) {
      alert('Conversation name contains invalid characters.');
      return;
    }
    try {
      const nameExists = conversations.some(convo => convo.name === convoName);
      if (nameExists) {
        alert('A conversation with this name already exists.');
        return;
      }
      const uniqueId = uuidv4();
      const conversationData = {
        id: uniqueId,
        name: convoName,
        allowedUsers: [actualUser.id],
        messages: [],
        lastModified: Date.now(),
      };
      await writeFile('conversation.json', JSON.stringify(conversationData, null, 2), uniqueId);
      const newConversation = { id: uniqueId, name: convoName, lastModified: Date.now() };
      setConversations((prev) => [newConversation, ...prev]);
      setCurrentConversation(newConversation);
      setMessages([]);
      setIndexContent(initConv);
      alert(`Conversation "${convoName}" created successfully.`);
    } catch (err) {
      console.error('Error creating conversation:', err);
      alert('Failed to create conversation.');
    }
  };

  // Load one conversation
  const handleLoadConversation = async (conversation) => {
    setIsDataLoading(false);
    try {
      const convoContent = await readFile('conversation.json', conversation.id);
      if (!convoContent || !convoContent.trim()) {
        alert('Conversation not found or malformed.');
        return;
      }
      const convoData = JSON.parse(convoContent);
      if (!convoData.allowedUsers || !convoData.allowedUsers.includes(actualUser.id)) {
        alert('You are not authorized to access this conversation.');
        return;
      }
      const loadedMessages = convoData.messages;
      if (!Array.isArray(loadedMessages)) {
        throw new Error('Invalid conversation format.');
      }
      const mappedMessages = loadedMessages.map((msg) => {
        if (msg.sender === 'assistant') {
          return { ...msg, displayContent: msg.content };
        }
        return { ...msg, displayContent: msg.content };
      });
      setIndexContent(initConv);
      setMessages(mappedMessages);
      setCurrentConversation(conversation);
      setError(null);
      await getConversationIndexContent(conversation);
    } catch (err) {
      console.error('Error loading conversation:', err);
      alert('Failed to load conversation.');
      setIndexContent(initConv);
    }
  };

  // Minimal iFrame content loading
  const getConversationIndexContent = async (conversation) => {
    if (!conversation) {
      setIndexContent(initConv);
      return;
    }
    try {
      const idxContent = await readFile('index.html', conversation.id);
      if (idxContent && idxContent.trim()) {
        setIndexContent(idxContent);
      } else {
        setIndexContent(initConv);
      }
    } catch (err) {
      console.error('Error getting index.html content:', err);
      setIndexContent(initConv);
    }
  };

  // iFrame message handling (unchanged)
  useEffect(() => {
    const handleMessage = async (event) => {
      if (iframeRef.current && event.source === iframeRef.current.contentWindow) {
        const { type, payload } = event.data;
        switch (type) {
          case 'READ_FILE':
            try {
              const data = await readFile(payload.filename, currentConversation?.id || null);
              event.source.postMessage(
                {
                  type: 'FILE_CONTENT',
                  payload: { filename: payload.filename, content: data === "" ? "{}" : data },
                },
                '*'
              );
            } catch (err) {
              console.error(`Error reading file ${payload.filename}:`, err);
              event.source.postMessage(
                { type: 'ERROR', payload: `Failed to read file ${payload.filename}.` },
                '*'
              );
            }
            break;
          case 'WRITE_FILE':
            try {
              await writeFile(payload.filename, payload.content, currentConversation?.id || null);
              event.source.postMessage(
                { type: 'WRITE_SUCCESS', payload: { filename: payload.filename } },
                '*'
              );
            } catch (err) {
              console.error(`Error writing to file ${payload.filename}:`, err);
              event.source.postMessage(
                { type: 'ERROR', payload: `Failed to write file ${payload.filename}.` },
                '*'
              );
            }
            break;
          default:
            console.warn('Unknown message type:', type);
            break;
        }
      }
    };
    window.addEventListener('message', handleMessage);
    return () => {
      window.removeEventListener('message', handleMessage);
    };
  }, [currentConversation]);

  const lastAssistantMessage = messages.slice().reverse().find((msg) => msg.sender === 'assistant');

  // Source tracking (unchanged, except replacing localStorage calls)
  useEffect(() => {
    const sendSourceToBackend = async (source) => {
      try {
        await api.post('/visit', { source: JSON.stringify(source), userId: actualUser.id });
      } catch (error) {
        console.error('Error sending source to backend:', error);
      }
    };
    const getUTMParams = () => {
      const params = new URLSearchParams(location.search);
      const utm_source = params.get('utm_source');
      const utm_medium = params.get('utm_medium');
      const utm_campaign = params.get('utm_campaign');
      return { utm_source, utm_medium, utm_campaign };
    };
    const determineSource = () => {
      const { utm_source, utm_medium, utm_campaign } = getUTMParams();
      if (utm_source) {
        return { utm_source, utm_medium, utm_campaign };
      } else if (document.referrer) {
        try {
          const referrerUrl = new URL(document.referrer);
          return {
            visitedPage: 'Example Chat page',
            exampleURL: location.pathname,
            URL: referrerUrl.toString(),
            hash: referrerUrl.hash,
            host: referrerUrl.host,
            hostname: referrerUrl.hostname,
            href: referrerUrl.href,
            origin: referrerUrl.origin,
            password: referrerUrl.password,
            pathname: referrerUrl.pathname,
            port: referrerUrl.port,
            protocol: referrerUrl.protocol,
            search: referrerUrl.search,
            searchParams: Object.fromEntries(referrerUrl.searchParams.entries()),
            username: referrerUrl.username,
          };
        } catch (err) {
          console.error('Error parsing referrer URL:', err);
          return null;
        }
      }
      return null;
    };

    const sourceSentFlag = `sourceSentExampleChat_${actualUser.id}`;
    const fromExample = `fromExample`;
    const exampleURL = `exampleURL`;
    // USE secureLocalStorage HERE
    if (!secureLocalStorage.getItem(sourceSentFlag)) {
      const source = determineSource();
      if (source) {
        sendSourceToBackend(source).then(() => {
          secureLocalStorage.setItem(sourceSentFlag, 'true');
          secureLocalStorage.setItem(fromExample, 'true');
          secureLocalStorage.setItem(exampleURL, location.pathname);
        });
      } else {
        sendSourceToBackend({ visitedPage: "Example Chat page", exampleURL: JSON.stringify(location.pathname) })
          .then(() => {
            secureLocalStorage.setItem(sourceSentFlag, 'true');
            secureLocalStorage.setItem(fromExample, 'true');
            secureLocalStorage.setItem(exampleURL, location.pathname);
          });
      }
    }
  }, [location.search, actualUser.id, location.pathname]);

  // For auto-import from /start/*.bin
  useEffect(() => {
    const path = location.pathname;
    if (path.startsWith('/start/') && path.endsWith('.bin')) {
      (async () => {
        try {
          const binFileName = path.replace('/start/', '');
          const response = await fetch(`/${binFileName}`);
          if (!response.ok) {
            throw new Error(`Failed to fetch .bin file. Status: ${response.status}`);
          }
          const fileContent = await response.text();
          const decrypted = decryptData(fileContent);
          const data = JSON.parse(decrypted);
          if (!data.name) {
            throw new Error('Imported conversation data must include a name.');
          }
          const existingConversationIds = conversations.map((c) => c.id);
          let importedId = data.id || uuidv4();
          const alreadyExists = existingConversationIds.includes(importedId);

          if (alreadyExists) {
            const existingConversation = conversations.find((c) => c.id === importedId);
            if (existingConversation) {
              await handleLoadConversation(existingConversation);
            }
          } else {
            const conversationJsonEntry = data.entries.find((e) => e.name === 'conversation.json');
            if (conversationJsonEntry) {
              const convoDecrypted = decryptData(conversationJsonEntry.content);
              const convoObj = JSON.parse(convoDecrypted);
              convoObj.id = importedId;
              convoObj.allowedUsers = [actualUser.id];
              convoObj.lastModified = Date.now();

              const uniqueName = await getUniqueConversationName(data.name);
              convoObj.name = uniqueName;
              conversationJsonEntry.content = encryptData(JSON.stringify(convoObj, null, 2));
              data.id = importedId;
              data.name = uniqueName;
            }
            await importSingleConversation(data);
            alert(`Imported conversation successfully as "${data.name}"!`);
            const updatedConvs = await loadConversations();
            const newlyCreatedConvo = updatedConvs.find((c) => c.id === importedId);
            if (newlyCreatedConvo) {
              await handleLoadConversation(newlyCreatedConvo);
            }
          }
        } catch (err) {
          console.error('Error auto-importing .bin from URL:', err);
        } finally {
          window.history.replaceState(null, '', '/login');
        }
      })();
    }
  }, [location.pathname]);

  // Utility: import a single conversation
  const importSingleFileInputRef = useRef(null);
  const importSingleConversation = async (data) => {
    try {
      const processDir = async (dataObj, prefix) => {
        for (const entry of dataObj.entries) {
          if (entry.type === 'file') {
            const path = `${prefix}/${entry.name}`;
            await indexedDBPut({ path, content: entry.content });
          } else if (entry.type === 'directory') {
            await processDir(entry, `${prefix}/${entry.name}`);
          }
        }
      };
      await processDir(data, `conversations/${data.id}`);
    } catch (err) {
      console.error('Error importing single conversation:', err);
      throw err;
    }
  };

  const getUniqueConversationName = async (baseName) => {
    let uniqueName = baseName;
    const convoNames = conversations.map(c => c.name);
    if (convoNames.includes(uniqueName)) {
      let counter = 2;
      while (convoNames.includes(`${baseName}(${counter})`)) {
        counter++;
      }
      uniqueName = `${baseName}(${counter})`;
    }
    return uniqueName;
  };

  // iFrame full-screen toggle
  const [isIframeFullScreen, setIsIframeFullScreen] = useState(false);
  const toggleIframeFullScreen = () => {
    setIsIframeFullScreen(!isIframeFullScreen);
  };

  // JSX:
  return (
    <div className="chat-page">
      {isDataLoading && (
        <div className="loading-overlay">
          {/* <div className="spinner"></div> */}
          Logo aritdwaaar
        </div>
      )}

      <div className="limit-reached-bar">
        <span>Create your app easly with no code , just prompts.</span>
        <Link to="/login">Login</Link>
      </div>

      {/* Main Chat Area */}
      <div className={`main-chat ${false ? 'with-sidebar' : 'full-width'}`}>
        <div className={`iframe-container ${isIframeFullScreen ? 'full-screen' : ''}`}>
          <iframe
            ref={iframeRef}
            title="Rendered Output"
            className="rendered-iframe"
            srcDoc={indexContent}
            sandbox="allow-scripts allow-same-origin allow-downloads allow-popups allow-modals allow-forms"
          ></iframe>
          <button
            className="toggle-fullscreen-btn"
            onClick={toggleIframeFullScreen}
          >
            {isIframeFullScreen ? <FaTimes size={20} /> : <MdFullscreen size={24} />}
          </button>
        </div>
      </div>
    </div>
  );
};

// IndexedDB read/write logic (unchanged)
const readFile = async (filename, conversationId = null, folderName = null) => {
  const path = (() => {
    if (conversationId) {
      return conversationFilePath(conversationId, filename);
    } else if (folderName) {
      return folderFilePath(folderName, filename);
    } else if (filename === 'favorites.json') {
      return favoritesFilePath();
    } else {
      return filename;
    }
  })();

  try {
    const decryptedContent = await readEncryptedFile(path);
    return decryptedContent;
  } catch (err) {
    console.warn(`${filename} not found in IDB. Returning empty content.`);
    return '';
  }
};

const writeFile = async (filename, content, conversationId = null, folderName = null) => {
  const path = (() => {
    if (conversationId) {
      const sanitizedFileName = sanitizeFileName(filename);
      return conversationFilePath(conversationId, sanitizedFileName);
    } else if (folderName) {
      const sanitizedFileName = sanitizeFileName(filename);
      return folderFilePath(folderName, sanitizedFileName);
    } else if (filename === 'favorites.json') {
      return favoritesFilePath();
    } else {
      return filename;
    }
  })();

  await writeEncryptedFile(path, content);
};

export default ChatPageExample;
