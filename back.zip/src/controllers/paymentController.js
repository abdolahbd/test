// src/controllers/paymentController.js
const { createCheckoutSession } = require('../services/paymentService');
const  Checkout = require('../models/Checkout');  
const geoip = require('geoip-lite');



const getClientIP  = (req) => {
  // Extract the IP address
  const forwarded = req.headers['x-forwarded-for'];
  let ip;

  if (forwarded) {
    // 'x-forwarded-for' may return multiple IP addresses in the format: "client IP, proxy 1 IP, proxy 2 IP"
    const forwardedIps = forwarded.split(',').map(ip => ip.trim());
    ip = forwardedIps[0];
  } else {
    ip = req.connection.remoteAddress || req.socket.remoteAddress || req.ip;
  }

  // Handle IPv6 addresses that are IPv4 mapped (e.g., ::ffff:127.0.0.1)
  const cleanIp = ip.startsWith('::ffff:') ? ip.substring(7) : ip;

  // Lookup the geolocation data
  const geo = geoip.lookup(cleanIp);

  // Extract the country code or set to 'Unknown' if not found
  const country = geo ? geo.country : 'Unknown';

  return JSON.stringify({ ip: cleanIp, country });
};


exports.createCheckoutSession = async (req, res) => {
  try {
 

    const userId = req.user.id;
    const session = await createCheckoutSession(userId);  
    const ip = getClientIP(req);

    await Checkout.create({
      user_id:userId,
      ip
    });
    res.status(200).json({ sessionId: session.id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
