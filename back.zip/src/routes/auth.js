// src/routes/auth.js
const express = require('express');
const router = express.Router();
const { register, login,googleSaveKeys } = require('../controllers/authController');
const { check } = require('express-validator');
const passport = require('passport');
const jwt = require('jsonwebtoken');
require('dotenv').config();


router.post(
  '/register',
  [
    check('email', 'Please include a valid email').isEmail(),
    check('password', 'Password must be at least 6 characters').isLength({
      min: 1,
    })
  ],
  register
);

router.post('/login', login);


// Google OAuth login route
router.get(
    '/google',
    passport.authenticate('google', { scope: ['email', 'profile'] })
  );
  
  // Google OAuth callback route
  router.get(
    '/google/callback',
    passport.authenticate('google', {
      failureRedirect: '/login',
      session: false,
    }),
    (req, res) => {
      // Successful authentication, generate JWT
      const token = jwt.sign({ id: req.user.id }, process.env.JWT_SECRET
        // ,{expiresIn: '30s'},  //<-------------------- ghiz arthkams ghlmoda nsession ightzri ikhsa ada7 iskr login
    );
      // Redirect to frontend with the token
      res.redirect(`${process.env.FRONTEND_URL}/auth/google/success?token=${token}`);
    }
  );


router.post('/google/save-keys', googleSaveKeys);

module.exports = router;
