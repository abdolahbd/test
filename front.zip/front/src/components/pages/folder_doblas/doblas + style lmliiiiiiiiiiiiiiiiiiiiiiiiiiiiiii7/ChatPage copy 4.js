// src/components/pages/ChatPage.js

import React, { useState, useRef, useEffect, useContext } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import api from '../../services/apiService';
import Modal from 'react-modal';
import './ChatPage.css';
import { AuthContext } from '../../contexts/AuthContext';
import ReviewModal from '../Modals/ReviewModal';
import HelpModal from '../Modals/HelpModal';
import ShareModal from '../Modals/ShareModal';
import CryptoJS from 'crypto-js';
import { v4 as uuidv4 } from 'uuid';
import { MdFullscreen } from 'react-icons/md';
import { FaTimes } from 'react-icons/fa';
import { AiOutlineCodeSandbox } from "react-icons/ai";
import LogoutButton from '../common/LogoutButton';
import SubscriptionManagementPage from './SubscriptionManagementPage';
import obscureHtmlCode from '../../utils/obscureHtmlCode';
import ServiceDropdown from '../common/ServiceDropdown'; 
import ConversationItem from '../common/ConversationItem'; 
import { FaRegStar } from "react-icons/fa";
import { TbLayoutSidebarLeftCollapseFilled } from "react-icons/tb";
import { TbLayoutSidebarLeftExpand } from "react-icons/tb";
import { IoIosArrowDropdown, IoIosArrowDropup } from "react-icons/io";
import FoldersSection from '../common/FoldersSection';
import FavoriteApps from '../common/FavoriteApps';
import ConversationsSection from '../common/ConversationsSection';


// Encryption key from environment variables
const encryptionKey = process.env.REACT_APP_ENCRYPTION_KEY;

// List of supported services
const supportedServices = JSON.parse(process.env.REACT_APP_SUPPORTED_SERVICES);

// Mapping between service names and backend keys
const serviceKeyMap = JSON.parse(process.env.REACT_APP_SERVICE_KEY_MAP);

const initConv = "<html><head></head><body><script>document.addEventListener('click', () => {parent.postMessage({ type: 'iframe-click' }, '*');});</script></body></html>"

const LMARHALA = process.env.REACT_APP_LMARHALA;

// Flag to enable or disable encryption for localStorage
const encryptionEnabledFlag = process.env.REACT_APP_ENCRYPTION_ENABLED === '1';

/**
 * Use the same AES routines from your code to encrypt/decrypt localStorage data (for values).
 * We will now *hash* the key so that each plaintext key consistently maps to the same hashed key.
 */
const hashKey = (plainKey) => {
  // Use SHA-256 hashing to ensure a stable, deterministic key
  return CryptoJS.SHA256(plainKey).toString();
};











function maybeHashKey(key) {
  if (encryptionEnabledFlag) {
    // When encryption is enabled, hash the key using SHA-256 so it's stable ciphertext
    return CryptoJS.SHA256(key).toString();
  } else {
    // If encryption is disabled, just store the key as-is (plaintext)
    return key;
  }
}

const encryptLocalData = (plainText) => {
  if (!encryptionKey) {
    throw new Error('Encryption key is missing. Please set REACT_APP_ENCRYPTION_KEY in your .env file.');
  }
  return CryptoJS.AES.encrypt(plainText, encryptionKey).toString();
};

const decryptLocalData = (cipherText) => {
  if (!encryptionKey) {
    throw new Error('Encryption key is missing. Please set REACT_APP_ENCRYPTION_KEY in your .env file.');
  }
  const bytes = CryptoJS.AES.decrypt(cipherText, encryptionKey);
  const decrypted = bytes.toString(CryptoJS.enc.Utf8);
  return decrypted;
};

/**
 * A secure wrapper around localStorage to *hash* the key (when enabled)
 * and optionally encrypt/decrypt the *value* based on REACT_APP_ENCRYPTION_ENABLED.
 */
const secureLocalStorage = {
  setItem: (key, value) => {
    if (!key) return;
    const storageKey = maybeHashKey(key);

    if (encryptionEnabledFlag) {
      // Encrypt the value
      const encryptedValue = encryptLocalData(value);
      localStorage.setItem(storageKey, encryptedValue);
    } else {
      // Plain text store
      localStorage.setItem(storageKey, value);
    }
  },

  getItem: (key) => {
    if (!key) return null;
    const storageKey = maybeHashKey(key);

    const storedValue = localStorage.getItem(storageKey);
    if (!storedValue) return null;

    if (encryptionEnabledFlag) {
      try {
        return decryptLocalData(storedValue);
      } catch (err) {
        console.error('Failed to decrypt localStorage value:', err);
        return null;
      }
    } else {
      return storedValue;
    }
  },

  removeItem: (key) => {
    if (!key) return;
    const storageKey = maybeHashKey(key);
    localStorage.removeItem(storageKey);
  },

  clear: () => {
    // Clears everything, both hashed/unhashed
    localStorage.clear();
  },
};

// Existing AES-based encryption/decryption used for your IndexedDB content.
const encryptData = (data) => {
  if (!encryptionKey) {
    throw new Error('Encryption key is missing. Please set REACT_APP_ENCRYPTION_KEY in your .env file.');
  }
  return CryptoJS.AES.encrypt(data, encryptionKey).toString();
};

const decryptData = (cipherText) => {
  if (!encryptionKey) {
    throw new Error('Encryption key is missing. Please set REACT_APP_ENCRYPTION_KEY in your .env file.');
  }
  try {
    const bytes = CryptoJS.AES.decrypt(cipherText, encryptionKey);
    const decrypted = bytes.toString(CryptoJS.enc.Utf8);
    if (!decrypted) {
      throw new Error('Decryption failed. Invalid ciphertext or encryption key.');
    }
    return decrypted;
  } catch (error) {
    console.error('Error during decryption:', error);
    throw new Error('Failed to decrypt data.');
  }
};












// Utility to read a file as Data URL
const readFileAsDataURL = (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

// IndexedDB utilities
let dbPromise = null;

const initIndexedDB = () => {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const request = window.indexedDB.open('WIA-SIGMANOS-GM-TZ', 2);
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains('files')) {
          db.createObjectStore('files', { keyPath: 'path' });
        }
      };
      request.onsuccess = () => {
        resolve(request.result);
      };
      request.onerror = () => {
        reject(request.error);
      };
    });
  }
  return dbPromise;
};

const dbTransaction = async (storeName, mode) => {
  const db = await initIndexedDB();
  const tx = db.transaction(storeName, mode);
  return tx.objectStore(storeName);
};

const indexedDBGet = async (key) => {
  const store = await dbTransaction('files', 'readonly');
  return new Promise((resolve, reject) => {
    const req = store.get(key);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
};

const indexedDBGetAllKeys = async () => {
  const store = await dbTransaction('files', 'readonly');
  return new Promise((resolve, reject) => {
    const req = store.getAllKeys();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
};

const indexedDBPut = async (record) => {
  const store = await dbTransaction('files', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.put(record);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
};

const indexedDBDelete = async (key) => {
  const store = await dbTransaction('files', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.delete(key);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
};

const indexedDBListByPrefix = async (prefix) => {
  const keys = await indexedDBGetAllKeys();
  return keys.filter(k => k.startsWith(prefix));
};

// Encryption and decryption for files using IndexedDB
const readEncryptedFile = async (path) => {
  const record = await indexedDBGet(path);
  if (!record) {
    const err = new Error('NotFoundError');
    err.name = 'NotFoundError';
    throw err;
  }
  const encryptedContent = record.content;
  const decryptedContent = decryptData(encryptedContent);
  return decryptedContent;
};

const writeEncryptedFile = async (path, data) => {
  const encryptedContent = encryptData(data);
  const record = { path, content: encryptedContent };
  await indexedDBPut(record);
};

// File path utilities using unique conversation IDs
const conversationFilePath = (conversationId, fileName) => `conversations/${conversationId}/${fileName}`;
const folderFilePath = (folderName, fileName) => `folders/${folderName}/${fileName}`;
const favoritesFilePath = () => `favorites.json`;

// Utility function to sanitize file names by replacing spaces with underscores
const sanitizeFileName = (name) => name.replace(/\s+/g, '_');

const ChatPage = () => {
  const { user } = useContext(AuthContext);
  const actualUser = user || { id: "777777777", iat: 1733253711 }; // Fallback for unauthenticated users

  // State management
  const [prompt, setPrompt] = useState('');
  const [messages, setMessages] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [loadingImportLink, setLoadingImportLink] = useState(false);

  const [iframeError, setIframeError] = useState(null);
  const navigate = useNavigate();
  const location = useLocation();

  const [isLimitReached, setIsLimitReached] = useState(false);
  const [currentClickCount, setCurrentClickCount] = useState(0);
  const [clickLimit, setClickLimit] = useState(0);

  const [conversations, setConversations] = useState([]);
  const [currentConversation, setCurrentConversation] = useState(null);

  const fileInputRef = useRef(null);
  const messagesEndRef = useRef(null);
  const iframeRef = useRef(null);
  const uploadFileInputRef = useRef(null);

  const [isCreateFolderModalOpen, setIsCreateFolderModalOpen] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');

  const [isRenameModalOpen, setIsRenameModalOpen] = useState(false);
  const [renameConversation, setRenameConversation] = useState(null);
  const [newConversationName, setNewConversationName] = useState('');

  const [folders, setFolders] = useState([]);
  const [expandedFolders, setExpandedFolders] = useState({});
  const [filesInFolders, setFilesInFolders] = useState({});

  const [indexContent, setIndexContent] = useState(initConv);
  const [currentUploadFolder, setCurrentUploadFolder] = useState(null);

  const [isConversationsCollapsed, setIsConversationsCollapsed] = useState(false);
  const [displayedConversations, setDisplayedConversations] = useState(7);

  const [isFoldersCollapsed, setIsFoldersCollapsed] = useState(false);
  const [displayedFolders, setDisplayedFolders] = useState(7);

  const [favoriteConversations, setFavoriteConversations] = useState([]);
  const [isFavoriteAppsCollapsed, setIsFavoriteAppsCollapsed] = useState(false);


  const [isServiceDropdownOpen, setIsServiceDropdownOpen] = useState(false);


  // API Key Management
  // State to hold API key statuses
  const [apiKeyStatus, setApiKeyStatus] = useState(() => {
    // Load from (secure) localStorage if available
    const storedStatus = secureLocalStorage.getItem(`apiKeyStatus_${actualUser.id}`);
    return storedStatus ? JSON.parse(storedStatus) : {};
  });

  // API Key Presence Status (True/False)
  const [hasApiKey, setHasApiKey] = useState(() => {
    return Object.values(apiKeyStatus).some(status => status === true);
  });

  // Initialize selectedService from (secure) localStorage or default to first service
  const [selectedService, setSelectedService] = useState(() => {
    const savedService = secureLocalStorage.getItem('selectedService');
    return supportedServices.includes(savedService) ? savedService : supportedServices[0];
  });

  const [isImportDropdownOpen, setIsImportDropdownOpen] = useState(false);
  const [isImportLinkModalOpen, setIsImportLinkModalOpen] = useState(false);
  const [importUrl, setImportUrl] = useState('');

  const [isDataLoading, setIsDataLoading] = useState(true);

  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const [activeModal, setActiveModal] = useState(null); // Possible values: 'profile', 'settings', 'logout', null

  // References for the profile button and dropdown
  const profileButtonRef = useRef(null);
  const dropdownRef = useRef(null);

  const importLinkInputRef = useRef(null);



  const sidebarRef = useRef(null);
  const toggleButtonRef = useRef(null);
  

  // Function to handle importing from URL
  const handleImportFromLink = async () => {
    setLoadingImportLink(true);
    if (!importUrl.trim()) {
      alert('Please enter a valid URL.');
      setLoadingImportLink(false);
      return;
    }

    try {
      // Fetch the file from the URL
      const response = await fetch(importUrl);
      if (!response.ok) {
        throw new Error(`Failed to fetch the file. Status: ${response.status}`);
      }

      const fileContent = await response.text(); // Assuming the file is text-based

      // Decrypt the file content
      const decrypted = decryptData(fileContent);
      const data = JSON.parse(decrypted);

      // Validate the imported data
      if (!data.name) {
        throw new Error('Imported conversation data must include a name.');
      }

      // Ensure unique conversation ID
      const existingConversationIds = conversations.map((c) => c.id);
      let importedId = data.id || uuidv4();
      if (existingConversationIds.includes(importedId)) {
        importedId = uuidv4();
      }
      data.id = importedId;

      // Overwrite conversation.json entry with updated ID and allowedUsers
      const conversationJsonEntry = data.entries.find((e) => e.name === 'conversation.json');
      if (conversationJsonEntry) {
        const convoDecrypted = decryptData(conversationJsonEntry.content);
        const convoObj = JSON.parse(convoDecrypted);

        // Update ID & allowedUsers
        convoObj.id = data.id;
        convoObj.allowedUsers = [actualUser.id];
        convoObj.lastModified = Date.now();

        // Ensure unique conversation name
        const uniqueName = await getUniqueConversationName(data.name);
        convoObj.name = uniqueName;

        // Re-encrypt and update the content
        const newConvoContent = JSON.stringify(convoObj, null, 2);
        conversationJsonEntry.content = encryptData(newConvoContent);

        // Sync data.name with unique name
        data.name = uniqueName;
      }

      // Import into IndexedDB
      await importSingleConversation(data);
      setLoadingImportLink(false);
      alert(`Imported conversation successfully as "${data.name}"!`);

      // 1) Reload the conversation list and store the result
      const updatedConvs = await loadConversations();
      // 2) Find the newly created conversation by id
      const newlyImportedConvo = updatedConvs.find((c) => c.id === data.id);
      // 3) If found, load it immediately
      if (newlyImportedConvo) {
        await handleLoadConversation(newlyImportedConvo);
      }

      // Reset the modal state
      setIsImportLinkModalOpen(false);
      setImportUrl('');
    } catch (err) {
      console.error('Error importing from link:', err);
      alert(
        'Failed to import conversation from the provided URL. Please ensure the URL is correct and the file format is valid.'
      );
    }
  };

  const handleClickOutside = (event) => {
    
    if (
      dropdownRef.current &&
      !dropdownRef.current.contains(event.target) &&
      profileButtonRef.current &&
      !profileButtonRef.current.contains(event.target)
    ) {
      setIsProfileDropdownOpen(false);
    }
  };

  useEffect(() => {
    // Bind the event listener
    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      // Unbind the event listener on clean up
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Save selectedService to (secure) localStorage whenever it changes
  useEffect(() => {
    secureLocalStorage.setItem('selectedService', selectedService);
  }, [selectedService]);

  const [isKeyModalOpen, setIsKeyModalOpen] = useState(false);
  const [keyInput, setKeyInput] = useState('');

  const [hasShownReviewModal, setHasShownReviewModal] = useState(() => {
    const val = secureLocalStorage.getItem(`hasShownReviewModal_${actualUser.id}`);
    return val ? JSON.parse(val) : false;
  });

  const [reviewModalShow, setreviewModalShow] = useState(false);
  const [helpModalShow, sethelpModalShow] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  // Inside your ChatPage component, among other useState hooks
  const [apiKeyError, setApiKeyError] = useState(null);

  const shareUrl = 'https://yobino.com';
  const title = 'Check out this awesome app!';
  const description = 'This app does amazing things. You should definitely try it out!';

  const handleOpenReview = () => setreviewModalShow(true);
  const handleCloseReview = () => setreviewModalShow(false);

  const handleOpenHelp = () => sethelpModalShow(true);
  const handleCloseHelp = () => sethelpModalShow(false);

  const conversationCountRef = useRef(0);

  useEffect(() => {
    conversationCountRef.current = conversations.length;
  }, [conversations.length]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    const saveConversation = async () => {
      if (currentConversation) {
        try {
          const originalMessages = messages.map(({ sender, content, timestamp }) => ({
            sender,
            content,
            timestamp,
          }));

          let allowedUsers = [actualUser.id];

          const conversationData = {
            id: currentConversation.id, // Include unique ID
            name: currentConversation.name, // Include name
            allowedUsers,
            messages: originalMessages,
            lastModified: Date.now(), // Update lastModified
          };
          await writeFile('conversation.json', JSON.stringify(conversationData, null, 2), currentConversation.id);

          console.log(`Conversation "${currentConversation.name}" saved automatically.`);

          // Update the lastModified in the conversations state
          setConversations((prevConvos) =>
            prevConvos.map((convo) =>
              convo.id === currentConversation.id
                ? { ...convo, lastModified: Date.now() }
                : convo
            )
          );
        } catch (err) {
          console.error('Error auto-saving conversation:', err);
        }
      }
    };

    saveConversation();
  }, [messages, currentConversation, actualUser.id]);

  // Listen for errors inside the iframe
  useEffect(() => {
    const handleIframeError = (e) => {
      // This will catch runtime errors from within the iframe
      console.log('-------*-*-*-*-*-*-*---------');
      console.log(e.message);
      console.log('-------*-*-*-*-*-*-*---------');

      setIframeError(e.message);
    };

    if (iframeRef.current && iframeRef.current.contentWindow) {
      iframeRef.current.contentWindow.addEventListener('error', handleIframeError);
    }

    return () => {
      if (iframeRef.current && iframeRef.current.contentWindow) {
        iframeRef.current.contentWindow.removeEventListener('error', handleIframeError);
      }
    };
  }, []);

  useEffect(() => {
    const handleIframeErrorMessage = (e) => {
      if (e.data && e.data.type === 'iframeError') {
        console.log('Iframe error received:', e.data.payload.message);
        setIframeError(e.data.payload.message);
      }
    };
    window.addEventListener('message', handleIframeErrorMessage);
    return () => {
      window.removeEventListener('message', handleIframeErrorMessage);
    };
  }, []);

  const checkUserLimit = async () => {
    try {
      const response = await api.get('/user/userStatus');
      const {
        isSubscribed,
        currentRequestCount,
        requestLimit,
        isLimitReached: limitReachedBackend,
        currentClickCount: clickCountBackend,
        clickLimit: clickLimitBackend,
      } = response.data;

      setIsLimitReached(limitReachedBackend);
      setCurrentClickCount(clickCountBackend);
      setClickLimit(clickLimitBackend);
    } catch (err) {
      console.error('Error checking user limit:', err);
    }
  };

  useEffect(() => {
    const fetchApiKeyStatus = async () => {
      if (actualUser.id !== "777777777") {
        // Authenticated users
        try {
          const response = await api.get('/user/apiKeyStatus');
          const apiKeyStatusResponse = response.data; // { openaiApiKey: true, geminiApiKey: false, ... }

          setApiKeyStatus(apiKeyStatusResponse);
          setHasApiKey(Object.values(apiKeyStatusResponse).some(status => status === true));

          // Save to (secure) localStorage
          secureLocalStorage.setItem(
            `apiKeyStatus_${actualUser.id}`,
            JSON.stringify(apiKeyStatusResponse)
          );
        } catch (err) {
          console.error('Error fetching API key status:', err);
        }
      } else {
        // Unauthenticated users: load from localStorage if available
        const storedStatus = secureLocalStorage.getItem(`apiKeyStatus_${actualUser.id}`);
        if (storedStatus) {
          const parsedStatus = JSON.parse(storedStatus);
          setApiKeyStatus(parsedStatus);
          const hasKey = Object.values(parsedStatus).some(status => status === true);
          setHasApiKey(hasKey);
        }
      }
    };

    fetchApiKeyStatus();
  }, [actualUser.id]);

  const loadFavorites = async (userId) => {
    try {
      const content = await readFile('favorites.json');
      if (!content) {
        setFavoriteConversations([]);
        return;
      }
      const allFavorites = JSON.parse(content);
      if (typeof allFavorites !== 'object' || allFavorites === null) {
        setFavoriteConversations([]);
        return;
      }

      if (userId !== "777777777" && allFavorites["777777777"]) {
        const oldFavorites = Array.isArray(allFavorites["777777777"])
          ? allFavorites["777777777"]
          : [];
        if (!Array.isArray(allFavorites[userId])) {
          allFavorites[userId] = [];
        }
        allFavorites[userId] = Array.from(new Set([...allFavorites[userId], ...oldFavorites]));
        delete allFavorites["777777777"];
        await writeFile('favorites.json', JSON.stringify(allFavorites, null, 2));
      }

      const userFavorites = Array.isArray(allFavorites[userId]) ? allFavorites[userId] : [];
      setFavoriteConversations(userFavorites);
    } catch (err) {
      console.error('Error loading favorites:', err);
      setFavoriteConversations([]);
    }
  };

  const saveFavorites = async (userId, favorites) => {
    let allFavorites = {};
    try {
      const content = await readFile('favorites.json');
      if (content) {
        try {
          allFavorites = JSON.parse(content);
          if (typeof allFavorites !== 'object' || allFavorites === null) {
            allFavorites = {};
          }
        } catch {
          allFavorites = {};
        }
      }
      allFavorites[userId] = favorites;
      await writeFile('favorites.json', JSON.stringify(allFavorites, null, 2));
    } catch (err) {
      console.error('Error saving favorites:', err);
      alert('Failed to save favorites.');
    }
  };

  const toggleFavoriteConversation = async (conversation) => {
    const isFavorite = favoriteConversations.includes(conversation.id);
    let updatedFavorites;

    if (isFavorite) {
      updatedFavorites = favoriteConversations.filter((favId) => favId !== conversation.id);
    } else {
      updatedFavorites = [...favoriteConversations, conversation.id];
    }

    setFavoriteConversations(updatedFavorites);

    await saveFavorites(actualUser.id, updatedFavorites);
  };

  const removeFavoriteConversation = async (conversationId) => {
    const updatedFavorites = favoriteConversations.filter((favId) => favId !== conversationId);
    setFavoriteConversations(updatedFavorites);

    await saveFavorites(actualUser.id, updatedFavorites);
  };

  const loadConversations = async () => {
    try {
      const allKeys = await indexedDBListByPrefix('conversations/');
      const conversationIds = new Set(
        allKeys
          .map(k => {
            const parts = k.split('/');
            return parts.length > 1 ? parts[1] : null;
          })
          .filter(Boolean)
      );

      const convs = [];
      for (const convoId of conversationIds) {
        const convoContent = await readFile('conversation.json', convoId);
        if (!convoContent || !convoContent.trim()) continue;
        try {
          const convoData = JSON.parse(convoContent);
          let shouldInclude = false;
          if (convoData.allowedUsers && convoData.allowedUsers.includes(actualUser.id)) {
            shouldInclude = true;
          } else if (convoData.allowedUsers && convoData.allowedUsers.includes("777777777")) {
            convoData.allowedUsers = convoData.allowedUsers.map(uid =>
              uid === "777777777" ? actualUser.id : uid
            );
            await writeFile(
              'conversation.json',
              JSON.stringify(convoData, null, 2),
              convoId
            );
            shouldInclude = true;
          }

          if (shouldInclude) {
            const lastModified = convoData.lastModified || Date.now(); // Read lastModified from data
            convs.push({
              id: convoData.id || convoId, // Ensure ID is present
              name: convoData.name || `Conversation ${convs.length + 1}`, // Fallback name
              lastModified,
            });
          }
        } catch {
          console.warn(`conversation.json malformed for ${convoId}. Skipping.`);
        }
      }

      convs.sort((a, b) => b.lastModified - a.lastModified); // Sort by lastModified descending
      setConversations(convs);
      setDisplayedConversations(7);
      return convs;
    } catch (err) {
      console.error('Error loading conversations:', err);
      alert('Failed to load conversations.');
      return [];
    }
  };

  // Load folders so only owners see them
  const loadFolders = async () => {
    try {
      const keys = await indexedDBListByPrefix('folders/');
      // Gather unique folder names.
      const folderNames = new Set(
        keys.map(k => k.split('/')[1]).filter(name => name)
      );

      const folderEntries = [];
      for (const fname of folderNames) {
        const fContent = await readFile('folder.json', null, fname);
        let lastModified = 0;
        let shouldInclude = false;
        if (fContent && fContent.trim()) {
          try {
            const folderData = JSON.parse(fContent);
            lastModified = folderData.lastModified || 0;

            // Check if folderData has an allowedUsers array
            if (folderData.allowedUsers && folderData.allowedUsers.includes(actualUser.id)) {
              shouldInclude = true;
            }
            // If there's an allowedUsers array that still has "777777777", rewrite it to the current user
            else if (folderData.allowedUsers && folderData.allowedUsers.includes("777777777")) {
              folderData.allowedUsers = folderData.allowedUsers.map(uid =>
                uid === "777777777" ? actualUser.id : uid
              );
              await writeFile(
                'folder.json',
                JSON.stringify(folderData, null, 2),
                null,
                fname
              );
              shouldInclude = true;
            }
            // If old folder has no allowedUsers at all, treat it like the user is the owner
            else if (!folderData.allowedUsers) {
              folderData.allowedUsers = [actualUser.id];
              await writeFile(
                'folder.json',
                JSON.stringify(folderData, null, 2),
                null,
                fname
              );
              shouldInclude = true;
            }
          } catch {
            console.warn(`folder.json malformed for ${fname}`);
          }
        }
        // If user is allowed, push into folderEntries
        if (shouldInclude) {
          folderEntries.push({
            name: fname,
            lastModified,
          });
        }
      }

      // Sort by lastModified descending
      folderEntries.sort((a, b) => b.lastModified - a.lastModified);
      setFolders(folderEntries);
      setDisplayedFolders(7);
    } catch (err) {
      console.error('Error loading folders:', err);
      alert('Failed to load folders.');
    }
  };

  const handleSelectDirectory = async () => {
    try {
      await initIndexedDB();
      await loadConversations();
      await loadFavorites(actualUser.id);
      await loadFolders();
      await checkUserLimit();
    } catch (err) {
      console.error('Error initializing IndexedDB:', err);
      alert('Failed to initialize storage.');
    }
  };

  useEffect(() => {
    handleSelectDirectory();
  }, []);

  useEffect(() => {
    if (conversations.length >= 7 && !hasShownReviewModal) {
      setreviewModalShow(true);
      setHasShownReviewModal(true);
      secureLocalStorage.setItem(
        `hasShownReviewModal_${actualUser.id}`,
        JSON.stringify(true)
      );
    }
  }, [conversations.length, hasShownReviewModal, actualUser.id]);

  const promptInputRef = useRef(null);


  const handleCreateConversation = async () => {
    setIframeError(null);
    const convoName = window.prompt(
      'Enter a name for the new conversation:',
      `Conversation ${conversations.length + 1}`
    );
    if (!convoName) {
      alert('Conversation name is required.');
      return;
    }

    const invalidChars = /[<>:"/\\|?*\x00-\x1F]/g;
    if (invalidChars.test(convoName)) {
      alert('Conversation name contains invalid characters.');
      return;
    }

    try {
      // Check if any conversation already has this name
      const nameExists = conversations.some(convo => convo.name === convoName);
      if (nameExists) {
        alert('A conversation with this name already exists.');
        return;
      }

      const uniqueId = uuidv4(); // Generate unique ID for the conversation

      const conversationData = {
        id: uniqueId,
        name: convoName,
        allowedUsers: [actualUser.id],
        messages: [],
        lastModified: Date.now(), // Initialize lastModified
      };
      await writeFile('conversation.json', JSON.stringify(conversationData, null, 2), uniqueId);
      const newConversation = { id: uniqueId, name: convoName, lastModified: Date.now() };
      setConversations((prev) => [newConversation, ...prev]);
      setCurrentConversation(newConversation);
      setMessages([]);
      setIndexContent(obscureHtmlCode(initConv));
            promptInputRef.current.focus();

      const isMobile = window.innerWidth < 600; // Define your mobile breakpoint
      if (isMobile) {
        setIsSidebarOpen(false);
      }

 
    
      alert(`Conversation "${convoName}" created successfully.`);

      await checkUserLimit();
    } catch (err) {
      console.error('Error creating conversation:', err);
      alert('Failed to create conversation.');
    }
  };

  const openRenameConversationModal = (conversation) => {
    setRenameConversation(conversation);
    setNewConversationName(conversation.name);
    setIsRenameModalOpen(true);
  };

  const closeRenameConversationModal = () => {
    setIsRenameModalOpen(false);
    setRenameConversation(null);
    setNewConversationName('');
  };

  const handleRenameConversation = async () => {
    if (!newConversationName.trim()) {
      alert('Conversation name cannot be empty.');
      return;
    }

    const invalidChars = /[<>:"/\\|?*\x00-\x1F]/g;
    if (invalidChars.test(newConversationName)) {
      alert('Conversation name contains invalid characters.');
      return;
    }

    try {
      const existing = conversations.find(
        convo => convo.name === newConversationName.trim()
      );
      if (existing) {
        alert('A conversation with this name already exists.');
        return;
      }

      const convoId = renameConversation.id;
      const convoData = {
        id: convoId,
        name: newConversationName.trim(),
        allowedUsers: [actualUser.id],
        messages: messages.map(({ sender, content, timestamp }) => ({
          sender,
          content,
          timestamp,
        })),
        lastModified: Date.now(),
      };

      await writeFile('conversation.json', JSON.stringify(convoData, null, 2), convoId);

      setConversations((prevConvos) =>
        prevConvos.map((convo) =>
          convo.id === convoId
            ? { ...convo, name: newConversationName.trim(), lastModified: Date.now() }
            : convo
        )
      );

      if (currentConversation && currentConversation.id === convoId) {
        setCurrentConversation({ ...currentConversation, name: newConversationName.trim() });
      }

      alert(`Conversation renamed to "${newConversationName.trim()}" successfully.`);
      closeRenameConversationModal();
      await checkUserLimit();
    } catch (err) {
      console.error('Error renaming conversation:', err);
      alert('Failed to rename conversation.');
    }
  };

  const handleDeleteConversation = async (conversation) => {
    if (!window.confirm(`Are you sure you want to delete the conversation "${conversation.name}"?`)) {
      return;
    }

    try {
      const convoId = conversation.id;
      const keys = await indexedDBListByPrefix(`conversations/${convoId}/`);
      for (const key of keys) {
        await indexedDBDelete(key);
      }

      setConversations((prevConvos) => prevConvos.filter((convo) => convo.id !== convoId));

      if (favoriteConversations.includes(convoId)) {
        const updatedFavorites = favoriteConversations.filter((favId) => favId !== convoId);
        setFavoriteConversations(updatedFavorites);
        await saveFavorites(actualUser.id, updatedFavorites);
      }

      if (currentConversation && currentConversation.id === convoId) {
        setCurrentConversation(null);
        setMessages([]);
        setIndexContent(obscureHtmlCode(initConv));
      }

      alert(`Conversation "${conversation.name}" deleted successfully.`);
      await checkUserLimit();
    } catch (err) {
      console.error('Error deleting conversation:', err);
      alert('Failed to delete conversation.');
    }
  };

  const handleLoadConversation = async (conversation) => {
    setIsDataLoading(false);
    console.log(777777);

    try {
      const convoContent = await readFile('conversation.json', conversation.id);
      if (!convoContent || !convoContent.trim()) {
        alert('Conversation not found or malformed.');
        return;
      }
      const convoData = JSON.parse(convoContent);

      if (!convoData.allowedUsers || !convoData.allowedUsers.includes(actualUser.id)) {
        alert('You are not authorized to access this conversation.');
        return;
      }

      const loadedMessages = convoData.messages;
      if (!Array.isArray(loadedMessages)) {
        throw new Error('Invalid conversation format.');
      }

      const mappedMessages = loadedMessages.map((msg) => {
        if (msg.sender === 'assistant') {
          const modifiedDisplayContent = msg.content;
          return { ...msg, displayContent: modifiedDisplayContent };
        }
        return { ...msg, displayContent: msg.content };
      });

      setIndexContent(obscureHtmlCode(initConv)); // Reset index content before loading new conversation
      setMessages(mappedMessages);
      setCurrentConversation(conversation);
      setError(null);

      await getConversationIndexContent(conversation);
    } catch (err) {
      console.error('Error loading conversation:', err);
      alert('Failed to load conversation.');
      setIndexContent(obscureHtmlCode(initConv));
    }
  };

  const handleSelectConversation = async (conversation, index) => {
    if (isLimitReached && index >= 3) {
      return;
    }
    await handleLoadConversation(conversation);
  };

  const handleSend = async () => {
    if (!prompt.trim()) {
      setError('Please enter a valid prompt.');
      return;
    }

    if (!currentConversation) {
      setError('Please select or create a conversation first.');
      return;
    }

    // Check if API key is present based on service status
    const isApiKeyPresent = apiKeyStatus[serviceKeyMap[selectedService]];

    if (!isApiKeyPresent) {
      setIsKeyModalOpen(true);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const lastExchange = [];
      if (messages.length >= 2) {
        const lastUserMessage = messages[messages.length - 2];
        const lastAssistantMessage = messages[messages.length - 1];
        if (lastUserMessage.sender === 'user' && lastAssistantMessage.sender === 'assistant') {
          lastExchange.push(
            { ...lastUserMessage, content: lastUserMessage.content },
            { ...lastAssistantMessage, content: lastAssistantMessage.content }
          );
        }
      }

      const userMessageContent = prompt;

      // LOG the iframeError to ensure we see what is being appended
      console.log('00000000000');
      console.log(iframeError);
      console.log('00000000000');

      // Append iframeError to user's prompt if error is detected
      const requestPayload = {
        prompt: iframeError
          ? `${userMessageContent} . i have this error: ${iframeError}`
          : userMessageContent,
        messages: lastExchange,
        conversationName: currentConversation.name,
        service: selectedService, // Include selected service
      };

      if (actualUser.id === "777777777") {
        // Unauthenticated users: include all API keys from localStorage
        const apiKeys = {};
        supportedServices.forEach(service => {
          const keyName = `${service.toLowerCase()}ApiKey`;
          const localKey = secureLocalStorage.getItem(keyName);
          if (localKey) {
            apiKeys[serviceKeyMap[service]] = localKey;
          }
        });
        requestPayload.apiKeys = apiKeys;
      }

      const response = await api.post('/request', requestPayload);

      const assistantCode = response.data.code;

      const assistantMessage = {
        sender: 'assistant',
        content: assistantCode,
        displayContent: assistantCode,
        timestamp: new Date().toISOString(),
      };
      const userMessage = {
        sender: 'user',
        content: userMessageContent,
        displayContent: userMessageContent,
        timestamp: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, userMessage, assistantMessage]);

      await saveAssistantCode(assistantCode);
      await getConversationIndexContent(currentConversation);

      await checkUserLimit();
      setIframeError(null);
      setPrompt('');
    } catch (err) {
      if (err.response) {
        const errorMsg = err.response.data.error || 'An error occurred. Please try again.';
        setError(errorMsg);
        if (errorMsg === 'Request limit reached. Upgrade your account.') {
          setIsLimitReached(true);
        }
      } else if (err.request) {
        setError('No response from server. Please try again later.');
      } else {
        setError('An unexpected error occurred.');
      }
    } finally {
      setLoading(false);
    }
  };

  const extractImagePaths = (htmlContent) => {
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlContent, 'text/html');
    const images = doc.querySelectorAll('img');
    const imagePaths = [];

    images.forEach((img) => {
      let src = img.getAttribute('src');
      if (src && !src.startsWith('data:') && !src.startsWith('http')) {
        src = src.startsWith('/') ? src : `/${src}`;
        src = decodeURIComponent(src);
        imagePaths.push(src);
      }
    });
    return imagePaths;
  };

  const saveAssistantCode = async (codeContent) => {
    if (!currentConversation) {
      alert('Please select or create a conversation first.');
      return;
    }

    try {
      let modifiedCodeContent = codeContent;
      const imagePaths = extractImagePaths(codeContent);

      for (const imagePath of imagePaths) {
        // Remove leading slash to match IndexedDB storage path
        const dbPath = `folders${imagePath}`;
        const record = await indexedDBGet(dbPath);
        if (record) {
          const dataURL = decryptData(record.content);
          const escapedImagePath = imagePath.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
          const regex = new RegExp(escapedImagePath, 'g');
          modifiedCodeContent = modifiedCodeContent.replace(regex, dataURL);
        } else {
          console.error(`Image file ${imagePath} not found in IndexedDB.`);
        }
      }

      await writeFile('index.html', modifiedCodeContent, currentConversation.id);

      // Update lastModified after saving
      setConversations((prevConvos) =>
        prevConvos.map((convo) =>
          convo.id === currentConversation.id ? { ...convo, lastModified: Date.now() } : convo
        )
      );
    } catch (err) {
      console.error('Error saving code:', err);
      alert('Failed to save code.');
    }
  };

  const handleResetConversation = () => {
    if (window.confirm('Are you sure you want to reset the current conversation?')) {
      setMessages([]);
      setIndexContent(obscureHtmlCode(initConv));
      checkUserLimit();
    }
  };

  const handleUpgrade = () => {
    navigate('/subscription');
    setIsLimitReached(false);
  };

  const openCreateFolderModal = () => {
    setNewFolderName('');
    setIsCreateFolderModalOpen(true);
  };

  const closeCreateFolderModal = () => {
    setIsCreateFolderModalOpen(false);
  };

  const handleCreateFolder = async () => {
    if (!newFolderName.trim()) {
      alert('Folder name cannot be empty.');
      return;
    }

    const invalidChars = /[<>:"/\\|?*\x00-\x1F]/g;
    if (invalidChars.test(newFolderName)) {
      alert('Folder name contains invalid characters.');
      return;
    }

    try {
      const existingKeys = await indexedDBListByPrefix(`folders/${newFolderName}/`);
      if (existingKeys.length > 0) {
        alert('A folder with this name already exists.');
        return;
      }

      const folderMetadata = {
        name: newFolderName,
        createdAt: Date.now(),
        lastModified: Date.now(),
        allowedUsers: [actualUser.id],
      };
      await writeFile('folder.json', JSON.stringify(folderMetadata, null, 2), null, newFolderName);

      const newFolder = { name: newFolderName, lastModified: folderMetadata.lastModified };
      setFolders((prev) => [newFolder, ...prev]);
      alert(`Folder "${newFolderName}" created successfully.`);
      closeCreateFolderModal();
      setDisplayedFolders((prev) => prev + 1);
    } catch (err) {
      console.error('Error creating folder:', err);
      alert('Failed to create folder.');
    }
  };

  // Toggle folder expansion
const toggleFolderExpansion = (folderName) => {
  setExpandedFolders((prev) => ({
    ...prev,
    [folderName]: !prev[folderName],
  }));

  if (!expandedFolders[folderName] && !filesInFolders[folderName]) {
    loadFilesInFolder(folderName);
  }
};


const loadFilesInFolder = async (folderName) => {
  try {
    const keys = await indexedDBListByPrefix(`folders/${folderName}/`);
    const files = keys
      .map(k => k.split('/').pop())
      .filter(f => f !== 'folder.json');
    setFilesInFolders((prev) => ({
      ...prev,
      [folderName]: files,
    }));
  } catch (err) {
    console.error(`Error loading files for folder "${folderName}":`, err);
    alert(`Failed to load files for folder "${folderName}".`);
  }
};


  // Handle file selection
const handleSelectFile = (folderName, fileName) => {
  const sanitizedFileName = sanitizeFileName(fileName);
  const relativePath = `/${folderName}/${sanitizedFileName}`;
  insertAtCursor('"' + relativePath + '" ');
};


  const insertAtCursor = (insertText) => {
    const textarea = document.getElementById('prompt-textarea');
    if (!textarea) return;

    const startPos = textarea.selectionStart;
    const endPos = textarea.selectionEnd;
    const before = prompt.substring(0, startPos);
    const after = prompt.substring(endPos, prompt.length);
    const newText = before + insertText + after;
    setPrompt(newText);

    setTimeout(() => {
      textarea.selectionStart = textarea.selectionEnd = startPos + insertText.length;
      textarea.focus();
    }, 0);
  };

  const handleTextareaKeyDown = (e) => {
    // You can customize how the text area behaves on key down
  };

  const getConversationIndexContent = async (conversation) => {
    if (!conversation) {
      setIndexContent(obscureHtmlCode(initConv));
      return;
    }

    try {
      const idxContent = await readFile('index.html', conversation.id);

      if (idxContent && idxContent.trim()) {
        const modifiedContent = injectIframeClickListener(idxContent);
        setIndexContent(obscureHtmlCode(modifiedContent));
      } else {
        setIndexContent(obscureHtmlCode(initConv));
      }
    } catch (err) {
      console.error('Error getting index.html content:', err);
      setIndexContent(obscureHtmlCode(initConv));
    }
  };

  // Function to inject click listener script into HTML content
  const injectIframeClickListener = (htmlContent) => {
    const script = `
    <style>
    body{
      overflow: auto;
    }
      /* width */
::-webkit-scrollbar {
  width: 10px;
   height: 10px;
}

/* Track */
::-webkit-scrollbar-track {
  background: #f1f1f1;
}

/* Handle */
::-webkit-scrollbar-thumb {
  background: #53a0ff;
  border-radius: 10px;

}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #2a7cff;
}
    </style>

    <script>
    window.onerror = function(message, source, lineno, colno, error) {
      parent.postMessage({
        type: 'iframeError',
        payload: { message, source, lineno, colno, error: error.toString() }
      }, '*');
    };
      document.addEventListener('click', () => {
        parent.postMessage({ type: 'iframe-click' }, '*');
      });
    </script>
    `;
    if (htmlContent.includes('</body>')) {
      return htmlContent.replace('</body>', `${script}</body>`);
    } else {
      return htmlContent + script;
    }
  };

  useEffect(() => {
    const handleMessage = async (event) => {
      if (iframeRef.current && event.source === iframeRef.current.contentWindow) {
        const { type, payload } = event.data;

        switch (type) {
          case 'READ_FILE':
            try {
              const data = await readFile(payload.filename, currentConversation?.id || null);
              console.log('data');
              console.log(data);
              console.log('data');

              event.source.postMessage(
                {
                  type: 'FILE_CONTENT',
                  payload: { filename: payload.filename, content: data == "" ? "{}" : data },
                },
                '*'
              );
            } catch (err) {
              console.error(`Error reading file ${payload.filename}:`, err);
              event.source.postMessage(
                { type: 'ERROR', payload: `Failed to read file ${payload.filename}.` },
                '*'
              );
            }
            break;
          case 'WRITE_FILE':
            try {
              await writeFile(payload.filename, payload.content, currentConversation?.id || null);
              event.source.postMessage(
                { type: 'WRITE_SUCCESS', payload: { filename: payload.filename } },
                '*'
              );
            } catch (err) {
              console.error(`Error writing to file ${payload.filename}:`, err);
              event.source.postMessage(
                { type: 'ERROR', payload: `Failed to write file ${payload.filename}.` },
                '*'
              );
            }
            break;
          case 'iframe-click':
            setIsProfileDropdownOpen(false);
            setIsServiceDropdownOpen(false);

            const isMobile = window.innerWidth < 600; // Define your mobile breakpoint
        if (isMobile) {
          setIsSidebarOpen(false);
        }

            handleClick(); // Increment click count when iframe is clicked
            break;
          default:
            console.warn('Unknown message type:', type);
            break;
        }
      }
    };

    window.addEventListener('message', handleMessage);
    return () => {
      window.removeEventListener('message', handleMessage);
    };
  }, [currentConversation]);

  const lastAssistantMessage = messages.slice().reverse().find((msg) => msg.sender === 'assistant');

  const handlePerFolderFileUpload = async (event) => {
    const files = event.target.files;
    const folderName = event.target.getAttribute('data-folder');
    if (files.length === 0 || !folderName) return;
  
    try {
      for (const file of files) {
        let fileName = file.name;
        // Sanitize file name by replacing spaces with underscores
        let sanitizedFileName = sanitizeFileName(fileName);
        const keys = await indexedDBListByPrefix(`folders/${folderName}/`);
        while (keys.includes(`folders/${folderName}/${sanitizedFileName}`)) {
          const nameParts = sanitizedFileName.split('.');
          const extension = nameParts.pop();
          const baseName = nameParts.join('.');
          fileName = `${baseName}(1).${extension}`;
          sanitizedFileName = sanitizeFileName(fileName);
        }
        const dataURL = await readFileAsDataURL(file);
        await writeFile(sanitizedFileName, dataURL, null, folderName);
      }
  
      const keysAfterUpload = await indexedDBListByPrefix(`folders/${folderName}/`);
      const filesList = keysAfterUpload
        .map(k => k.split('/').pop())
        .filter(f => f !== 'folder.json');
      setFilesInFolders((prev) => ({
        ...prev,
        [folderName]: filesList,
      }));
  
      alert('Files uploaded successfully!');
      setCurrentUploadFolder(null);
      if (uploadFileInputRef.current) {
        uploadFileInputRef.current.value = '';
      }
    } catch (err) {
      console.error('Error uploading files:', err);
      alert('Failed to upload files.');
    }
  };
  

  const toggleConversationsCollapse = () => {
    setIsConversationsCollapsed(!isConversationsCollapsed);
  };

  const toggleFoldersCollapse = () => {
    setIsFoldersCollapsed(!isFoldersCollapsed);
  };

  const toggleFavoriteAppsCollapse = () => {
    setIsFavoriteAppsCollapsed(!isFavoriteAppsCollapsed);
  };

  const [isSendingClicks, setIsSendingClicks] = useState(false);
  const isSendingClicksRef = useRef(false);

  useEffect(() => {
    isSendingClicksRef.current = isSendingClicks;
  }, [isSendingClicks]);

  useEffect(() => {
    const path = location.pathname;
    if (path.startsWith('/chat/') && path.endsWith('.bin')) {
      // ======= ADDED LINE BELOW =======
      secureLocalStorage.setItem('fromExample', 'true');
      // ===============================
      const exampleURL = `exampleURL`;
      secureLocalStorage.setItem(exampleURL, location.pathname);

      console.log('Just set fromExample to:', secureLocalStorage.getItem('fromExample'));
      (async () => {
        try {
          // 1. Fetch the .bin file from /public
          const binFileName = path.replace('/chat/', '');
          const response = await fetch(`/${binFileName}`);
          if (!response.ok) {
            throw new Error(`Failed to fetch .bin file. Status: ${response.status}`);
          }

          // 2. Decrypt/parse
          const fileContent = await response.text();
          const decrypted = decryptData(fileContent);
          const data = JSON.parse(decrypted);
          if (!data.name) {
            throw new Error('Imported conversation data must include a name.');
          }

          // 3. Check if conversation already exists
          const existingConversationIds = conversations.map((c) => c.id);
          let importedId = data.id || uuidv4();
          const alreadyExists = existingConversationIds.includes(importedId);

          if (alreadyExists) {
            // If it already exists, just load it
            const existingConversation = conversations.find((c) => c.id === importedId);
            if (existingConversation) {
              await handleLoadConversation(existingConversation);
            }
          } else {
            // Otherwise, import and open it
            const conversationJsonEntry = data.entries.find((e) => e.name === 'conversation.json');
            if (conversationJsonEntry) {
              const convoDecrypted = decryptData(conversationJsonEntry.content);
              const convoObj = JSON.parse(convoDecrypted);
              convoObj.id = importedId;
              convoObj.allowedUsers = [actualUser.id];
              convoObj.lastModified = Date.now();

              const uniqueName = await getUniqueConversationName(data.name);
              convoObj.name = uniqueName;
              conversationJsonEntry.content = encryptData(JSON.stringify(convoObj, null, 2));

              data.id = importedId;
              data.name = uniqueName;
            }

            // Import
            await importSingleConversation(data);
            alert(`Imported conversation successfully as "${data.name}"!`);

            // Reload & open newly imported
            const updatedConvs = await loadConversations();
            const newlyCreatedConvo = updatedConvs.find((c) => c.id === importedId);
            if (newlyCreatedConvo) {
              await handleLoadConversation(newlyCreatedConvo);
            }
          }
        } catch (err) {
          console.error('Error auto-importing .bin from URL:', err);
        } finally {
          navigate('/chat', { replace: true });
        }
      })();
    }

    const sendSourceToBackend = async (source) => {
      try {
        await api.post('/visit', { source: JSON.stringify(source), userId: actualUser.id });
      } catch (error) {
        console.error('Error sending source to backend:', error);
      }
    };

    const getUTMParams = () => {
      const params = new URLSearchParams(location.search);
      const utm_source = params.get('utm_source');
      const utm_medium = params.get('utm_medium');
      const utm_campaign = params.get('utm_campaign');
      return { utm_source, utm_medium, utm_campaign };
    };

    const determineSource = () => {
      const fromExample = `fromExample`;
      const exampleURL = `exampleURL`;
      const { utm_source, utm_medium, utm_campaign } = getUTMParams();
      if (utm_source) {
        return { utm_source, utm_medium, utm_campaign };
      } else if (document.referrer) {
        try {
          const referrerUrl = new URL(document.referrer);
          return {
            visitedPage: 'Chat page',
            fromExample: secureLocalStorage.getItem(fromExample),
            exampleURL: secureLocalStorage.getItem(exampleURL),
            URL: referrerUrl.toString(),
            hash: referrerUrl.hash,
            host: referrerUrl.host,
            hostname: referrerUrl.hostname,
            href: referrerUrl.href,
            origin: referrerUrl.origin,
            password: referrerUrl.password,
            pathname: referrerUrl.pathname,
            port: referrerUrl.port,
            protocol: referrerUrl.protocol,
            search: referrerUrl.search,
            searchParams: Object.fromEntries(referrerUrl.searchParams.entries()),
            username: referrerUrl.username,
          };
        } catch (err) {
          console.error('Error parsing referrer URL:', err);
          return null;
        }
      }
      return null;
    };

    const sourceSentFlag = `sourceSentChat_${actualUser.id}`;
    const fromExample = `fromExample`;
    const exampleURL = `exampleURL`;

    console.log('secureLocalStorage.getItem(fromExample)');
    console.log(secureLocalStorage.getItem(fromExample));
    console.log('secureLocalStorage.getItem(fromExample)');

    if (!secureLocalStorage.getItem(sourceSentFlag)) {
      const source = determineSource();
      if (source) {
        sendSourceToBackend(source).then(() => {
          secureLocalStorage.setItem(sourceSentFlag, 'true');
        });
      } else {
        sendSourceToBackend({
          visitedPage: "Chat page",
          fromExample: secureLocalStorage.getItem(fromExample),
          exampleURL: secureLocalStorage.getItem(exampleURL),
        }).then(() => {
          secureLocalStorage.setItem(sourceSentFlag, 'true');
        });
      }
    }
  }, [location.search, actualUser.id, location.pathname, conversations]);

  const sendClickCountToBackend = async (userId, clickCount, conversationCount, favoriteCount) => {
    try {
      await api.post('/clicks', { userId, clickCount, conversationCount, favoriteCount });
    } catch (error) {
      console.error('Failed to send click count and conversation count:', error);
      throw error;
    }
  };

  const handleClick = () => {
    const CLICK_THRESHOLD = 20;
    const userId = actualUser.id;

    const currentCount = parseInt(secureLocalStorage.getItem('clickCount_' + userId)) || 0;
    const newCount = currentCount + 1;
    secureLocalStorage.setItem('clickCount_' + userId, newCount.toString());

    if (newCount >= CLICK_THRESHOLD && !isSendingClicksRef.current) {
      setIsSendingClicks(true);
      isSendingClicksRef.current = true;

      const currentConversationCount = conversationCountRef.current;
      const currentFavoriteCount = favoriteConversations.length;

      sendClickCountToBackend(userId, CLICK_THRESHOLD, currentConversationCount, currentFavoriteCount)
        .then(() => {
          const latestCount = parseInt(secureLocalStorage.getItem('clickCount_' + userId)) || 0;
          const updatedCount = latestCount - CLICK_THRESHOLD;
          secureLocalStorage.setItem(
            'clickCount_' + userId,
            (updatedCount < 0 ? 0 : updatedCount).toString()
          );
          checkUserLimit();
        })
        .catch((error) => {
          console.error('Error sending click count to backend:', error);
        })
        .finally(() => {
          setIsSendingClicks(false);
          isSendingClicksRef.current = false;
        });
    }
  };

  useEffect(() => {
    const handlePageClick = () => {
      handleClick();
    };

    document.addEventListener('click', handlePageClick);

    return () => {
      document.removeEventListener('click', handlePageClick);
    };
  }, [actualUser.id, favoriteConversations.length]);

  // API Key Modal Handlers
  const openKeyModal = () => {
    setApiKeyError(null);
    setKeyInput(''); // Clear previous input
    setIsKeyModalOpen(true);
  };

  const closeKeyModal = () => {
    setApiKeyError(null);
    setIsKeyModalOpen(false);
    setKeyInput('');
  };

  const handleSaveKey = async () => {
    setApiKeyError(null);
    if (!keyInput.trim()) {
      setApiKeyError('API key cannot be empty.');
      return;
    }
    const service = selectedService;

    if (actualUser.id === "777777777") {
      // For Gemini, we do a quick check if possible (optional).
      if (service === "Gemini") {
        try {
          const { GoogleGenerativeAI } = await import("@google/generative-ai");
          const testGenAI = new GoogleGenerativeAI(keyInput.trim());
          const testModel = testGenAI.getGenerativeModel({
            model: "gemini-2.0-flash-thinking-exp-1219",
          });

          const testChatSession = testModel.startChat({
            generationConfig: {
              temperature: 1,
              topP: 0.95,
              topK: 64,
              maxOutputTokens: 2,
              responseMimeType: "text/plain",
            },
            history: [],
          });

          await testChatSession.sendMessage("test");
        } catch (err) {
          console.error("Gemini test error: ", err);
          setApiKeyError("Invalid Gemini API key. Please check and try again.");
          return;
        }
      }

      // Unauthenticated user: save in localStorage (secureLocalStorage)
      const keyName = `${service.toLowerCase()}ApiKey`;
      secureLocalStorage.setItem(keyName, keyInput.trim());

      // Update API key status in state and localStorage
      setApiKeyStatus((prevStatus) => ({
        ...prevStatus,
        [serviceKeyMap[service]]: true,
      }));
      secureLocalStorage.setItem(
        `apiKeyStatus_${actualUser.id}`,
        JSON.stringify({
          ...apiKeyStatus,
          [serviceKeyMap[service]]: true,
        })
      );

      setHasApiKey(
        Object.values({ ...apiKeyStatus, [serviceKeyMap[service]]: true }).some(
          (status) => status === true
        )
      );

      setIsKeyModalOpen(false);
      setKeyInput('');
      setApiKeyError(null);
      alert(`${service} API key saved successfully.`);
    } else {
      // Authenticated user: save to backend
      try {
        await api.post('/user/apiKey', { service, apiKey: keyInput.trim() });

        // After saving, fetch the updated API key status
        const response = await api.get('/user/apiKeyStatus');
        const apiKeyStatusResponse = response.data;

        setApiKeyStatus(apiKeyStatusResponse);
        setHasApiKey(Object.values(apiKeyStatusResponse).some(status => status === true));

        // Save to localStorage
        secureLocalStorage.setItem(
          `apiKeyStatus_${actualUser.id}`,
          JSON.stringify(apiKeyStatusResponse)
        );

        setIsKeyModalOpen(false);
        setKeyInput('');
        setApiKeyError(null);
        alert(`${service} API key saved successfully.`);
      } catch (err) {
        console.error('Error saving API key:', err);
        const errorMsg = err.response?.data?.error || 'Failed to save API key.';
        setApiKeyError(errorMsg);
      }
    }
  };

  const importSingleFileInputRef = useRef(null);

  //
  // ======================== EXPORT SINGLE CONVERSATION ========================
  //
  const handleExportSingleConversation = async (conversation) => {
    if (!conversation) {
      alert('No conversation selected.');
      return;
    }

    try {
      // Gather all files belonging to the conversation
      const gatherFiles = async (convoId) => {
        const keys = await indexedDBListByPrefix(`conversations/${convoId}/`);
        const files = [];
        for (const key of keys) {
          const record = await indexedDBGet(key);
          const content = record.content;
          if (key.endsWith('conversation.json')) {
            const decrypted = decryptData(content);
            const convoData = JSON.parse(decrypted);
            // Keep ID intact, add/replace allowedUsers with current user
            convoData.allowedUsers = [actualUser.id];
            const newContent = JSON.stringify(convoData, null, 2);
            const reEncrypted = encryptData(newContent);
            files.push({ type: 'file', name: 'conversation.json', content: reEncrypted });
          } else {
            const name = key.split('/').pop();
            files.push({ type: 'file', name, content });
          }
        }

        return {
          type: 'directory',
          name: conversation.name,
          entries: files,
        };
      };

      const conversationDirData = await gatherFiles(conversation.id);

      // Encrypt the entire directory listing
      const jsonString = JSON.stringify(conversationDirData);
      const packageEncrypted = encryptData(jsonString);

      // Create a Blob and download
      const blob = new Blob([packageEncrypted], { type: 'application/octet-stream' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${conversation.name}_conversation.bin`;
      a.click();
      URL.revokeObjectURL(url);

      alert(`Exported conversation "${conversation.name}" successfully!`);
    } catch (err) {
      console.error('Error exporting single conversation:', err);
      alert('Failed to export single conversation.');
    }
  };

  //
  // ======================== IMPORT SINGLE CONVERSATION ========================
  //
  const importSingleConversation = async (data) => {
    try {
      const processDir = async (dataObj, prefix) => {
        for (const entry of dataObj.entries) {
          if (entry.type === 'file') {
            const path = `${prefix}/${entry.name}`;
            await indexedDBPut({ path, content: entry.content });
          } else if (entry.type === 'directory') {
            await processDir(entry, `${prefix}/${entry.name}`);
          }
        }
      };
      // Actually store all files under conversations/{data.id}
      await processDir(data, `conversations/${data.id}`);
    } catch (err) {
      console.error('Error importing single conversation:', err);
      throw err;
    }
  };

  const getUniqueConversationName = async (baseName) => {
    let uniqueName = baseName;
    const convoNames = conversations.map(c => c.name);
    if (convoNames.includes(uniqueName)) {
      let counter = 2;
      while (convoNames.includes(`${baseName}(${counter})`)) {
        counter++;
      }
      uniqueName = `${baseName}(${counter})`;
    }
    return uniqueName;
  };

  const handleImportSingleConversation = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    try {
      const fileContent = await file.text();
      const decrypted = decryptData(fileContent);
      const data = JSON.parse(decrypted);

      // Ensure the data has a name
      if (!data.name) {
        throw new Error('Imported conversation data must include a name.');
      }

      // 1) Check if data.id collides with an existing conversation ID
      const existingConversationIds = conversations.map((c) => c.id);
      let importedId = data.id || uuidv4();
      if (existingConversationIds.includes(importedId)) {
        importedId = uuidv4();
      }
      data.id = importedId;

      // Overwrite the conversation.json inside data.entries
      const conversationJsonEntry = data.entries.find((e) => e.name === 'conversation.json');
      if (conversationJsonEntry) {
        const convoDecrypted = decryptData(conversationJsonEntry.content);
        const convoObj = JSON.parse(convoDecrypted);

        convoObj.id = data.id;
        convoObj.allowedUsers = [actualUser.id];
        convoObj.lastModified = Date.now(); // Update lastModified

        const uniqueName = await getUniqueConversationName(data.name);
        convoObj.name = uniqueName;

        const newConvoContent = JSON.stringify(convoObj, null, 2);
        conversationJsonEntry.content = encryptData(newConvoContent);

        data.name = uniqueName;
      }

      // Import into IndexedDB
      await importSingleConversation(data);

      alert(`Imported conversation successfully as "${data.name}"!`);

      // 1) Reload conversation list
      const updatedConvs = await loadConversations();
      // 2) Find the newly created conversation by id
      const newlyImportedConvo = updatedConvs.find((c) => c.id === data.id);
      // 3) If found, load it immediately
      if (newlyImportedConvo) {
        await handleLoadConversation(newlyImportedConvo);
      }
    } catch (err) {
      console.error('Error importing single conversation:', err);
      alert('Failed to import single conversation.');
    } finally {
      if (importSingleFileInputRef.current) {
        importSingleFileInputRef.current.value = '';
      }
    }
  };
// Handle file uploads to a specific folder
const handleUploadFiles = async (folderName) => {
  setCurrentUploadFolder(folderName);
  if (uploadFileInputRef.current) {
    uploadFileInputRef.current.setAttribute('data-folder', folderName);
    uploadFileInputRef.current.click();
  }
};
 // Handle folder deletion
const handleDeleteFolder = async (folderName) => {
  if (!window.confirm(`Are you sure you want to delete the folder "${folderName}" and all its contents?`)) {
    return;
  }

  try {
    const keys = await indexedDBListByPrefix(`folders/${folderName}/`);
    for (const key of keys) {
      await indexedDBDelete(key);
    }

    setFolders((prevFolders) => prevFolders.filter(folder => folder.name !== folderName));

    setExpandedFolders((prev) => {
      const newExpanded = { ...prev };
      delete newExpanded[folderName];
      return newExpanded;
    });
    setFilesInFolders((prev) => {
      const newFiles = { ...prev };
      delete newFiles[folderName];
      return newFiles;
    });

    alert(`Folder "${folderName}" and all its contents have been deleted successfully.`);
  } catch (err) {
    console.error(`Error deleting folder "${folderName}":`, err);
    alert(`Failed to delete folder "${folderName}".`);
  }
};


// Handle file deletion
const handleDeleteFile = async (folderName, fileName) => {
  if (!window.confirm(`Are you sure you want to delete the file "${fileName}" from folder "${folderName}"?`)) {
    return;
  }

  try {
    const sanitizedFileName = sanitizeFileName(fileName);
    const path = `folders/${folderName}/${sanitizedFileName}`;
    await indexedDBDelete(path);

    setFilesInFolders((prev) => {
      const updatedFiles = prev[folderName]?.filter(f => f !== fileName) || [];
      return {
        ...prev,
        [folderName]: updatedFiles,
      };
    });

    alert(`File "${fileName}" has been deleted successfully from folder "${folderName}".`);
  } catch (err) {
    console.error(`Error deleting file "${fileName}" from folder "${folderName}":`, err);
    alert(`Failed to delete file "${fileName}" from folder "${folderName}".`);
  }
};


  const [showMessages, setShowMessages] = useState(false);
  const toggleMessages = () => setShowMessages(prev => !prev);

  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  // Add this for iFrame full-screen
  const [isIframeFullScreen, setIsIframeFullScreen] = useState(false);
  const toggleIframeFullScreen = () => {
    setIsIframeFullScreen(!isIframeFullScreen);
  };

  useEffect(() => {
    (async () => {
      // 1) Wait for all the data to finish loading
      const convs = await loadConversations();
      const path = location.pathname;

      if (convs.length === 0 && path.startsWith('/chat/') && path.endsWith('.bin')) {
        // Handled in a previous useEffect
      } else if (convs.length === 0) {
        // 2) If no conversations found, create "Conversation 1"
        const convoName = "Conversation 1";
        const uniqueId = uuidv4();
        const conversationData = {
          id: uniqueId,
          name: convoName,
          allowedUsers: [actualUser.id],
          messages: [],
          lastModified: Date.now(),
        };
        await writeFile('conversation.json', JSON.stringify(conversationData, null, 2), uniqueId);
        // Update state
        const newConversation = { id: uniqueId, name: convoName, lastModified: Date.now() };
        setConversations((prev) => [newConversation, ...prev]);
        setCurrentConversation(newConversation);
        setMessages([]);
        setIndexContent(obscureHtmlCode(initConv));
        alert(`Conversation "${convoName}" created successfully.`);
        setIsDataLoading(false);
      } else {
        // 3) If conversations exist, open the most recent one
        const lastConvo = convs[0];
        await handleLoadConversation(lastConvo);
      }
    })();
  }, []);





  const handleClickOutsideSidebar = (event) => {
    if (
      sidebarRef.current &&
      !sidebarRef.current.contains(event.target) &&
      toggleButtonRef.current &&
      !toggleButtonRef.current.contains(event.target)
    ) {
      // Define the breakpoint for mobile screens (e.g., 768px)
      const isMobile = window.innerWidth < 600;
      if (isMobile) {
        setIsSidebarOpen(false);
      }
    }
  };
  
  useEffect(() => {
    // Add the event listener for detecting clicks outside the sidebar
    document.addEventListener('mousedown', handleClickOutsideSidebar);
  
    // Clean up the event listener on component unmount
    return () => {
      document.removeEventListener('mousedown', handleClickOutsideSidebar);
    };
  }, [isSidebarOpen]); // Re-run the effect if `isSidebarOpen` changes
  

  return (
    <div className="chat-page">
      {isDataLoading && (
        <div className="loading-overlay">
          {/* <div className="spinner"></div> */}
          Logo aritdwaaar
        </div>
      )}

      {/* Limit Reached Bar */}
      {isLimitReached && (
        <div className="limit-reached-bar">
          <span>You have reached the usage limit. Upgrade your account to continue using all features.</span>
          <button onClick={handleUpgrade} className="upgrade-account-btn">
            Upgrade Account
          </button>
        </div>
      )}

      {/* Top Bar with Toggle Button */}
      <div className="top-bar">
        <div className="usage-info">
          <p>
            Click Count: {currentClickCount} / {clickLimit}
          </p>
        </div>

        <button
          className="profile"
          onClick={() => setIsProfileDropdownOpen((prev) => !prev)}
          ref={profileButtonRef}
        >
          <AiOutlineCodeSandbox />
        </button>


        <button
          className="review"
          onClick={handleOpenReview}
        >
          <FaRegStar />
        </button>

        {/* Profile Button with Dropdown */}
        <div className="profile-dropdown-container">
          {isProfileDropdownOpen && (
            <div className="profile-dropdown" ref={dropdownRef}>
              {/* Menu Items to Open Modals */}
              {LMARHALA == 2 && (
                <button
                  className="dropdown-item"
                  onClick={() => {
                    setActiveModal('profile');
                    setIsProfileDropdownOpen(false);
                  }}
                >
                  Subscription Status
                </button>
              )}

              <button
                className="dropdown-item"
                onClick={() => {
                  setActiveModal('help');
                  setIsProfileDropdownOpen(false);
                  handleOpenHelp();
                }}
              >
                Help
              </button>

              <button
    onClick={
      () => {
      setIsShareModalOpen(true);
      setActiveModal('share');
      setIsProfileDropdownOpen(false);
      handleOpenHelp();
    }}
    className="dropdown-item"
    disabled={isLimitReached}
  >
    Share
  </button>

              {LMARHALA != 0 && <LogoutButton className="dropdown-item" />}
            </div>
          )}
        </div>
        <button
        ref={toggleButtonRef}
          className={`toggle-sidebar-btn ${isSidebarOpen ? 'open' : 'closed'}`}
          onClick={toggleSidebar}
          aria-label={isSidebarOpen ? 'Hide Sidebar' : 'Show Sidebar'}
        >
          {/* {isSidebarOpen ? '←' : '→'} */}
          {isSidebarOpen ? <TbLayoutSidebarLeftCollapseFilled /> : <TbLayoutSidebarLeftExpand />}
        </button>


        <div className={`api-key-section ${isSidebarOpen ? 'open' : 'closed'}`}>
          <ServiceDropdown
            supportedServices={supportedServices}
            apiKeyStatus={apiKeyStatus}
            serviceKeyMap={serviceKeyMap}
            selectedService={selectedService}
            setSelectedService={setSelectedService}
            onAddOrUpdate={(service) => {
              setSelectedService(service);
              openKeyModal();
              setIsServiceDropdownOpen(false); // Close dropdown after clicking Add/Update
            }}
            isLimitReached={isLimitReached}
            isOpen={isServiceDropdownOpen}
            setIsOpen={setIsServiceDropdownOpen}
          />
        </div>




      </div>

      {/* Sidebar */}
      <div className={`sidebar ${isSidebarOpen ? 'open' : 'closed'}`} ref={sidebarRef}>
        {/* API Key Section */}




        <button
          onClick={handleCreateConversation}
          className={`new-conversation-btn ${isSidebarOpen ? 'open' : 'closed'}`}
          disabled={isLimitReached}
        >
          New Conversation
        </button>


        <div>

          



        </div>

        <ReviewModal
          show={reviewModalShow}
          handleClose={handleCloseReview}
          displayinputname={actualUser.id === "777777777"}
        />

      



        <div className="import-conversation-div">
          <button
            className="import-conversation-btn"
            onClick={() => setIsImportDropdownOpen(!isImportDropdownOpen)}
            disabled={isLimitReached}
          >
            Import Conversation
          </button>



          {isImportDropdownOpen && (
            <div className="import-dropdown">
              <button
                onClick={() => {
                  setIsImportDropdownOpen(false);
                  if (importSingleFileInputRef.current) {
                    importSingleFileInputRef.current.click();
                  }
                }}
                className="dropdown-option"
                disabled={isLimitReached}
              >
                From Device
              </button>
              <button
                onClick={() => {
                  setIsImportDropdownOpen(false);
                  setIsImportLinkModalOpen(true);
                }}
                className="dropdown-option"
                disabled={isLimitReached}
              >
                From Link
              </button>
            </div>
          )}

          <input
            type="file"
            ref={importSingleFileInputRef}
            style={{ display: 'none' }}
            onChange={handleImportSingleConversation}
            disabled={isLimitReached}
          />

          <Modal
            isOpen={isImportLinkModalOpen}
            onRequestClose={() => setIsImportLinkModalOpen(false)}
            contentLabel="Import from URL"
            className="import-link-modal"
            overlayClassName="import-link-modal-overlay"
            ariaHideApp={false}
          >
            {loadingImportLink && (
              <div className="loading-overlay-import-link">
                {/* <div className="spinner"></div> */}
                loading aritdwaaar
              </div>
            )}
            <div className="modal-content">
              <h2>Import Conversation from URL</h2>
              <input
                type="url"
                placeholder="Enter the URL of the conversation file"
                value={importUrl}
                onChange={(e) => setImportUrl(e.target.value)}
                className="import-url-input"
                ref={importLinkInputRef}
              />
              <div className="modal-buttons">
                <button
                  onClick={handleImportFromLink}
                  className="btn import-link-btn"
                >
                  Import
                </button>
                <button
                  onClick={() => setIsImportLinkModalOpen(false)}
                  className="btn close-modal-btn"
                >
                  Cancel
                </button>
              </div>
            </div>
          </Modal>

        </div>



   {/* Conversations Section */}
   <ConversationsSection
          conversations={conversations}
          displayedConversations={displayedConversations}
          setDisplayedConversations={setDisplayedConversations}
          isConversationsCollapsed={isConversationsCollapsed}
          toggleConversationsCollapse={toggleConversationsCollapse}
          currentConversation={currentConversation}
          isLimitReached={isLimitReached}
          favoriteConversations={favoriteConversations}
          toggleFavoriteConversation={toggleFavoriteConversation}
          handleDeleteConversation={handleDeleteConversation}
          handleExportSingleConversation={handleExportSingleConversation}
          openRenameConversationModal={openRenameConversationModal}
          handleSelectConversation={handleSelectConversation}
        />

        {/* Favorite Apps Section */}
<FavoriteApps
  favoriteConversations={favoriteConversations}
  conversations={conversations}
  currentConversation={currentConversation}
  isLimitReached={isLimitReached}
  removeFavoriteConversation={removeFavoriteConversation}
  handleSelectConversation={handleSelectConversation}
/>

       
       

        {/* Folders Section */}
<FoldersSection
  folders={folders}
  expandedFolders={expandedFolders}
  toggleFolderExpansion={toggleFolderExpansion}
  filesInFolders={filesInFolders}
  handleSelectFile={handleSelectFile}
  handleDeleteFile={handleDeleteFile}
  handleDeleteFolder={handleDeleteFolder}
  handleUploadFiles={handleUploadFiles}
  openCreateFolderModal={openCreateFolderModal}
  isLimitReached={isLimitReached}
  displayedFolders={displayedFolders}
  setDisplayedFolders={setDisplayedFolders}
/>

      </div>

      {/* Main Chat Area */}
      <div className={`main-chat ${isSidebarOpen ? 'with-sidebar' : 'full-width'}`}>
        <div className={`iframe-container ${isIframeFullScreen ? 'full-screen' : ''}`}>
          <iframe
            ref={iframeRef}
            title="Rendered Output"
            className="rendered-iframe"
            srcDoc={indexContent}
            sandbox="allow-scripts allow-same-origin allow-downloads allow-popups allow-modals allow-forms"
          ></iframe>
          <button
            className="toggle-fullscreen-btn"
            onClick={toggleIframeFullScreen}
          >
            {isIframeFullScreen ? <FaTimes size={20} /> : <MdFullscreen size={24} />}
          </button>
        </div>

        <div className="messages-toggle-bar" onClick={toggleMessages}>
          {showMessages ? 'Hide Messages' : 'Show Messages'}
        </div>

        <div className={`messages-section ${showMessages ? 'visible' : 'hidden'}`}>
          <div className="messages-container">
            {messages
              .filter(msg => msg.sender === 'user') // Only include user messages
              .map((msg, index) => (
                <div key={index} className={`message ${msg.sender}`}>
                  <div className="message-content">{msg.content}</div>
                </div>
              ))
            }
            <div ref={messagesEndRef} />
          </div>
        </div>

        <div className="input-area">
          {loading && (
            <div className="loading-overlay-send">
              {/* <div className="spinner"></div> */}
              Generate App
            </div>
          )}

          <textarea
            id="prompt-textarea"
            ref={promptInputRef}
            placeholder="Enter your request (e.g., I want a landing page)... Type '/' to insert a file path."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={handleTextareaKeyDown}
            disabled={!currentConversation || loading || isLimitReached}
          />
          <div className="buttons">
            <button
              onClick={handleSend}
              disabled={loading || !currentConversation || isLimitReached}
              className="btn send-btn"
            >
              {loading ? 'Generating...' : 'Send'}
            </button>
          </div>
        </div>

        {/* Create Folder Modal */}
        <Modal
          isOpen={isCreateFolderModalOpen}
          onRequestClose={closeCreateFolderModal}
          contentLabel="Create New Folder"
          className="image-modal"
          overlayClassName="image-modal-overlay"
          ariaHideApp={false}
        >
          <div className="modal-content">
            <h2>Create New Folder</h2>
            <input
              type="text"
              placeholder="Enter folder name"
              value={newFolderName}
              onChange={(e) => setNewFolderName(e.target.value)}
              className="folder-input"
              disabled={isLimitReached}
            />
            <div className="modal-buttons">
              <button
                onClick={handleCreateFolder}
                className="btn create-folder-btn"
                disabled={isLimitReached}
              >
                Create
              </button>
              <button onClick={closeCreateFolderModal} className="btn close-modal-btn">
                Cancel
              </button>
            </div>
          </div>
        </Modal>

        {/* Rename Conversation Modal */}
        <Modal
          isOpen={isRenameModalOpen}
          onRequestClose={closeRenameConversationModal}
          contentLabel="Rename Conversation"
          className="image-modal"
          overlayClassName="image-modal-overlay"
          ariaHideApp={false}
        >
          <div className="modal-content">
            <h2>Rename Conversation</h2>
            <input
              type="text"
              placeholder="Enter new conversation name"
              value={newConversationName}
              onChange={(e) => setNewConversationName(e.target.value)}
              className="folder-input"
              disabled={isLimitReached}
            />
            <div className="modal-buttons">
              <button
                onClick={handleRenameConversation}
                className="btn rename-conversation-btn"
                disabled={isLimitReached}
              >
                Rename
              </button>
              <button onClick={closeRenameConversationModal} className="btn close-modal-btn">
                Cancel
              </button>
            </div>
          </div>
        </Modal>

        {/* Add/Update API Key Modal */}
        <Modal
          isOpen={isKeyModalOpen}
          onRequestClose={closeKeyModal}
          contentLabel="Add API Key"
          className="key-modal"
          overlayClassName="key-modal-overlay"
          ariaHideApp={false}
        >
          <div className="modal-content">
            <h2>
              {apiKeyStatus[serviceKeyMap[selectedService]]
                ? `Update ${selectedService} API Key`
                : `Add ${selectedService} API Key`}
            </h2>

            {apiKeyError && (
              <div className="error-message" style={{ color: 'red', marginBottom: '10px' }}>
                {apiKeyError}
              </div>
            )}

            <input
              type="text"
              placeholder={`Enter your ${selectedService} API key`}
              value={keyInput}
              onChange={(e) => setKeyInput(e.target.value)}
              className="key-input"
            />
            <div className="modal-buttons">
              <button onClick={handleSaveKey} className="btn save-key-btn">
                Save
              </button>
              <button onClick={closeKeyModal} className="btn close-modal-btn">
                Cancel
              </button>
            </div>
          </div>
        </Modal>

        {/* Hidden File Input for Uploading Files to Folders */}
        <input
          type="file"
          multiple
          ref={uploadFileInputRef}
          style={{ display: 'none' }}
          onChange={handlePerFolderFileUpload}
          disabled={isLimitReached}
        />

        {error && (
          <div className="error-message">
            <p>{error}</p>
            {error === 'Request limit reached. Upgrade your account.' && (
              <button onClick={handleUpgrade} className="btn upgrade-btn">
                Upgrade Account
              </button>
            )}
          </div>
        )}
      </div>

      {/* Modals */}
      {activeModal === 'profile' && (
        <Modal
          isOpen={true}
          onRequestClose={() => setActiveModal(null)}
          contentLabel="My Profile"
          className="custom-modal"
          overlayClassName="custom-modal-overlay"
          ariaHideApp={false}
        >
          <SubscriptionManagementPage onClose={() => setActiveModal(null)} />
        </Modal>
      )}

      {activeModal === 'help' && (
        <HelpModal
          show={helpModalShow}
          handleClose={() => {
            handleCloseHelp();
            setActiveModal(null);
          }}
        />
      )}

      {activeModal === 'share' && (
             <ShareModal
      isOpen={isShareModalOpen}
      onRequestClose={() => {setIsShareModalOpen(false);setActiveModal(null);}}
      shareUrl={shareUrl}
      title={title}
      description={description}
    />
      )}


    </div>
  );
};

// Utility functions for reading and writing files using IndexedDB
const readFile = async (filename, conversationId = null, folderName = null) => {
  const path = (() => {
    if (conversationId) {
      return conversationFilePath(conversationId, filename);
    } else if (folderName) {
      return folderFilePath(folderName, filename);
    } else if (filename === 'favorites.json') {
      return favoritesFilePath();
    } else {
      return filename;
    }
  })();

  try {
    const decryptedContent = await readEncryptedFile(path);
    return decryptedContent;
  } catch (err) {
    console.warn(`${filename} not found in IDB. Returning empty content.`);
    return '';
  }
};

const writeFile = async (filename, content, conversationId = null, folderName = null) => {
  const path = (() => {
    if (conversationId) {
      const sanitizedFileName = sanitizeFileName(filename);
      return conversationFilePath(conversationId, sanitizedFileName);
    } else if (folderName) {
      const sanitizedFileName = sanitizeFileName(filename);
      return folderFilePath(folderName, sanitizedFileName);
    } else if (filename === 'favorites.json') {
      return favoritesFilePath();
    } else {
      return filename;
    }
  })();

  await writeEncryptedFile(path, content);
};

export default ChatPage;
