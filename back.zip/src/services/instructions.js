// تعريف المتغيرات وتصديرها باستخدام CommonJS
const myNumber = 42;
const myString = "مرحبا بالعالم";


const VisNetwork = `

Generaly for diagrams use Vis Network js, example:

<!DOCTYPE html>
<html lang=&quot;en&quot;>
<head>
  <meta charset=&quot;UTF-8&quot; />
  <meta name=&quot;viewport&quot; content=&quot;width=device-width, initial-scale=1.0&quot; />
  <title>Home Management Diagram</title>
  <!-- Load vis-network, dom-to-image, and jsPDF -->
  <script src=&quot;https://unpkg.com/vis-network/standalone/umd/vis-network.min.js&quot;></script>
  <script src=&quot;https://cdnjs.cloudflare.com/ajax/libs/dom-to-image/2.6.0/dom-to-image.min.js&quot;></script>
  <script src=&quot;https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js&quot;></script>
  <style>
    body {
      font-family: 'Arial', sans-serif;
      margin: 0;
      padding: 20px;
      background-color: #f8f8f8;
      color: #333;
      display: flex;
      flex-direction: column;
      align-items: center;
      height: 100vh;
      overflow: auto;
    }
    h1 {
      color: #3a3a3a;
      text-align: center;
      margin-bottom: 20px;
    }
    #controls {
      margin-bottom: 25px;
      display: flex;
      gap: 10px;
    }
    #controls button {
      padding: 12px 24px;
      font-size: 16px;
      border: none;
      border-radius: 8px;
      background-color: #007bff;
      color: white;
      cursor: pointer;
      transition: background-color 0.3s ease;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    #controls button:hover {
      background-color: #0056b3;
      box-shadow: 0 3px 6px rgba(0,0,0,0.15);
    }
    #controls button:active {
      background-color: #004080;
      box-shadow: 0 1px 2px rgba(0,0,0,0.2);
    }
    #diagram-container {
      width: 95%;
      height: 80vh;
      background-color: #ffffff;
      border: 1px solid #e0e0e0;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.05);
    }
    /* Custom scrollbar */
    ::-webkit-scrollbar {
      width: 12px;
      height: 12px;
    }
    ::-webkit-scrollbar-track {
      background: #f1f1f1;
      border-radius: 8px;
    }
    ::-webkit-scrollbar-thumb {
      background: #c0c0c0;
      border-radius: 8px;
    }
    ::-webkit-scrollbar-thumb:hover {
      background: #888;
    }
  </style>
</head>
<body>
  <h1>Home Management Diagram</h1>
  <div id=&quot;controls&quot;>
    <button id=&quot;download-svg&quot;>Download SVG</button>
    <button id=&quot;download-png&quot;>Download PNG</button>
    <button id=&quot;download-pdf&quot;>Download PDF</button>
  </div>
  <div id=&quot;diagram-container&quot;></div>

  <script>
    // Draw the diagram using vis-network
    function drawDiagram() {
      const nodes = [
        { id: 1, label: 'Home Management', shape: 'box', color: '#f0f0f0', font: { size: 18 } },
        { id: 2, label: 'Finances', group: 'finances' },
        { id: 3, label: 'Maintenance', group: 'maintenance' },
        { id: 4, label: 'Cleaning', group: 'cleaning' },
        { id: 5, label: 'Security', group: 'security' },
        { id: 6, label: 'Organization', group: 'organization' },
        { id: 7, label: 'Budgeting', group: 'finances', shape: 'ellipse' },
        { id: 8, label: 'Bills Payment', group: 'finances', shape: 'ellipse' },
        { id: 9, label: 'Repairs', group: 'maintenance', shape: 'ellipse' },
        { id: 10, label: 'Gardening', group: 'maintenance', shape: 'ellipse' },
        { id: 11, label: 'Regular Cleaning', group: 'cleaning', shape: 'ellipse' },
        { id: 12, label: 'Deep Cleaning', group: 'cleaning', shape: 'ellipse' },
        { id: 13, label: 'Alarm System', group: 'security', shape: 'ellipse' },
        { id: 14, label: 'Locks &amp; Keys', group: 'security', shape: 'ellipse' },
        { id: 15, label: 'Space Management', group: 'organization', shape: 'ellipse' },
        { id: 16, label: 'Inventory', group: 'organization', shape: 'ellipse' }
      ];

      const edges = [
        { from: 1, to: 2, arrows: 'to' },
        { from: 1, to: 3, arrows: 'to' },
        { from: 1, to: 4, arrows: 'to' },
        { from: 1, to: 5, arrows: 'to' },
        { from: 1, to: 6, arrows: 'to' },
        { from: 2, to: 7, arrows: 'to' },
        { from: 2, to: 8, arrows: 'to' },
        { from: 3, to: 9, arrows: 'to' },
        { from: 3, to: 10, arrows: 'to' },
        { from: 4, to: 11, arrows: 'to' },
        { from: 4, to: 12, arrows: 'to' },
        { from: 5, to: 13, arrows: 'to' },
        { from: 5, to: 14, arrows: 'to' },
        { from: 6, to: 15, arrows: 'to' },
        { from: 6, to: 16, arrows: 'to' }
      ];

      const groups = {
        finances: { color: { background: '#FFDAB9', border: '#FFA07A' } },
        maintenance: { color: { background: '#ADD8E6', border: '#87CEFA' } },
        cleaning: { color: { background: '#90EE90', border: '#32CD32' } },
        security: { color: { background: '#FFB6C1', border: '#FF69B4' } },
        organization: { color: { background: '#EEE8AA', border: '#BDB76B' } }
      };

      const container = document.getElementById('diagram-container');
      const diagramData = {
        nodes: new vis.DataSet(nodes),
        edges: new vis.DataSet(edges)
      };

      const options = {
        layout: {
          hierarchical: {
            direction: 'UD',
            sortMethod: 'directed',
            levelSeparation: 150,
            nodeSpacing: 100
          }
        },
        edges: {
          smooth: { type: 'cubicBezier', roundness: 0.4 }
        },
        nodes: {
          shape: 'box',
          widthConstraint: { maximum: 150 },
          margin: 10,
          font: { face: 'Arial', size: 14, color: '#333' },
          color: {
            background: '#e0e0e0',
            border: '#888',
            highlight: { background: '#d2e5ff', border: '#2b7ce9' }
          }
        },
        groups: groups,
        interaction: { dragNodes: true, dragView: true, zoomView: true }
      };

      new vis.Network(container, diagramData, options);
    }

    document.addEventListener('DOMContentLoaded', drawDiagram);

    // Download as SVG
    document.getElementById('download-svg').addEventListener('click', function() {
      const node = document.getElementById('diagram-container');
      domtoimage.toSvg(node)
        .then(function(dataUrl) {
          const link = document.createElement('a');
          link.download = 'diagram.svg';
          link.href = dataUrl;
          link.click();
        })
        .catch(function(error) {
          console.error('Error exporting SVG:', error);
        });
    });

    // Download as PNG
    document.getElementById('download-png').addEventListener('click', function() {
      const node = document.getElementById('diagram-container');
      domtoimage.toPng(node)
        .then(function(dataUrl) {
          const link = document.createElement('a');
          link.download = 'diagram.png';
          link.href = dataUrl;
          link.click();
        })
        .catch(function(error) {
          console.error('Error exporting PNG:', error);
        });
    });

    // Download as PDF
    document.getElementById('download-pdf').addEventListener('click', function() {
      const node = document.getElementById('diagram-container');
      domtoimage.toPng(node)
        .then(function(dataUrl) {
          const img = new Image();
          img.src = dataUrl;
          img.onload = function() {
            const { jsPDF } = window.jspdf;
            const pdf = new jsPDF({
              orientation: 'landscape',
              unit: 'pt',
              format: [img.width, img.height]
            });
            pdf.addImage(img, 'PNG', 0, 0, img.width, img.height);
            pdf.save('diagram.pdf');
          };
        })
        .catch(function(error) {
          console.error('Error exporting PDF:', error);
        });
    });
  </script>

    <style>
    body{
      overflow: auto;
    }
      /* width */
::-webkit-scrollbar {
  width: 10px;
   height: 10px;
}

/* Track */
::-webkit-scrollbar-track {
  background: #f1f1f1;
}

/* Handle */
::-webkit-scrollbar-thumb {
  background: #d2d2c7;
  border-radius: 10px;

}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #6d6d6d;
}
    </style>

    <script>
    window.onerror = function(message, source, lineno, colno, error) {
      parent.postMessage({
        type: 'iframeError',
        payload: { message, source, lineno, colno, error: error.toString() }
      }, '*');
    };
      document.addEventListener('click', () => {
        parent.postMessage({ type: 'iframe-click' }, '*');
      });
    </script>
    </body>
</html>

`;

const classesDiagram = `

classes DiagramExample :
<!DOCTYPE html>
<html lang=&quot;en&quot;>
<head>
    <meta charset=&quot;UTF-8&quot;>
    <meta name=&quot;viewport&quot; content=&quot;width=device-width, initial-scale=1.0&quot;>
    <title>Facebook Class Diagram</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f2f5;
            color: #050505;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        #diagram-container {
            width: 95%;
            max-width: 1200px;
            margin: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            overflow-x: auto; /* Enable horizontal scrolling for wide diagrams */
        }

        .mermaid {
            background-color: #fff; /* Ensure mermaid background is white for better contrast */
        }

        h1 {
            color: #1877f2;
            text-align: center;
            margin-top: 20px;
        }

        p {
            text-align: center;
            color: #65676b;
            margin-bottom: 20px;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            #diagram-container {
                width: 98%;
                margin: 10px;
                padding: 10px;
            }
            h1 {
                font-size: 1.5em;
            }
            p {
                font-size: 0.9em;
            }
        }
    </style>
</head>
<body>
    <h1>Facebook Class Diagram</h1>
    <p>Simplified Class Diagram of Facebook's Core Components</p>
    <div id=&quot;diagram-container&quot;>
        <div class=&quot;mermaid&quot;>
            classDiagram
                class User {
                    - userId: int
                    - name: string
                    - email: string
                    - profilePicture: string
                    + post(content: string): Post
                    + addFriend(user: User): void
                    + sendMessage(user: User, message: string): Message
                }
                class Post {
                    - postId: int
                    - author: User
                    - content: string
                    - timestamp: datetime
                    - likes: int
                    - comments: Comment[]
                    + like(): void
                    + addComment(comment: Comment): void
                }
                class Comment {
                    - commentId: int
                    - author: User
                    - content: string
                    - timestamp: datetime
                    + like(): void
                }
                class Page {
                    - pageId: int
                    - name: string
                    - category: string
                    - followers: User[]
                    + post(content: string): Post
                    + like(user: User): void
                }
                class Group {
                    - groupId: int
                    - name: string
                    - members: User[]
                    - privacy: string
                    + post(content: string): Post
                    + joinGroup(user: User): void
                }
                class Message {
                    - messageId: int
                    - sender: User
                    - receiver: User
                    - content: string
                    - timestamp: datetime
                    - isRead: boolean
                }
                class NewsFeed {
                    - newsFeedId: int
                    - user: User
                    - posts: Post[]
                    + generateFeed(): Post[]
                }

                User --|> Post : authors
                User --|> Comment : authors
                User &quot;1&quot; -- &quot;0..*&quot; User : friends
                User &quot;1&quot; -- &quot;0..*&quot; Message : sentMessages
                User &quot;1&quot; -- &quot;0..*&quot; Message : receivedMessages
                Post &quot;1&quot; -- &quot;0..*&quot; Comment : comments
                Page &quot;1&quot; -- &quot;0..*&quot; Post : posts
                Page &quot;1&quot; -- &quot;0..*&quot; User : followers
                Group &quot;1&quot; -- &quot;0..*&quot; Post : posts
                Group &quot;1&quot; -- &quot;0..*&quot; User : members
                NewsFeed &quot;1&quot; -- &quot;0..*&quot; Post : posts
                NewsFeed &quot;1&quot; --|> User : belongs to

                style User fill:#f9f,stroke:#333,stroke-width:2px
                style Post fill:#ccf,stroke:#333,stroke-width:2px
                style Comment fill:#eee,stroke:#333,stroke-width:2px
                style Page fill:#cfc,stroke:#333,stroke-width:2px
                style Group fill:#fce,stroke:#333,stroke-width:2px
                style Message fill:#cff,stroke:#333,stroke-width:2px
                style NewsFeed fill:#eff,stroke:#333,stroke-width:2px
        </div>
    </div>

    <script type=&quot;module&quot;>
        import mermaid from 'https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.esm.min.mjs';
        mermaid.initialize({ startOnLoad: true });
    </script>

    <style>
    body{
      overflow: auto;
    }
      /* width */
::-webkit-scrollbar {
  width: 10px;
   height: 10px;
}

/* Track */
::-webkit-scrollbar-track {
  background: #f1f1f1;
}

/* Handle */
::-webkit-scrollbar-thumb {
  background: #d2d2c7;
  border-radius: 10px;

}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #6d6d6d;
}
    </style>

    <script>
    window.onerror = function(message, source, lineno, colno, error) {
      parent.postMessage({
        type: 'iframeError',
        payload: { message, source, lineno, colno, error: error.toString() }
      }, '*');
    };
      document.addEventListener('click', () => {
        parent.postMessage({ type: 'iframe-click' }, '*');
      });
    </script>
    </body>
</html>

`;

const math = `

for math simulation use plotly js library

`;

const mindmap = `

MindMap Example (rounded):

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Radial Ecommerce Mind Map</title>
    <style>
      /* Style for the network container */
      #mynetwork {
        width: 100%;
        height: 100vh;
        border: 1px solid lightgray;
      }
    </style>
    <!-- Include vis-network CSS from CDN -->
    <link href="https://unpkg.com/vis-network/styles/vis-network.min.css" rel="stylesheet" type="text/css" />
  </head>
  <body>
    <!-- Network container -->
    <div id="mynetwork"></div>
    
    <!-- Include vis-network JS from CDN -->
    <script type="text/javascript" src="https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"></script>
    <script type="text/javascript">
      // Initialize an array to hold all nodes.
      const nodes = [];
      
      // Central node (Ecommerce) fixed at the center.
      nodes.push({
        id: 1,
        label: 'Ecommerce',
        x: 0,
        y: 0,
        fixed: true,
        color: '#FF9800',
        shape: 'box'
      });
      
      // Define level-1 nodes (main categories)
      const level1Data = [
        { id: 2, label: "Products" },
        { id: 3, label: "Customers" },
        { id: 4, label: "Payments" },
        { id: 5, label: "Shipping" },
        { id: 6, label: "Marketing" },
        { id: 7, label: "Analytics" },
        { id: 8, label: "Inventory" },
        { id: 9, label: "Support" }
      ];
      
      // Radius for level-1 nodes from center.
      const R1 = 300;
      const numLevel1 = level1Data.length;
      
      // Compute positions for level-1 nodes evenly on a circle.
      level1Data.forEach((node, index) => {
        const angle = (2 * Math.PI * index) / numLevel1;
        node.x = R1 * Math.cos(angle);
        node.y = R1 * Math.sin(angle);
        node.fixed = false;  // allow dragging
        node.color = '#4CAF50';
        // Store parent's angle (optional, if you want to align children)
        node.parentAngle = angle;
        nodes.push(node);
      });
      
      // Mapping of level-1 node IDs to their children (level-2 nodes)
      const childrenMapping = {
        2: ["Catalog", "Reviews", "Pricing", "Inventory Mgmt"],
        3: ["User Accounts", "Loyalty Program", "Feedback"],
        4: ["Credit Cards", "PayPal", "Crypto"],
        5: ["Domestic", "International", "Tracking"],
        6: ["SEO", "Social Media", "Email Marketing"],
        7: ["Sales Data", "Traffic", "Conversion Rate"],
        8: ["Stock Mgmt", "Suppliers"],
        9: ["Live Chat", "FAQ", "Returns"]
      };
      
      // Next available id for level-2 nodes.
      let nextId = 10;
      // Radius for children around their parent.
      const R2 = 150;
      
      // For each level-1 node, compute positions for its children.
      Object.keys(childrenMapping).forEach(parentId => {
        // Find the parent node data from level1Data.
        const parent = level1Data.find(n => n.id == parentId);
        const children = childrenMapping[parentId];
        const numChildren = children.length;
        
        children.forEach((label, j) => {
          // Distribute children evenly in a circle around the parent.
          const angle = (2 * Math.PI * j) / numChildren;
          const childX = parent.x + R2 * Math.cos(angle);
          const childY = parent.y + R2 * Math.sin(angle);
          
          nodes.push({
            id: nextId,
            label: label,
            x: childX,
            y: childY,
            fixed: false,
            color: '#2196F3'
          });
          nextId++;
        });
      });
      
      // Create edges connecting nodes.
      const edges = [];
      // Connect the central node to all level-1 nodes.
      level1Data.forEach(node => {
        edges.push({ from: 1, to: node.id, arrows: 'to' });
      });
      // Connect each level-1 node to its children.
      let childIdStart = 10;
      Object.keys(childrenMapping).forEach(parentId => {
        const children = childrenMapping[parentId];
        children.forEach(() => {
          edges.push({ from: Number(parentId), to: childIdStart, arrows: 'to' });
          childIdStart++;
        });
      });
      
      // Create vis DataSets.
      const nodesDataset = new vis.DataSet(nodes);
      const edgesDataset = new vis.DataSet(edges);
      
      // Network container.
      const container = document.getElementById('mynetwork');
      const data = { nodes: nodesDataset, edges: edgesDataset };
      
      // Options: physics disabled (since positions are set manually) and enable interactions.
      const options = {
        physics: false,
        interaction: {
          dragNodes: true,
          zoomView: true,
          dragView: true
        }
      };
      
      // Create the network.
      new vis.Network(container, data, options);
    </script>
  </body>
</html>

`;
const pdf = `

    **PDF Handling (if needed)**  
     you must know how to use pdf code and write 100/100 correct code.
   - **Include** these scripts in the <head> or before your main <script> code:
     
     <!-- 1) PDF.js (for rendering previews) -->
     <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.13.216/pdf.min.js"></script>
     <script>
       pdfjsLib.GlobalWorkerOptions.workerSrc =
         'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.13.216/pdf.worker.min.js';
     </script>

     <!-- 2) pdf-lib (for creating or editing PDFs in memory) -->
     <script src="https://unpkg.com/pdf-lib/dist/pdf-lib.min.js"></script>
     
   - **Important**: Reference the PDF-lib object correctly:
     
     const { PDFDocument } = PDFLib;
   
     (Do **not** use pdfLib or any other name unless you explicitly redefine it.)

     The generated application will run within an iframe (srcDoc) so make attention to errors like this: 
     --TypeError: copyPage is not a function 
     --TypeError: srcDoc must be of type PDFDocument, but was actually of type NaN
     --TypeError: pdf must be of type string or Uint8Array or ArrayBuffer, but was actually of type undefined

Using PDF example:
<!DOCTYPE html>
<html lang=&quot;en&quot;>
<head>
    <meta charset=&quot;UTF-8&quot;>
    <meta name=&quot;viewport&quot; content=&quot;width=device-width, initial-scale=1.0&quot;>
    <title>PDF Page Reorder</title>
    <!-- PDF.js (for rendering previews) -->
    <script src=&quot;https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.13.216/pdf.min.js&quot;></script>
    <script>
        pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.13.216/pdf.worker.min.js';
    </script>
    <!-- pdf-lib (for creating or editing PDFs in memory) -->
    <script src=&quot;https://unpkg.com/pdf-lib/dist/pdf-lib.min.js&quot;></script>
    <style>
        body {
            font-family: sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            background-color: #f4f7f9;
        }

        #app-container {
            width: 95%;
            max-width: 1200px;
            padding: 20px;
            background-color: #fff;
}
    </style>
</head>
<body>
    <div id=&quot;app-container&quot;>
        <h1>PDF Page Reorder</h1>
        <div id=&quot;pdfUploadContainer&quot;>
            <input type=&quot;file&quot; id=&quot;pdfUpload&quot; accept=&quot;.pdf&quot;>
        </div>
        <div id=&quot;pageThumbnails&quot;>
            <!-- Page thumbnails will be added here -->
        </div>
        <button id=&quot;downloadButton&quot; class=&quot;hidden&quot;>Download Reordered PDF</button>
        <canvas id=&quot;pdfCanvas&quot; class=&quot;hidden&quot;></canvas>
        <div id=&quot;message-area&quot;></div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            let pdfDoc = null;
            let pageThumbnailsDiv = document.getElementById('pageThumbnails');
            let downloadButton = document.getElementById('downloadButton');
            let pdfCanvas = document.getElementById('pdfCanvas');
            let pdfUpload = document.getElementById('pdfUpload');
            let messageArea = document.getElementById('message-area');
            let currentPageOrder = [];

            pdfUpload.addEventListener('change', async (e) => {
                const file = e.target.files[0];
                if (!file) {
                    messageArea.textContent = 'No file selected.';
                    return;
                }

                if (file.type !== 'application/pdf') {
                    messageArea.textContent = 'Please select a PDF file.';
                    return;
                }

                messageArea.textContent = 'Loading PDF...';
                pageThumbnailsDiv.innerHTML = ''; // Clear previous thumbnails
                downloadButton.classList.add('hidden');

                try {
                    const fileData = await file.arrayBuffer();
                    pdfDoc = await pdfjsLib.getDocument(fileData).promise;
                    renderPageThumbnails(pdfDoc);
                } catch (error) {
                    console.error('Error loading PDF:', error);
                    messageArea.textContent = 'Error loading PDF. Please try again.';
                }
            });

            async function renderPageThumbnails(pdfDocument) {
                pageThumbnailsDiv.innerHTML = '';
                currentPageOrder = [];
                for (let pageNum = 1; pageNum <= pdfDocument.numPages; pageNum++) {
                    const page = await pdfDocument.getPage(pageNum);
                    const viewport = page.getViewport({ scale: 0.3 }); // Adjust scale for thumbnail size
                    pdfCanvas.height = viewport.height;
                    pdfCanvas.width = viewport.width;
                    const canvasContext = pdfCanvas.getContext('2d');

                    const renderContext = {
                        canvasContext,
                        viewport,
                    };
                    await page.render(renderContext).promise;
                    const thumbnailDataURL = pdfCanvas.toDataURL('image/jpeg');

                    const thumbnailDiv = document.createElement('div');
                    thumbnailDiv.classList.add('page-thumbnail');
                    thumbnailDiv.setAttribute('draggable', true);
                    thumbnailDiv.dataset.pageNumber = pageNum;

                    const img = document.createElement('img');
                    img.src = thumbnailDataURL;

                    const pageNumberSpan = document.createElement('span');
                    pageNumberSpan.classList.add('page-number');
                    pageNumberSpan.textContent = pageNum;

                    thumbnailDiv.appendChild(img);
                    thumbnailDiv.appendChild(pageNumberSpan);
                    pageThumbnailsDiv.appendChild(thumbnailDiv);
                    currentPageOrder.push(pageNum); //initial order

                }
                setupDragAndDrop();
            }


            function setupDragAndDrop() {
                let draggedItem = null;

                pageThumbnailsDiv.addEventListener('dragstart', (event) => {
                    draggedItem = event.target.closest('.page-thumbnail');
                    if (draggedItem) {
                        event.dataTransfer.setData('text/plain', ''); // Required for Firefox
                    }
                });

                pageThumbnailsDiv.addEventListener('dragover', (event) => {
                    event.preventDefault();
                });

                pageThumbnailsDiv.addEventListener('drop', (event) => {
                    event.preventDefault();
                    if (!draggedItem) return;

                    const dropTarget = event.target.closest('.page-thumbnail');
                    if (dropTarget &amp;&amp; dropTarget !== draggedItem) {
                        const thumbnails = Array.from(pageThumbnailsDiv.children);
                        const draggedIndex = thumbnails.indexOf(draggedItem);
                        const dropIndex = thumbnails.indexOf(dropTarget);

                        if (draggedIndex < dropIndex) {
                            pageThumbnailsDiv.insertBefore(draggedItem, dropTarget.nextSibling);
                        } else {
                            pageThumbnailsDiv.insertBefore(draggedItem, dropTarget);
                        }
                        updatePageOrder();
                        draggedItem = null;
                    }
                });

                pageThumbnailsDiv.addEventListener('dragend', () => {
                    draggedItem = null;
                });
            }

            function updatePageOrder() {
                currentPageOrder = Array.from(pageThumbnailsDiv.children).map(thumbnail => parseInt(thumbnail.dataset.pageNumber));
            }


            downloadButton.addEventListener('click', async () => {
                if (!pdfDoc) {
                    messageArea.textContent = 'No PDF loaded to reorder.';
                    return;
                }
                messageArea.textContent = 'Reordering pages and preparing for download...';

                try {
                    const { PDFDocument } = PDFLib;
                    const newPdfDoc = await PDFDocument.create();
                    const originalPdfBytes = await pdfDoc.getData();
                    const loadedPdfDoc = await PDFDocument.load(originalPdfBytes);

                    const pages = await newPdfDoc.copyPages(loadedPdfDoc, currentPageOrder.map(pageNumber => pageNumber -1 )); //pdf-lib is 0-indexed

                    for (const page of pages) {
                        newPdfDoc.addPage(page);
                    }


                    const pdfBytes = await newPdfDoc.save();

                    const blob = new Blob([pdfBytes], { type: 'application/pdf' });
                    const url = URL.createObjectURL(blob);

                    const a = document.createElement('a');
                    a.href = url;
                    a.download = 'reordered_pdf.pdf';
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);
                    messageArea.textContent = 'PDF reordered and downloaded successfully.';
                } catch (error) {
                    console.error('Error reordering PDF:', error);
                    messageArea.textContent = 'Error reordering PDF. Please try again.';
                }
            });

            pdfUpload.addEventListener('change', () => {
                downloadButton.classList.remove('hidden');
            });


            // Example of reading data.json (not strictly needed for this app, but as requested in instructions)
            window.parent.postMessage({ type: 'READ_FILE', payload: { filename: 'data.json' } }, '*');

            window.addEventListener('message', (event) => {
                if (event.data.type === 'FILE_CONTENT' &amp;&amp; event.data.payload.filename === 'data.json') {
                    // Handle initial data if needed, for this app, we don't need to load data.json
                    // const data = JSON.parse(event.data.payload.content || '{}');
                    // console.log('Data from data.json:', data);
                }
            });


        });
    </script>

    <style>
    body{
      overflow: auto;
    }
      /* width */
::-webkit-scrollbar {
  width: 10px;
   height: 10px;
}

    </style>

    <script>
    window.onerror = function(message, source, lineno, colno, error) {
      parent.postMessage({
        type: 'iframeError',
        payload: { message, source, lineno, colno, error: error.toString() }
      }, '*');
    };
      document.addEventListener('click', () => {
        parent.postMessage({ type: 'iframe-click' }, '*');
      });
    </script>
    </body>
</html>     

`;
const physicsimulation = `

for physics simulation use matter-js library


`;

const tlata_3D = `

for 3d simulation use Three.js library


`;
const sequenceDiagram = `

sequence Diagram Example :
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Facebook Post Status Sequence Diagram</title>
  <!-- Import Mermaid 11 as an ES module from a CDN -->
  <script type="module">
    import mermaid from "https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs";
    mermaid.initialize({ startOnLoad: true });
  </script>
  <!-- Import jsPDF for PDF export -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <style>
    /* Center content and style export buttons */
    body {
      display: flex;
      flex-direction: column;
      align-items: center;
      margin: 20px;
    }
    #export-buttons {
      margin-bottom: 20px;
    }
    button {
      margin: 0 5px;
      padding: 8px 12px;
      font-size: 14px;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <!-- Export buttons -->
  <div id="export-buttons">
    <button id="export-png">Export as PNG</button>
    <button id="export-pdf">Export as PDF</button>
    <button id="export-svg">Export as SVG</button>
  </div>

  <!-- Mermaid diagram: Facebook Post Status Sequence Diagram -->
  <div class="mermaid">
    sequenceDiagram
      participant User as User
      participant Browser as Browser
      participant API as Facebook API
      participant DB as Database
      participant Notif as Notification Service

      User->>Browser: Write new status
      Browser->>API: Send status post request
      API->>DB: Save status to database
      DB-->>API: Confirm save
      API-->>Browser: Return post success response
      Browser-->>User: Display new status
      API->>Notif: Notify friends about new post
  </div>

  <script>
    // Updated function to convert SVG to canvas using SVG dimensions.
    function svgToCanvas(svgElement, scale = 1) {
      return new Promise((resolve, reject) => {
        const svgData = new XMLSerializer().serializeToString(svgElement);
        const canvas = document.createElement("canvas");
        let width, height;

        // Use width/height attributes if available, or fall back to viewBox or getBBox.
        if (svgElement.getAttribute("width") && svgElement.getAttribute("height")) {
          width = parseFloat(svgElement.getAttribute("width"));
          height = parseFloat(svgElement.getAttribute("height"));
        } else if (svgElement.hasAttribute("viewBox")) {
          const viewBox = svgElement.getAttribute("viewBox").split(" ");
          width = parseFloat(viewBox[2]);
          height = parseFloat(viewBox[3]);
        } else {
          const bbox = svgElement.getBBox();
          width = bbox.width;
          height = bbox.height;
        }

        // Set canvas dimensions using the scale factor for high quality output.
        canvas.width = width * scale;
        canvas.height = height * scale;

        const ctx = canvas.getContext("2d");
        ctx.scale(scale, scale);
        const img = new Image();
        const svgBlob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });
        const url = URL.createObjectURL(svgBlob);
        img.onload = () => {
          ctx.drawImage(img, 0, 0, width, height);
          URL.revokeObjectURL(url);
          resolve(canvas);
        };
        img.onerror = (err) => reject(err);
        img.src = url;
      });
    }

    // Export as PNG with a higher resolution (scale factor of 3).
    document.getElementById("export-png").addEventListener("click", async () => {
      const svg = document.querySelector(".mermaid svg");
      if (!svg) {
        alert("SVG not found. Please wait for the diagram to render.");
        return;
      }
      try {
        const scale = 3;
        const canvas = await svgToCanvas(svg, scale);
        const imgURL = canvas.toDataURL("image/png");
        const dlLink = document.createElement("a");
        dlLink.download = "facebook_post_status.png";
        dlLink.href = imgURL;
        dlLink.click();
      } catch (err) {
        console.error("Error exporting PNG:", err);
      }
    });

    // Export as PDF using jsPDF with high-resolution image.
    document.getElementById("export-pdf").addEventListener("click", async () => {
      const svg = document.querySelector(".mermaid svg");
      if (!svg) {
        alert("SVG not found. Please wait for the diagram to render.");
        return;
      }
      try {
        const scale = 3;
        const canvas = await svgToCanvas(svg, scale);
        const imgData = canvas.toDataURL("image/png");
        const { jsPDF } = window.jspdf;
        const pdf = new jsPDF({
          orientation: canvas.width > canvas.height ? "landscape" : "portrait",
          unit: "pt",
          format: [canvas.width, canvas.height]
        });
        pdf.addImage(imgData, "PNG", 0, 0, canvas.width, canvas.height);
        pdf.save("facebook_post_status.pdf");
      } catch (err) {
        console.error("Error exporting PDF:", err);
      }
    });

    // Export the original SVG for vector quality.
    document.getElementById("export-svg").addEventListener("click", () => {
      const svg = document.querySelector(".mermaid svg");
      if (!svg) {
        alert("SVG not found. Please wait for the diagram to render.");
        return;
      }
      const svgData = new XMLSerializer().serializeToString(svg);
      const blob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const dlLink = document.createElement("a");
      dlLink.href = url;
      dlLink.download = "facebook_post_status.svg";
      dlLink.click();
      URL.revokeObjectURL(url);
    });
  </script>
</body>
</html>

`;






const exportExcel=`
export excele example :

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Export HTML Table to Excel</title>
  <style>
    /* Basic table styling */
    table {
      border-collapse: collapse;
      width: 100%;
      margin-bottom: 20px;
    }
    table, th, td {
      border: 1px solid #333;
    }
    th, td {
      padding: 8px;
      text-align: left;
    }
    /* Button styling */
    .export-btn {
      padding: 10px 20px;
      background-color: #28a745;
      color: #fff;
      border: none;
      cursor: pointer;
      font-size: 16px;
    }
    .export-btn:hover {
      background-color: #218838;
    }
  </style>
</head>
<body>
  <h2>Sample Data Table</h2>
  <table id="dataTable">
    <thead>
      <tr>
        <th>Name</th>
        <th>Age</th>
        <th>City</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Alice</td>
        <td>25</td>
        <td>New York</td>
      </tr>
      <tr>
        <td>Bob</td>
        <td>30</td>
        <td>Los Angeles</td>
      </tr>
      <tr>
        <td>Charlie</td>
        <td>28</td>
        <td>Chicago</td>
      </tr>
    </tbody>
  </table>
  <button class="export-btn" onclick="exportTableToExcel()">Export to Excel</button>

  <!-- Load SheetJS library -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>
  <script>
    function exportTableToExcel() {
      // Get the HTML table element
      var table = document.getElementById("dataTable");
      // Convert the HTML table to a SheetJS workbook
      var workbook = XLSX.utils.table_to_book(table, { sheet: "Sheet1" });
      // Export the workbook as an Excel file with a given filename
      XLSX.writeFile(workbook, "table.xlsx");
    }
  </script>
</body>
</html>


`





module.exports = {VisNetwork ,
    classesDiagram ,
    math ,
    mindmap ,
    pdf ,
    physicsimulation ,
    tlata_3D ,
    sequenceDiagram,
    exportExcel
};



