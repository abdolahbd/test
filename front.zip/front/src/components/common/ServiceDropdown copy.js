// src/components/common/ServiceDropdown.js

import React, { useRef, useEffect } from 'react';
import './ServiceDropdown.css'; // Ensure this path is correct
import { FaCheckCircle } from "react-icons/fa";
import { MdOutlineKeyboardDoubleArrowDown } from "react-icons/md";



const ServiceDropdown = ({
  supportedServices,
  apiKeyStatus,
  serviceKeyMap,
  selectedService,
  setSelectedService,
  onAddOrUpdate,
  isLimitReached,
  isOpen, // Controlled by parent
  setIsOpen, // Function to control from parent
}) => {
  const dropdownRef = useRef(null);

  // Close dropdown if user clicks outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [setIsOpen]);

  const handleToggleDropdown = () => {
    if (!isLimitReached) {
      setIsOpen((prev) => !prev);
    }
  };

  const handleSelectService = (service) => {
    setSelectedService(service);
    setIsOpen(false);
  };

  return (
    <div className="service-dropdown" ref={dropdownRef}>
      <div className="service-dropdown-header" style={{ backgroundColor: apiKeyStatus[serviceKeyMap[selectedService]] ? '#beffbe' : '#ff7f7f',borderColor: apiKeyStatus[serviceKeyMap[selectedService]] ? '#beffbe' : '#c10d0d' ,color: apiKeyStatus[serviceKeyMap[selectedService]] ? '#003f01' : '#3f0000' }} onClick={handleToggleDropdown}>

        <span>
          {apiKeyStatus[serviceKeyMap[selectedService]]?(selectedService ? "Api Key : "+selectedService : 'Select a service'):'Add Api Key'}
        </span>

        <span className="dropdown-arrow">{apiKeyStatus[serviceKeyMap[selectedService]] ? <FaCheckCircle /> : ''}  <MdOutlineKeyboardDoubleArrowDown /> </span>
      
      </div>

      {isOpen && (
        <div className="service-dropdown-menu">
          {supportedServices.map((service) => {
            const hasKey = apiKeyStatus[serviceKeyMap[service]];
            return (
              <div
                key={service}
                className="service-dropdown-item"
                // Clicking on the text will select the service
                onClick={() => handleSelectService(service)}
              >
                <span 
                  className="service-label"
                >
                  {service}<span className="service-status">{apiKeyStatus[serviceKeyMap[service]] ? <FaCheckCircle /> : ''} </span>

                </span>
                <button
                  className="add-update-btn"
                  // Stop the onClick from also selecting the service
                  onClick={(e) => {
                    e.stopPropagation();
                    onAddOrUpdate(service);
                  }}
                  disabled={isLimitReached}
                >
                  {hasKey ? 'Update' : 'Add'}
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default ServiceDropdown;
