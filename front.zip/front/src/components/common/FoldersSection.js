// src/components/FoldersSection/FoldersSection.js

import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import './FoldersSection.css';
import { IoIosArrowDropdown, IoIosArrowDropup } from "react-icons/io";
import { FaFileAlt, FaEye } from "react-icons/fa";
import { TbFilePlus, TbFolderOpen, TbFolderPlus, TbTrash } from 'react-icons/tb';
import CryptoJS from 'crypto-js';

// ------ IndexedDB & Decryption Helpers ------

const encryptionKey = process.env.REACT_APP_ENCRYPTION_KEY;

let dbPromise = null;
const initIndexedDB = () => {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const request = window.indexedDB.open('WIA-SIGMANOS-GM-TZ', 2);
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains('files')) {
          db.createObjectStore('files', { keyPath: 'path' });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  return dbPromise;
};

const indexedDBGet = async (key) => {
  const db = await initIndexedDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('files', 'readonly');
    const store = tx.objectStore('files');
    const req = store.get(key);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
};

const decryptData = (cipherText) => {
  if (!encryptionKey) {
    throw new Error('Encryption key is missing. Please set REACT_APP_ENCRYPTION_KEY in your .env file.');
  }
  try {
    const bytes = CryptoJS.AES.decrypt(cipherText, encryptionKey);
    const decrypted = bytes.toString(CryptoJS.enc.Utf8);
    if (!decrypted) throw new Error('Decryption failed');
    return decrypted;
  } catch (error) {
    console.error('Error during decryption:', error);
    return "";
  }
};

// ---------------------------------------------

/**
 * Tooltip Component (for text)
 */
const Tooltip = ({ visible, content, position }) => {
  if (!visible) return null;
  const style = {
    top: position.y + 10,
    left: position.x + 10,
  };
  return (
    <div className={`tool-tip ${visible ? 'visible' : ''}`} style={style}>
      {content}
    </div>
  );
};

Tooltip.propTypes = {
  visible: PropTypes.bool.isRequired,
  content: PropTypes.string.isRequired,
  position: PropTypes.shape({
    x: PropTypes.number,
    y: PropTypes.number,
  }).isRequired,
};

/**
 * PreviewTooltip Component (for image previews)
 * Uses a CSS class (.preview-tooltip) that you’ll add to mimic the tooltip style.
 */
const PreviewTooltip = ({ visible, imageSrc, position }) => {
  if (!visible || !imageSrc) return null;
  const style = {
    top: position.y - 100, // Display above the mouse pointer (150px image + 10px offset)
    left: position.x + 10,
    padding: '2px'
  };
  return (
    <div className={`preview-tooltip ${visible ? 'visible' : ''}`} style={style}>
      <img src={imageSrc} alt="Preview" />
    </div>
  );
};


PreviewTooltip.propTypes = {
  visible: PropTypes.bool.isRequired,
  imageSrc: PropTypes.string.isRequired,
  position: PropTypes.shape({
    x: PropTypes.number,
    y: PropTypes.number,
  }).isRequired,
};

const FoldersSection = ({
  folders,
  expandedFolders,
  toggleFolderExpansion,
  filesInFolders,
  handleSelectFile,
  handleDeleteFile,
  handleDeleteFolder,
  handleUploadFiles,
  openCreateFolderModal,
  isLimitReached,
}) => {
  const [isFoldersCollapsed, setIsFoldersCollapsed] = useState(false);
  const [tooltip, setTooltip] = useState({
    visible: false,
    content: '',
    position: { x: 0, y: 0 },
  });
  const [previewTooltip, setPreviewTooltip] = useState({
    visible: false,
    imageSrc: '',
    position: { x: 0, y: 0 },
  });
  const [displayedFolders, setDisplayedFolders] = useState(7);
  const [displayedFiles, setDisplayedFiles] = useState({});

  useEffect(() => {
    const initialDisplayedFiles = {};
    folders.forEach(folder => {
      initialDisplayedFiles[folder.name] = displayedFiles[folder.name] || 7;
    });
    setDisplayedFiles(initialDisplayedFiles);
  }, [folders]);

  const toggleFoldersCollapse = () => {
    setIsFoldersCollapsed(!isFoldersCollapsed);
  };

  const handleFileMouseEnter = (e, fileName) => {
    setTooltip({
      visible: true,
      content: fileName.replace(/_/g, ' '),
      position: { x: e.clientX, y: e.clientY },
    });
  };

  const handleFolderMouseEnter = (e, folderName) => {
    setTooltip({
      visible: true,
      content: folderName,
      position: { x: e.clientX, y: e.clientY },
    });
  };

  const handleMouseMove = (e) => {
    if (tooltip.visible) {
      setTooltip(prev => ({ ...prev, position: { x: e.clientX, y: e.clientY } }));
    }
    if (previewTooltip.visible) {
      setPreviewTooltip(prev => ({ ...prev, position: { x: e.clientX, y: e.clientY } }));
    }
  };

  const handleMouseLeave = () => {
    setTooltip({ visible: false, content: '', position: { x: 0, y: 0 } });
  };

  // When hovering on the preview icon, fetch and decrypt the image from IndexedDB.
  const handlePreviewMouseEnter = (e, folderName, file) => {
    const lowerCaseFile = file.toLowerCase();
    if (lowerCaseFile.endsWith('.png') || lowerCaseFile.endsWith('.jpg') || lowerCaseFile.endsWith('.jpeg')) {
      const filePath = `folders/${folderName}/${file}`;
      indexedDBGet(filePath)
        .then(record => {
          if (record && record.content) {
            const decryptedContent = decryptData(record.content);
            setPreviewTooltip({
              visible: true,
              imageSrc: decryptedContent, // Expected to be a Data URL.
              position: { x: e.clientX, y: e.clientY },
            });
          }
        })
        .catch(err => console.error('Error retrieving image from IndexedDB:', err));
    }
  };

  const handlePreviewMouseLeave = () => {
    setPreviewTooltip({ visible: false, imageSrc: '', position: { x: 0, y: 0 } });
  };

  const handleLoadMoreFolders = () => setDisplayedFolders(prev => prev + 7);

  const handleLoadMoreFiles = (folderName) => {
    setDisplayedFiles(prev => ({ ...prev, [folderName]: prev[folderName] + 7 }));
  };

  return (
    <div className="folders-section" onMouseMove={handleMouseMove}>
      <div className="folders-header" onClick={toggleFoldersCollapse}>
        <h2 className="section-collapse">
          <div className="left-section">
            <span>
              <TbFolderOpen style={{ fontSize: '20px', marginBottom: '2px', marginRight: '8px' }}/> Folders
            </span>
          </div>
          <div className="right-section">
            <button
              onClick={(e) => { e.stopPropagation(); openCreateFolderModal(); }}
              className="create-folder-btn"
              disabled={isLimitReached}
              aria-label="Create New Folder"
            >
              <TbFolderPlus style={{ fontSize: '20px', marginBottom: '2px', marginRight: '5px' }}/>
            </button>
            <span
              className="section-collapse-icon"
              onClick={(e) => { e.stopPropagation(); toggleFoldersCollapse(); }}
              aria-label={isFoldersCollapsed ? "Expand Folders" : "Collapse Folders"}
            >
              {isFoldersCollapsed ? <IoIosArrowDropdown /> : <IoIosArrowDropup />}
            </span>
          </div>
        </h2>
      </div>

      <div className={`folders-container ${isFoldersCollapsed ? '' : 'open'}`}>
        {folders.length > 0 ? (
          <>
            <ul className="folder-list">
              {folders.slice(0, displayedFolders).map((folder, index) => {
                const isOpen = expandedFolders[folder.name] || false;
                const files = filesInFolders[folder.name] || [];
                const currentDisplayedFiles = displayedFiles[folder.name] || 7;
                const hasMoreFiles = currentDisplayedFiles < files.length;
                return (
                  <li key={index} className="folder-item">
                    <div className="folder-header" onClick={() => toggleFolderExpansion(folder.name)}>
                      <div className="folder-info">
                        <IoIosArrowDropdown className={`toggle-icon ${isOpen ? 'expanded' : 'collapsed'}`} />
                        <span
                          className="folder-name"
                          onMouseEnter={(e) => handleFolderMouseEnter(e, folder.name)}
                          onMouseMove={handleMouseMove}
                          onMouseLeave={handleMouseLeave}
                        >
                          {folder.name}
                        </span>
                      </div>
                      <div className="folder-actions-buttons">
                        <button
                          onClick={(e) => { e.stopPropagation(); handleUploadFiles(folder.name); }}
                          className="upload-btn"
                          disabled={isLimitReached}
                          title="Upload Files"
                          aria-label={`Upload files to ${folder.name}`}
                        >
                          <TbFilePlus style={{ fontSize: '20px', marginBottom: '0px', marginRight: '-4px' }}/>
                        </button>
                        <button
                          className="delete-folder-btn"
                          onClick={(e) => { e.stopPropagation(); handleDeleteFolder(folder.name); }}
                          title="Delete Folder"
                          disabled={isLimitReached}
                          aria-label={`Delete folder ${folder.name}`}
                        >
                          <TbTrash style={{ fontSize: '20px', marginBottom: '2px', marginRight: '0px' }}/>
                        </button>
                      </div>
                    </div>

                    <div className={`folder-actions ${isOpen ? 'open' : ''}`}>
                      <ul className="file-list">
                        {files.length > 0 ? (
                          files.slice(0, currentDisplayedFiles).map((file, idx) => (
                            <li key={idx} className="file-item">
                              <div className="file-container">
                                <button
                                  onClick={() => handleSelectFile(folder.name, file)}
                                  className="file-btn"
                                  onMouseEnter={(e) => handleFileMouseEnter(e, file)}
                                  onMouseLeave={handleMouseLeave}
                                  aria-label={`Select ${file.replace(/_/g, ' ')}`}
                                >
                                  <FaFileAlt className="file-icon" />
                                  <span className="file-name">{file.replace(/_/g, ' ')}</span>
                                </button>
                                <button
                                  className="preview-file-btn"
                                  onMouseEnter={(e) => handlePreviewMouseEnter(e, folder.name, file)}
                                  onMouseLeave={handlePreviewMouseLeave}
                                  title="Preview File"
                                  aria-label={`Preview ${file.replace(/_/g, ' ')}`}
                                >
                                  <FaEye style={{ fontSize: '15px', marginBottom: '2px', marginRight: '5px' }}/>
                                </button>
                                <button
                                  className="delete-file-btn"
                                  onClick={(e) => { e.stopPropagation(); handleDeleteFile(folder.name, file); }}
                                  title="Delete File"
                                  disabled={isLimitReached}
                                  aria-label={`Delete ${file.replace(/_/g, ' ')}`}
                                >
                                  <TbTrash style={{ fontSize: '18px', marginBottom: '2px', marginRight: '5px' }}/>
                                </button>
                              </div>
                            </li>
                          ))
                        ) : (
                          <li className="no-files">No files in this folder.</li>
                        )}
                      </ul>
                      {hasMoreFiles && (
                        <button
                          onClick={() => handleLoadMoreFiles(folder.name)}
                          className="btn load-more-btn"
                          aria-label={`Load more files in ${folder.name}`}
                        >
                          Load More Files
                        </button>
                      )}
                    </div>
                  </li>
                );
              })}
            </ul>
            {displayedFolders < folders.length && (
              <button
                onClick={handleLoadMoreFolders}
                className="btn load-more-btn"
                aria-label="Load more folders"
              >
                Load More Folders
              </button>
            )}
          </>
        ) : (
          <p className="no-folders-message">No folders available.</p>
        )}
      </div>

      {/* Tooltips */}
      <Tooltip visible={tooltip.visible} content={tooltip.content} position={tooltip.position} />
      <PreviewTooltip visible={previewTooltip.visible} imageSrc={previewTooltip.imageSrc} position={previewTooltip.position} />
    </div>
  );
};

FoldersSection.propTypes = {
  folders: PropTypes.arrayOf(
    PropTypes.shape({
      name: PropTypes.string.isRequired,
      lastModified: PropTypes.number.isRequired,
    })
  ).isRequired,
  expandedFolders: PropTypes.objectOf(PropTypes.bool).isRequired,
  toggleFolderExpansion: PropTypes.func.isRequired,
  filesInFolders: PropTypes.objectOf(PropTypes.arrayOf(PropTypes.string)).isRequired,
  handleSelectFile: PropTypes.func.isRequired,
  handleDeleteFile: PropTypes.func.isRequired,
  handleDeleteFolder: PropTypes.func.isRequired,
  handleUploadFiles: PropTypes.func.isRequired,
  openCreateFolderModal: PropTypes.func.isRequired,
  isLimitReached: PropTypes.bool.isRequired,
};

export default FoldersSection;
