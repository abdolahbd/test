// src/components/common/CheckoutForm.js
import React from 'react';
import { CardElement, useStripe, useElements } from '@stripe/react-stripe-js';
import api from '../../services/apiService';

const CheckoutForm = () => {
  const stripe = useStripe();
  const elements = useElements();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!stripe || !elements) return;

    const cardElement = elements.getElement(CardElement);

    // Create a payment method
    const { error, paymentMethod } = await stripe.createPaymentMethod({
      type: 'card',
      card: cardElement,
    });

    if (error) {
      console.error('[createPaymentMethod error]', error);
      // Display error to the user
    } else {
      try {
        // Send the payment method ID to your server to create a subscription
        const response = await api.post('/payment/subscribe', {
          paymentMethodId: paymentMethod.id,
        });
        alert('Subscription successful!');
        // Redirect or update UI as needed
      } catch (err) {
        console.error('[Subscription error]', err);
        // Display error to the user
      }
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <CardElement />
      <button type="submit" disabled={!stripe}>
        Subscribe
      </button>
    </form>
  );
};

export default CheckoutForm;
