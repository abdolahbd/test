// src/models/Requests.js

const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./User');

const Requests = sequelize.define('Requests', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    unique: true // Make sure each user can only have one Requests entry
  },
  requestCount: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  ip: { // New IP field added
    type: DataTypes.STRING(4500), // Supports IPv6
    // allowNull: false,
  }
}, {
  indexes: [
    // Removed year, month dependent indexes
    {
      unique: true,
      fields: ['user_id']
    }
  ],
  timestamps: true // You can keep or remove timestamps as needed
});

Requests.belongsTo(User, { foreignKey: 'user_id' });

module.exports = Requests;