// src/components/Modals/HelpModal.js
import React, { useState, useContext, useEffect, useReducer } from 'react';
import PropTypes from 'prop-types';
import { Modal, Button, Form, Alert, Spinner, Row, Col } from 'react-bootstrap';
import { AuthContext } from '../../contexts/AuthContext';
import api from '../../services/apiService';
import styles from './HelpModal.module.css'; // Import CSS Module

const initialState = {
  userId: '',
  text: '',
  errors: {},
};

const reducer = (state, action) => {
  switch (action.type) {
    case 'SET_FIELD':
      return { ...state, [action.field]: action.value };
    case 'SET_ERRORS':
      return { ...state, errors: action.errors };
    case 'RESET':
      return initialState;
    case 'SET_INITIAL_USER_ID':
      return { ...state, userId: action.userId };
    default:
      return state;
  }
};

const HelpModal = ({ show, handleClose, onHelpSubmitted = null }) => {
  const { user, token } = useContext(AuthContext);
  const [state, dispatch] = useReducer(reducer, initialState);
  const { userId, text, errors } = state;

  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const TEXT_MIN_LENGTH = 1;
  const TEXT_MAX_LENGTH = 500;

  // If authenticated, set the userId; if not, leave it blank
  useEffect(() => {
    if (user) {
      dispatch({ type: 'SET_INITIAL_USER_ID', userId: user.id });
    } else {
      dispatch({ type: 'SET_INITIAL_USER_ID', userId: '' });
    }
  }, [user]);

  const validate = () => {
    const validationErrors = {};

    // Only validate text length. userId isn't required since IP-based helps are allowed.
    const trimmedText = text.trim();
    if (!trimmedText) {
      validationErrors.text = 'Please enter your message.';
    } else if (trimmedText.length < TEXT_MIN_LENGTH) {
      validationErrors.text = `Message must be at least ${TEXT_MIN_LENGTH} characters.`;
    } else if (trimmedText.length > TEXT_MAX_LENGTH) {
      validationErrors.text = `Message cannot exceed ${TEXT_MAX_LENGTH} characters.`;
    }

    dispatch({ type: 'SET_ERRORS', errors: validationErrors });
    return Object.keys(validationErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    setErrorMessage('');
    setSuccessMessage('');

    if (!validate()) return;

    const helpData = {
      // Send userId if authenticated (the backend can handle if it's absent)
      ...(userId && { userId }),
      text: text.trim(),
    };

    setIsSubmitting(true);

    try {
      const config = { headers: { 'Content-Type': 'application/json' } };
      if (user && token) {
        config.headers.Authorization = `Bearer ${token}`;
      }

      // Make sure /helps is the correct endpoint on your backend
      const response = await api.post('/helps', helpData, config);

      if (response.status === 201 || response.status === 200) {
        setSuccessMessage('Your help request has been submitted successfully.');
        alert('#success:Your help request has been submitted successfully.');
        dispatch({ type: 'RESET' });
        if (onHelpSubmitted) {
          onHelpSubmitted(response.data.data);
        }
        onClose()
      } else {
        setErrorMessage('Unexpected response from the server. Please try again.');
      }
    } catch (err) {
      console.error('Error submitting help request:', err);
      if (err.response?.data?.error) {
        setErrorMessage(err.response.data.error);
      } else {
        setErrorMessage('There was an error submitting your request. Please try again.');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const onClose = () => {
    setErrorMessage('');
    setSuccessMessage('');
    dispatch({ type: 'RESET' });
    handleClose();
  };

  const canSubmit =
    !isSubmitting &&
    text.trim().length >= TEXT_MIN_LENGTH &&
    text.trim().length <= TEXT_MAX_LENGTH &&
    Object.keys(errors).length === 0;

  return (
    <Modal
      show={show}
      onHide={onClose}
      centered
      aria-labelledby="help-modal-title"
      backdrop // Enables closing the modal when clicking the backdrop
      keyboard={!isSubmitting}
      dialogClassName={styles.helpModalDialog} // Apply unique class to the modal dialog
      backdropClassName={styles.helpModalBackdrop} // Apply unique class to the backdrop
      contentClassName={styles.helpModalContent} // Apply unique class for the modal content
    >
      <Modal.Header closeButton={!isSubmitting}>
        <Modal.Title id="help-modal-title">Need Help?</Modal.Title>
      </Modal.Header>

      <Form onSubmit={handleSubmit} noValidate>
        <Modal.Body>
          {errorMessage && <Alert variant="danger" className="mb-3">{errorMessage}</Alert>}
          {successMessage && <Alert variant="success" className="mb-3">{successMessage}</Alert>}

          <Form.Group controlId="formText" className={styles.helpModalFormGroup}>
            <Form.Label>
              Message :
            </Form.Label>
            <Form.Control
              as="textarea"
              rows={5}
              placeholder="Describe your issue or request for help..."
              value={text}
              onChange={(e) => dispatch({ type: 'SET_FIELD', field: 'text', value: e.target.value })}
              isInvalid={!!errors.text}
              required
              maxLength={TEXT_MAX_LENGTH}
              className={styles.helpModalTextArea}
            />
            <Form.Control.Feedback type="invalid">
              {errors.text}
            </Form.Control.Feedback>
            <Row className="justify-content-between mt-1">
              <Col xs="auto" className="text-muted">
                {text.length}/{TEXT_MAX_LENGTH} characters
              </Col>
            </Row>
          </Form.Group>
        </Modal.Body>

        <Modal.Footer>
          <Button className={styles.closeBtnHelp}  variant="secondary" onClick={onClose} disabled={isSubmitting}>
            Close
          </Button>
          <Button className={styles.submitBtnHelp} variant="primary" type="submit" disabled={!canSubmit}>
            {isSubmitting ? (
              <>
                <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" />{' '}
                Submitting...
              </>
            ) : (
              'Submit'
            )}
          </Button>
        </Modal.Footer>
      </Form>
    </Modal>
  );
};

HelpModal.propTypes = {
  show: PropTypes.bool.isRequired,
  handleClose: PropTypes.func.isRequired,
  onHelpSubmitted: PropTypes.func, // This prop is now optional with a default value
};

export default HelpModal;
