// src/services/paymentService.js
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const User = require('../models/User');
const Subscription = require('../models/Subscription');

const createCheckoutSession = async (userId) => {
  try {

    
    // Fetch the user from the database
    const user = await User.findByPk(userId);
    console.log(user);
    if (!user) throw new Error('User not found');

    // Create or retrieve Stripe customer
    let customerId = user.stripeCustomerId;
    if (!customerId) {
      const customer = await stripe.customers.create({
        email: user.email,
        name: user.name,
      });
      customerId = customer.id;
      user.stripeCustomerId = customerId;
      await user.save();
    } else {
      // Ensure the Stripe customer's name is up-to-date with the user's name
      await stripe.customers.update(customerId, {
        name: user.name,
      });
    }

    // Create a Stripe Checkout Session
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'subscription',
      customer: customerId,
      line_items: [
        {
          price: 'price_1QaM4xIv97lOp7hMfOhcoCZz', // Replace with your actual price ID from Stripe
          quantity: 1,
        },
      ],
      success_url: `${process.env.FRONTEND_URL}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.FRONTEND_URL}/chat`,
      // Optionally, collect billing address if needed
      // billing_address_collection: 'required', 
      customer_update: {
        name: 'never', // Prevent Stripe from updating the customer's name based on Checkout input
      },
      // Optionally, add metadata or other parameters
    });

    return session;
  } catch (err) {
    console.error('Error creating Stripe Checkout Session:', err);
    throw new Error('Unable to create Stripe Checkout Session');
  }
};

// Optional: Function to update existing Stripe customers with their names
const updateCustomerName = async (userId) => {
  try {
    const user = await User.findByPk(userId);
    if (!user || !user.stripeCustomerId) throw new Error('User or Stripe Customer not found');

    await stripe.customers.update(user.stripeCustomerId, {
      name: user.name,
    });
  } catch (err) {
    console.error('Error updating Stripe Customer name:', err);
    throw new Error('Unable to update Stripe Customer name');
  }
};

module.exports = { createCheckoutSession, updateCustomerName };



