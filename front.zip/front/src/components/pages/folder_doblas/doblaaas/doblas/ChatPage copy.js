// src/components/pages/ChatPage.js

import React, { useState, useRef, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../../services/apiService';
import Modal from 'react-modal';
import './ChatPage.css';
import { AuthContext } from '../../contexts/AuthContext'; // Import AuthContext

const ChatPage = () => {
  // Access the current user from AuthContext
  const { user } = useContext(AuthContext);

  // State variables
  const [prompt, setPrompt] = useState('');
  const [messages, setMessages] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  // State to track if limit is reached
  const [isLimitReached, setIsLimitReached] = useState(false);

  // File system handles
  const [directoryHandle, setDirectoryHandle] = useState(null);
  const [conversationsHandle, setConversationsHandle] = useState(null);
  const [foldersHandle, setFoldersHandle] = useState(null);
  const [conversations, setConversations] = useState([]);
  const [currentConversation, setCurrentConversation] = useState(null);

  // State for managing uploaded images
  const [uploadedImages, setUploadedImages] = useState([]);

  // Refs
  const fileInputRef = useRef(null);
  const messagesEndRef = useRef(null);
  const iframeRef = useRef(null);
  const uploadFileInputRef = useRef(null); // Ref for per-folder uploads

  // Modal states
  const [isCreateFolderModalOpen, setIsCreateFolderModalOpen] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');

  // Modal states for renaming conversations
  const [isRenameModalOpen, setIsRenameModalOpen] = useState(false);
  const [renameConversation, setRenameConversation] = useState(null);
  const [newConversationName, setNewConversationName] = useState('');

  // Folder and File States
  const [folders, setFolders] = useState([]);
  const [expandedFolders, setExpandedFolders] = useState({});
  const [filesInFolders, setFilesInFolders] = useState({});

  // Mappings between image paths and Blob URLs
  const imagePathToBlobURLRef = useRef(new Map());
  const blobURLToImagePathRef = useRef(new Map());

  // Loading states
  const [isLoadingImages, setIsLoadingImages] = useState(false);

  // State for index.html content
  const [indexContent, setIndexContent] = useState(null);

  // State for tracking current upload folder
  const [currentUploadFolder, setCurrentUploadFolder] = useState(null);

  // State Variables for Collapsible and Load More
  const [isConversationsCollapsed, setIsConversationsCollapsed] = useState(false);
  const [displayedConversations, setDisplayedConversations] = useState(7);

  const [isFoldersCollapsed, setIsFoldersCollapsed] = useState(false);
  const [displayedFolders, setDisplayedFolders] = useState(7);

  // State to manage favorite conversations as an array of names
  const [favoriteConversations, setFavoriteConversations] = useState([]);

  // State to manage collapsing of Favorite Apps section
  const [isFavoriteAppsCollapsed, setIsFavoriteAppsCollapsed] = useState(false);

  // Scroll to the latest message
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Cleanup object URLs on unmount
  useEffect(() => {
    return () => {
      uploadedImages.forEach((img) => URL.revokeObjectURL(img.url));
      // Also revoke Blob URLs for favorite apps if any
      imagePathToBlobURLRef.current.forEach((url) => URL.revokeObjectURL(url));
    };
  }, [uploadedImages]);

  // Effect to auto-save conversations when messages change
  useEffect(() => {
    const saveConversation = async () => {
      if (currentConversation && conversationsHandle) {
        try {
          const conversationFolderHandle = await conversationsHandle.getDirectoryHandle(currentConversation.name);
          const fileHandle = await conversationFolderHandle.getFileHandle('conversation.json', { create: true });
          const writable = await fileHandle.createWritable();

          // Extract original content from messages
          const originalMessages = messages.map(({ sender, content, timestamp }) => ({
            sender,
            content,
            timestamp,
          }));

          // Read existing conversation.json to preserve allowedUsers
          let allowedUsers = [];
          try {
            const existingFile = await conversationFolderHandle.getFileHandle('conversation.json');
            const existingContent = await existingFile.getFile();
            const existingData = JSON.parse(await existingContent.text());
            allowedUsers = existingData.allowedUsers || [];
          } catch (err) {
            console.warn('conversation.json does not exist or is malformed. Initializing allowedUsers.');
          }

          // Prepare new conversation data
          const conversationData = {
            allowedUsers,
            messages: originalMessages,
          };

          await writable.write(JSON.stringify(conversationData, null, 2));
          await writable.close();
          console.log(`Conversation "${currentConversation.name}" saved automatically.`);
        } catch (err) {
          console.error('Error auto-saving conversation:', err);
        }
      }
    };

    saveConversation();
  }, [messages, currentConversation, conversationsHandle]);

  // Function to check user limit by calling the backend
  const checkUserLimit = async () => {
    try {
      const response = await api.get('/user/userStatus');
      const { isSubscribed, currentRequestCount, requestLimit, isLimitReached } = response.data;

      setIsLimitReached(isLimitReached);
      console.log(`User subscribed: ${isSubscribed}`);
      console.log(`Current request count: ${currentRequestCount}`);
      console.log(`Request limit: ${requestLimit}`);
    } catch (err) {
      console.error('Error checking user limit:', err);
      // Optionally, handle the error (e.g., show a notification)
    }
  };

  // Helper function to load favorites from 'favorites.json'
  const loadFavorites = async (dirHandle) => {
    try {
      const favoritesFileHandle = await dirHandle.getFileHandle('favorites.json');
      const file = await favoritesFileHandle.getFile();
      const contents = await file.text();
      const favorites = JSON.parse(contents); // Expected to be an array of names or array of objects with name

      let favoriteNames = [];
      if (Array.isArray(favorites)) {
        if (typeof favorites[0] === 'string') {
          // favorites.json is an array of names
          favoriteNames = favorites;
        } else if (typeof favorites[0] === 'object' && favorites[0].name) {
          // favorites.json is array of objects with name
          favoriteNames = favorites.map(fav => fav.name);
        }
      }
      setFavoriteConversations(favoriteNames);
      console.log('Favorites loaded:', favoriteNames);
    } catch (err) {
      if (err.name === 'NotFoundError') {
        // favorites.json does not exist, initialize with empty array
        setFavoriteConversations([]);
        console.log('favorites.json not found. Initializing empty favorites.');
      } else {
        console.error('Error loading favorites:', err);
        alert('Failed to load favorites.');
      }
    }
  };

  // Helper function to save favorites to 'favorites.json'
  const saveFavorites = async (dirHandle, favorites) => {
    try {
      const favoritesFileHandle = await dirHandle.getFileHandle('favorites.json', { create: true });
      const writable = await favoritesFileHandle.createWritable();
      await writable.write(JSON.stringify(favorites, null, 2)); // Save as array of names
      await writable.close();
      console.log('Favorites saved:', favorites);
    } catch (err) {
      console.error('Error saving favorites:', err);
      alert('Failed to save favorites.');
    }
  };

  // useEffect to Persist Favorites
  // This effect watches for changes in favoriteConversations and saves them to favorites.json
  useEffect(() => {
    const persistFavorites = async () => {
      if (directoryHandle) {
        await saveFavorites(directoryHandle, favoriteConversations);
      }
    };

    persistFavorites();
  }, [favoriteConversations, directoryHandle]); // Depend on favoriteConversations and directoryHandle

  // Function to toggle a conversation's favorite status
  const toggleFavoriteConversation = (conversation) => {
    const isFavorite = favoriteConversations.includes(conversation.name);
    if (isFavorite) {
      // Remove from favorites
      const updatedFavorites = favoriteConversations.filter((favName) => favName !== conversation.name);
      setFavoriteConversations(updatedFavorites);
      console.log(`Removed "${conversation.name}" from favorites.`);
    } else {
      // Add to favorites
      setFavoriteConversations([...favoriteConversations, conversation.name]);
      console.log(`Added "${conversation.name}" to favorites.`);
    }
  };

  // Function to remove a conversation from favorites
  const removeFavoriteConversation = (conversationName) => {
    const updatedFavorites = favoriteConversations.filter((favName) => favName !== conversationName);
    setFavoriteConversations(updatedFavorites);
    console.log(`Removed "${conversationName}" from favorites.`);
  };

  // Function to load all conversations from the 'conversations' directory
  const loadConversations = async (conversationsDirHandle) => {
    try {
      const convs = [];
      for await (const entry of conversationsDirHandle.values()) {
        if (entry.kind === 'directory') {
          try {
            const convoFolderHandle = entry;
            const convoFileHandle = await convoFolderHandle.getFileHandle('conversation.json');
            const convoFile = await convoFileHandle.getFile();
            const convoData = JSON.parse(await convoFile.text());

            // Check if current user is allowed to access the conversation
            if (convoData.allowedUsers && convoData.allowedUsers.includes(user.id)) {
              const lastModified = convoFile.lastModified; // milliseconds since epoch

              convs.push({
                name: entry.name,
                folderHandle: convoFolderHandle,
                lastModified,
              });
            } else {
              console.log(`User with ID "${user.id}" is not authorized to access conversation "${entry.name}".`);
            }
          } catch (err) {
            console.warn(`conversation.json not found or malformed for ${entry.name}. Skipping this conversation.`);
          }
        }
      }
      // Sort convs by lastModified descending
      convs.sort((a, b) => b.lastModified - a.lastModified);
      setConversations(convs);
      setDisplayedConversations(7); // Reset displayed conversations
    } catch (err) {
      console.error('Error loading conversations:', err);
      alert('Failed to load conversations.');
    }
  };

  // Function to load all uploaded images from the 'folders/images' folder
  const loadUploadedImages = async (foldersDirHandle) => {
    try {
      let imagesDirHandle;
      try {
        imagesDirHandle = await foldersDirHandle.getDirectoryHandle('images');
      } catch (err) {
        console.warn("'images' directory does not exist under 'folders'. Creating it.");
        imagesDirHandle = await foldersDirHandle.getDirectoryHandle('images', { create: true });
      }

      const imageFiles = [];
      for await (const entry of imagesDirHandle.values()) {
        if (entry.kind === 'file' && entry.name.match(/\.(jpg|jpeg|png|gif|bmp|webp)$/i)) {
          imageFiles.push(entry);
        }
      }

      const images = [];
      const imagePathToBlobURL = new Map();
      const blobURLToImagePathMap = new Map();

      for (const fileHandle of imageFiles) {
        try {
          const file = await fileHandle.getFile();
          const imageURL = URL.createObjectURL(file);
          const relativePath = `/images/${file.name}`; // Do not encode the file name here
          images.push({ name: file.name, path: relativePath, url: imageURL });
          imagePathToBlobURL.set(relativePath, imageURL);
          blobURLToImagePathMap.set(imageURL, relativePath);
          console.log(`Loaded image: ${relativePath} -> ${imageURL}`);
        } catch (err) {
          console.error(`Error reading image file ${fileHandle.name}:`, err);
        }
      }

      return { images, imagePathToBlobURL, blobURLToImagePathMap };
    } catch (err) {
      console.error('Error loading uploaded images:', err);
      alert('Failed to load uploaded images.');
      return { images: [], imagePathToBlobURL: new Map(), blobURLToImagePathMap: new Map() };
    }
  };

  // Function to load all folders from the 'folders' directory (including 'images')
  const loadFolders = async (foldersDirHandle) => {
    try {
      const folderEntries = [];
      for await (const entry of foldersDirHandle.values()) {
        if (entry.kind === 'directory') {
          try {
            // Attempt to read 'folder.json' for metadata
            const folderFileHandle = await entry.getFileHandle('folder.json');
            const folderFile = await folderFileHandle.getFile();
            const folderData = JSON.parse(await folderFile.text());
            const lastModified = folderData.lastModified || folderFile.lastModified || 0;

            folderEntries.push({
              name: entry.name,
              folderHandle: entry,
              lastModified,
            });
          } catch (err) {
            console.warn(`folder.json not found for ${entry.name}. Using 0 as lastModified.`);
            folderEntries.push({
              name: entry.name,
              folderHandle: entry,
              lastModified: 0,
            });
          }
        }
      }
      // Sort folders by lastModified descending
      folderEntries.sort((a, b) => b.lastModified - a.lastModified);
      setFolders(folderEntries);
      setDisplayedFolders(7); // Reset displayed folders
    } catch (err) {
      console.error('Error loading folders:', err);
      alert('Failed to load folders.');
    }
  };

  // Handler to select the root directory
  const handleSelectDirectory = async () => {
    if (!window.showDirectoryPicker) {
      alert('File System Access API is not supported in this browser.');
      return;
    }

    try {
      const dirHandle = await window.showDirectoryPicker();
      setDirectoryHandle(dirHandle);
      console.log('Root directory selected:', dirHandle.name);

      // Ensure 'conversations' and 'folders' directories exist
      const conversationsDirHandle = await getOrCreateDirectory(dirHandle, 'conversations');
      const foldersDirHandle = await getOrCreateDirectory(dirHandle, 'folders');
      setConversationsHandle(conversationsDirHandle);
      setFoldersHandle(foldersDirHandle);

      // Load favorites after selecting directory
      await loadFavorites(dirHandle);

      // Ensure 'images' directory exists under 'folders'
      await getOrCreateDirectory(foldersDirHandle, 'images');

      // Load images first from 'folders/images'
      setIsLoadingImages(true);
      const { images, imagePathToBlobURL, blobURLToImagePathMap } = await loadUploadedImages(foldersDirHandle);
      setUploadedImages(images);
      imagePathToBlobURLRef.current = imagePathToBlobURL;
      blobURLToImagePathRef.current = blobURLToImagePathMap;
      setIsLoadingImages(false);
      console.log('Images loaded and mappings established.');

      // Then load conversations from 'conversations' folder
      await loadConversations(conversationsDirHandle);
      console.log('Conversations loaded.');

      // Finally, load other folders from 'folders' directory
      await loadFolders(foldersDirHandle);
      console.log('Folders loaded.');

      // **NEW: Check user limit after selecting directory**
      await checkUserLimit();
    } catch (err) {
      console.error('Error selecting directory:', err);
      alert('Failed to select directory.');
    }
  };

  // Helper function to get or create a directory
  const getOrCreateDirectory = async (parentHandle, dirName) => {
    try {
      const dirHandle = await parentHandle.getDirectoryHandle(dirName);
      return dirHandle;
    } catch (err) {
      // Directory does not exist, create it
      const newDirHandle = await parentHandle.getDirectoryHandle(dirName, { create: true });
      console.log(`Created directory: ${dirName}`);
      return newDirHandle;
    }
  };

  // Updated: handleCreateConversation to prevent duplicate names
  const handleCreateConversation = async () => {
    if (!conversationsHandle) {
      alert('Please select a directory first.');
      return;
    }

    const convoName = window.prompt('Enter a name for the new conversation:', `Conversation ${conversations.length + 1}`);
    if (!convoName) {
      alert('Conversation name is required.');
      return;
    }

    try {
      // Check if a conversation with the same name already exists
      await conversationsHandle.getDirectoryHandle(convoName, { create: false });
      // If no error is thrown, the conversation exists
      alert('A conversation with this name already exists.');
      return;
    } catch (err) {
      if (err.name !== 'NotFoundError') {
        console.error('Error checking conversation existence:', err);
        alert('Failed to create conversation.');
        return;
      }
      // If NotFoundError, the conversation does not exist, proceed to create
    }

    try {
      // Create the conversation folder inside 'conversations'
      const folderHandle = await conversationsHandle.getDirectoryHandle(convoName, { create: true });

      // Create conversation.json with allowedUsers
      const conversationData = {
        allowedUsers: [user.id], // Store the user's ID
        messages: [], // Initialize with empty messages
      };

      // Create the conversation.json file with the above data
      const fileHandle = await folderHandle.getFileHandle('conversation.json', { create: true });
      const writable = await fileHandle.createWritable();
      await writable.write(JSON.stringify(conversationData, null, 2));
      await writable.close();

      const newConversation = {
        name: convoName,
        folderHandle: folderHandle,
        lastModified: Date.now(), // Assign current time as lastModified
      };
      setConversations((prev) => [newConversation, ...prev]);
      setCurrentConversation(newConversation);
      setMessages([]);
      setIndexContent(null);
      setDisplayedConversations((prev) => prev + 1); // Adjust if needed
      alert(`Conversation "${convoName}" created successfully.`);
      console.log(`Created new conversation: ${convoName}`);
    } catch (err) {
      console.error('Error creating conversation:', err);
      alert('Failed to create conversation.');
    }
  };

  // Handler to open the Rename Conversation Modal
  const openRenameConversationModal = (conversation) => {
    setRenameConversation(conversation);
    setNewConversationName(conversation.name);
    setIsRenameModalOpen(true);
  };

  // Handler to close the Rename Conversation Modal
  const closeRenameConversationModal = () => {
    setIsRenameModalOpen(false);
    setRenameConversation(null);
    setNewConversationName('');
  };

  // Handler to rename a conversation
  const handleRenameConversation = async () => {
    if (!newConversationName.trim()) {
      alert('Conversation name cannot be empty.');
      return;
    }

    // Check for invalid characters
    const invalidChars = /[<>:"/\\|?*\x00-\x1F]/g;
    if (invalidChars.test(newConversationName)) {
      alert('Conversation name contains invalid characters.');
      return;
    }

    // Check if a conversation with the new name already exists
    try {
      await conversationsHandle.getDirectoryHandle(newConversationName, { create: false });
      // If no error is thrown, the conversation exists
      alert('A conversation with this name already exists.');
      return;
    } catch (err) {
      if (err.name !== 'NotFoundError') {
        console.error('Error checking conversation existence:', err);
        alert('Failed to rename conversation.');
        return;
      }
      // If NotFoundError, the conversation does not exist, proceed to rename
    }

    try {
      const oldName = renameConversation.name;
      const newName = newConversationName.trim();

      // Create the new folder
      const newFolderHandle = await conversationsHandle.getDirectoryHandle(newName, { create: true });

      // Recursive copy of all entries (files and subdirectories) from old to new folder
      const copyDirectoryRecursively = async (sourceHandle, destinationHandle) => {
        for await (const entry of sourceHandle.values()) {
          if (entry.kind === 'file') {
            const file = await entry.getFile();
            const newFileHandle = await destinationHandle.getFileHandle(entry.name, { create: true });
            const writable = await newFileHandle.createWritable();
            await writable.write(file);
            await writable.close();
          } else if (entry.kind === 'directory') {
            const newSubDirHandle = await destinationHandle.getDirectoryHandle(entry.name, { create: true });
            await copyDirectoryRecursively(entry, newSubDirHandle);
          }
        }
      };

      await copyDirectoryRecursively(renameConversation.folderHandle, newFolderHandle);
      console.log(`Copied contents from "${oldName}" to "${newName}".`);

      // Delete the old folder
      await conversationsHandle.removeEntry(oldName, { recursive: true });
      console.log(`Deleted old conversation folder: "${oldName}".`);

      // Update the conversations state
      setConversations((prevConvos) =>
        prevConvos.map((convo) =>
          convo.name === oldName
            ? { ...convo, name: newName, folderHandle: newFolderHandle }
            : convo
        )
      );

      // If the conversation is a favorite, update its name in favorites
      if (favoriteConversations.includes(oldName)) {
        setFavoriteConversations((prevFavorites) =>
          prevFavorites.map((fav) => (fav === oldName ? newName : fav))
        );
      }

      // If the renamed conversation is the current one, update currentConversation
      if (currentConversation && currentConversation.name === oldName) {
        setCurrentConversation({ ...currentConversation, name: newName, folderHandle: newFolderHandle });
      }

      alert(`Conversation renamed from "${oldName}" to "${newName}" successfully.`);
      console.log(`Renamed conversation "${oldName}" to "${newName}".`);
      closeRenameConversationModal();
    } catch (err) {
      console.error('Error renaming conversation:', err);
      alert('Failed to rename conversation.');
    }
  };

  // Handler to delete a conversation
  const handleDeleteConversation = async (conversation) => {
    if (!window.confirm(`Are you sure you want to delete the conversation "${conversation.name}"? This action cannot be undone.`)) {
      return;
    }

    try {
      // Delete the conversation folder
      await conversationsHandle.removeEntry(conversation.name, { recursive: true });

      // Update the conversations state
      setConversations((prevConvos) => prevConvos.filter((convo) => convo.name !== conversation.name));

      // If the conversation is a favorite, remove it from favorites
      if (favoriteConversations.includes(conversation.name)) {
        setFavoriteConversations((prevFavorites) =>
          prevFavorites.filter((fav) => fav !== conversation.name)
        );
      }

      // If the deleted conversation was the current one, reset the chat
      if (currentConversation && currentConversation.name === conversation.name) {
        setCurrentConversation(null);
        setMessages([]);
        setIndexContent(null);
      }

      alert(`Conversation "${conversation.name}" deleted successfully.`);
      console.log(`Deleted conversation "${conversation.name}".`);
    } catch (err) {
      console.error('Error deleting conversation:', err);
      alert('Failed to delete conversation.');
    }
  };

  // Function to load a selected conversation
  const handleLoadConversation = async (conversation) => {
    try {
      const conversationFolderHandle = conversation.folderHandle;
      const fileHandle = await conversationFolderHandle.getFileHandle('conversation.json');
      const file = await fileHandle.getFile();
      const contents = await file.text();
      const convoData = JSON.parse(contents);

      // Ensure the user is authorized to access this conversation
      if (!convoData.allowedUsers || !convoData.allowedUsers.includes(user.id)) {
        alert('You are not authorized to access this conversation.');
        return;
      }

      const loadedMessages = convoData.messages;

      if (!Array.isArray(loadedMessages)) {
        throw new Error('Invalid conversation format.');
      }

      // Map loaded messages to include displayContent for assistant messages
      const mappedMessages = loadedMessages.map((msg) => {
        if (msg.sender === 'assistant') {
          const modifiedDisplayContent = replaceRelativePathsWithBlobURLs(msg.content);
          return {
            ...msg,
            displayContent: modifiedDisplayContent,
          };
        }
        return {
          ...msg,
          displayContent: msg.content, // For user messages, displayContent is the same as content
        };
      });

      setMessages(mappedMessages);
      setCurrentConversation(conversation);
      setError(null);
      console.log(`Conversation "${conversation.name}" loaded.`);

      // Get the index.html content
      await getConversationIndexContent(conversation);
    } catch (err) {
      console.error('Error loading conversation:', err);
      alert('Failed to load conversation. Please ensure the conversation folder contains "conversation.json".');
      setIndexContent(null);
    }
  };

  // Handler to select a conversation from the sidebar
  const handleSelectConversation = async (conversation, index) => {
    if (isLimitReached && index >= 3) {
      // Do not allow selection beyond the first 3 conversations
      return;
    }
    await handleLoadConversation(conversation);
  };

  // Handler to send a prompt with limited context
  const handleSend = async () => {
    if (!prompt.trim()) {
      setError('Please enter a valid prompt.');
      return;
    }

    if (!currentConversation) {
      setError('Please select or create a conversation first.');
      return;
    }

    // Prepare the last exchange (last user and assistant messages)
    const lastExchange = [];
    if (messages.length >= 2) {
      const lastUserMessage = messages[messages.length - 2];
      const lastAssistantMessage = messages[messages.length - 1];
      if (lastUserMessage.sender === 'user' && lastAssistantMessage.sender === 'assistant') {
        // Replace Blob URLs with original paths in assistant message
        const processedAssistantContent = replaceBlobURLsWithPaths(lastAssistantMessage.displayContent);
        lastExchange.push(
          { ...lastUserMessage, content: lastUserMessage.content },
          { ...lastAssistantMessage, content: processedAssistantContent }
        );
      }
    }

    // Add user message
    const userMessage = {
      sender: 'user',
      content: prompt,
      displayContent: prompt, // For user messages, displayContent is the same as content
      timestamp: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, userMessage]);

    setLoading(true);
    setError(null);
    setPrompt('');

    try {
      // Send the prompt along with the last exchange as context, and include the conversation name
      const response = await api.post('/request', {
        prompt,
        messages: lastExchange,
        conversationName: currentConversation.name,
      });
      const assistantCode = response.data.code;
      console.log(assistantCode);

      // Replace relative paths with Blob URLs for display
      const modifiedCode = replaceRelativePathsWithBlobURLs(assistantCode);

      console.log(modifiedCode);

      // Add assistant message with modified code
      const assistantMessage = {
        sender: 'assistant',
        content: assistantCode, // Original content
        displayContent: modifiedCode, // Modified for display
        timestamp: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, assistantMessage]);

      // Save the assistant code to index.html and assets
      await saveAssistantCode(assistantCode);

      // Update the indexContent to display the new code
      await getConversationIndexContent(currentConversation);
    } catch (err) {
      if (err.response) {
        const errorMsg = err.response.data.error || 'An error occurred. Please try again.';
        setError(errorMsg);
        if (errorMsg === 'Request limit reached. Upgrade your account.') {
          setIsLimitReached(true);
        }
      } else if (err.request) {
        setError('No response from server. Please try again later.');
      } else {
        setError('An unexpected error occurred.');
      }
    } finally {
      setLoading(false);
    }
  };

  // Function to escape special characters in a string to be used in a regular expression
  const escapeRegExp = (string) => {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  };

  // Function to save assistant code to index.html and copy assets
  const saveAssistantCode = async (codeContent) => {
    if (!directoryHandle) {
      alert('Please select a directory first.');
      return;
    }

    if (!currentConversation) {
      alert('Please select or create a conversation first.');
      return;
    }

    try {
      // Create or get the conversation folder inside 'conversations'
      const conversationFolderHandle = await conversationsHandle.getDirectoryHandle(currentConversation.name, { create: true });

      // Create or get the 'assets' folder inside the conversation folder
      const assetsFolderHandle = await conversationFolderHandle.getDirectoryHandle('assets', { create: true });

      // Extract image paths from the code
      const imagePaths = extractImagePaths(codeContent);

      // Copy images to the 'assets' folder and update the code
      let modifiedCodeContent = codeContent;

      for (const imagePath of imagePaths) {
        // Determine if the image is from 'folders/images' or 'assets'
        if (imagePath.startsWith('/images/') || imagePath.startsWith('/assets/')) {
          // Get the image file from the 'folders/images' folder
          try {
            const imageFileName = decodeURIComponent(imagePath.split('/').pop());
            const imageFileHandle = await foldersHandle.getDirectoryHandle('images').then(dir => dir.getFileHandle(imageFileName));
            const imageFile = await imageFileHandle.getFile();

            // Check if the image already exists in 'assets'. If so, skip copying.
            let newImagePath = `assets/${imageFileHandle.name}`;
            try {
              await assetsFolderHandle.getFileHandle(imageFileHandle.name, { create: false });
              // If no error, the file exists. Skip copying to prevent duplicates.
              console.log(`Image "${newImagePath}" already exists in assets. Skipping copy.`);
            } catch (err) {
              if (err.name === 'NotFoundError') {
                // Image does not exist, proceed to copy
                const newImageFileHandle = await assetsFolderHandle.getFileHandle(imageFileHandle.name, { create: true });
                const writable = await newImageFileHandle.createWritable();
                await writable.write(imageFile);
                await writable.close();
                console.log(`Copied image "${imageFileHandle.name}" to assets.`);
              } else {
                throw err; // Re-throw unexpected errors
              }
            }

            // Update the code to point to the image in 'assets' folder
            const escapedImagePath = escapeRegExp(imagePath);
            const regex = new RegExp(escapedImagePath, 'g');
            modifiedCodeContent = modifiedCodeContent.replace(regex, newImagePath);
          } catch (err) {
            console.error(`Image file ${imagePath} not found in 'folders/images' directory.`);
          }
        }
      }

      // Save the modified code as index.html in the conversation folder
      const indexFileHandle = await conversationFolderHandle.getFileHandle('index.html', { create: true });
      const indexWritable = await indexFileHandle.createWritable();
      await indexWritable.write(modifiedCodeContent);
      await indexWritable.close();

      console.log(`Code saved in conversations/${currentConversation.name}/index.html`);
    } catch (err) {
      console.error('Error saving code:', err);
      alert('Failed to save code.');
    }
  };

  // Function to extract image paths from the code
  const extractImagePaths = (htmlContent) => {
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlContent, 'text/html');

    const images = doc.querySelectorAll('img');

    const imagePaths = [];

    images.forEach((img) => {
      let src = img.getAttribute('src');
      if (src && !src.startsWith('data:') && !src.startsWith('http')) {
        src = decodeURIComponent(src);
        imagePaths.push(src);
      }
    });

    return imagePaths;
  };

  // Handler to reset the current conversation
  const handleResetConversation = () => {
    if (window.confirm('Are you sure you want to reset the current conversation?')) {
      setMessages([]);
      setIndexContent(null);
      console.log('Conversation reset.');
    }
  };

  // Handler to navigate to the subscription page
  const handleUpgrade = () => {
    navigate('/subscribe');
    // Optionally, reset the limit after navigating
    setIsLimitReached(false);
  };

  // Handler to open the Create Folder Modal
  const openCreateFolderModal = () => {
    setNewFolderName('');
    setIsCreateFolderModalOpen(true);
  };

  // Handler to close the Create Folder Modal
  const closeCreateFolderModal = () => {
    setIsCreateFolderModalOpen(false);
  };

  // Handler to create a new folder inside 'folders'
  const handleCreateFolder = async () => {
    if (!foldersHandle) {
      alert('Folders directory handle is missing.');
      return;
    }

    if (!newFolderName.trim()) {
      alert('Folder name cannot be empty.');
      return;
    }

    const invalidChars = /[<>:"/\\|?*\x00-\x1F]/g;
    if (invalidChars.test(newFolderName)) {
      alert('Folder name contains invalid characters.');
      return;
    }

    if (newFolderName.toLowerCase() === 'images') {
      alert('A folder named "images" already exists and is reserved for image uploads.');
      return;
    }

    try {
      // Check if folder already exists inside 'folders'
      try {
        await foldersHandle.getDirectoryHandle(newFolderName);
        alert('A folder with this name already exists.');
        return;
      } catch (err) {
        // Folder does not exist, proceed to create
      }

      const newFolderHandle = await foldersHandle.getDirectoryHandle(newFolderName, { create: true });

      // Optionally, create a folder.json to store metadata (e.g., lastModified)
      const folderMetadata = {
        name: newFolderName,
        createdAt: Date.now(),
        lastModified: Date.now(), // Initialize lastModified
        // Add more metadata if needed
      };
      const metadataFileHandle = await newFolderHandle.getFileHandle('folder.json', { create: true });
      const writable = await metadataFileHandle.createWritable();
      await writable.write(JSON.stringify(folderMetadata, null, 2));
      await writable.close();

      const newFolder = {
        name: newFolderName,
        folderHandle: newFolderHandle,
        lastModified: folderMetadata.lastModified,
      };

      setFolders((prev) => [newFolder, ...prev]);
      alert(`Folder "${newFolderName}" created successfully.`);
      console.log(`Created folder: ${newFolderName}`);
      closeCreateFolderModal();
      setDisplayedFolders((prev) => prev + 1); // Adjust if needed
    } catch (err) {
      console.error('Error creating folder:', err);
      alert('Failed to create folder.');
    }
  };

  // Handler to toggle folder expansion
  const toggleFolderExpansion = async (folderName) => {
    setExpandedFolders((prev) => ({
      ...prev,
      [folderName]: !prev[folderName],
    }));

    if (!expandedFolders[folderName] && !filesInFolders[folderName]) {
      try {
        const folderHandle = await foldersHandle.getDirectoryHandle(folderName);
        const files = [];
        for await (const entry of folderHandle.values()) {
          if (entry.kind === 'file') {
            files.push(entry.name);
          }
        }
        setFilesInFolders((prev) => ({
          ...prev,
          [folderName]: files,
        }));
        console.log(`Loaded files for folder "${folderName}":`, files);
      } catch (err) {
        console.error(`Error loading files for folder "${folderName}":`, err);
        alert(`Failed to load files for folder "${folderName}".`);
      }
    }
  };

  // Handler to select a file from a folder
  const handleSelectFile = async (folderName, fileName) => {
    const relativePath = `/${folderName}/${fileName}`; // Removed trailing space
    insertAtCursor(relativePath);
    console.log(`Inserted file path: ${relativePath}`);
  };

  // Function to insert text at cursor position in textarea
  const insertAtCursor = (insertText) => {
    const textarea = document.getElementById('prompt-textarea');
    if (!textarea) return;

    const startPos = textarea.selectionStart;
    const endPos = textarea.selectionEnd;
    const before = prompt.substring(0, startPos);
    const after = prompt.substring(endPos, prompt.length);
    const newText = before + insertText + after;
    setPrompt(newText);

    setTimeout(() => {
      textarea.selectionStart = textarea.selectionEnd = startPos + insertText.length;
      textarea.focus();
    }, 0);
  };

  // Handler for key presses in the textarea
  const handleTextareaKeyDown = (e) => {
    if (e.key === '/' && !e.ctrlKey && !e.altKey && !e.metaKey) {
      e.preventDefault();
      // Optionally, you can trigger some action here when '/' is pressed
    }
  };

  // Function to replace blob URLs with original paths in HTML content
  const replaceBlobURLsWithPaths = (htmlContent) => {
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlContent, 'text/html');

    const images = doc.querySelectorAll('img');

    images.forEach((img) => {
      let src = img.getAttribute('src');
      if (src && src.startsWith('blob:')) {
        const originalPath = blobURLToImagePathRef.current.get(src);
        if (originalPath) {
          img.setAttribute('src', originalPath);
        }
      }
    });

    return doc.documentElement.outerHTML;
  };

  // Function to replace relative paths with Blob URLs in the HTML content
  const replaceRelativePathsWithBlobURLs = (htmlContent) => {
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlContent, 'text/html');

    const images = doc.querySelectorAll('img');

    images.forEach((img) => {
      let src = img.getAttribute('src');
      if (src) {
        src = decodeURIComponent(src);
        if (src.startsWith('/images/') || src.startsWith('/assets/')) {
          const blobURL = imagePathToBlobURLRef.current.get(src);
          if (blobURL) {
            console.log(`Replacing ${src} with Blob URL: ${blobURL}`);
            img.setAttribute('src', blobURL);
          } else {
            console.warn(`No Blob URL found for image path: ${src}`);
            img.setAttribute('src', '/placeholder.png');
            img.setAttribute('alt', 'Image not found');
          }
        }
      }
    });

    return doc.documentElement.outerHTML;
  };

  // Function to get the content of index.html from the conversation folder
  const getConversationIndexContent = async (conversation) => {
    if (!conversation || !conversationsHandle) {
      setIndexContent(null);
      return;
    }
    try {
      const conversationFolderHandle = await conversationsHandle.getDirectoryHandle(conversation.name);
      const indexFileHandle = await conversationFolderHandle.getFileHandle('index.html');
      const file = await indexFileHandle.getFile();
      const fileContent = await file.text();

      // Read images from assets folder and create Blob URLs
      const assetsFolderHandle = await conversationFolderHandle.getDirectoryHandle('assets');
      const assetFiles = {};
      for await (const entry of assetsFolderHandle.values()) {
        if (entry.kind === 'file') {
          const assetFile = await entry.getFile();
          const assetBlobURL = URL.createObjectURL(assetFile);
          const assetPath = `assets/${entry.name}`; // Do not encode the file name
          assetFiles[assetPath] = assetBlobURL;
        }
      }

      // Replace image src attributes with Blob URLs
      const parser = new DOMParser();
      const doc = parser.parseFromString(fileContent, 'text/html');

      const images = doc.querySelectorAll('img');

      images.forEach((img) => {
        let src = img.getAttribute('src');
        if (src) {
          src = decodeURIComponent(src);
          if (assetFiles[src]) {
            img.setAttribute('src', assetFiles[src]);
          } else {
            console.warn(`Image not found: ${src}`);
          }
        }
      });

      const modifiedHTML = doc.documentElement.outerHTML;

      setIndexContent(modifiedHTML);
    } catch (err) {
      console.error('Error getting index.html content:', err);
      setIndexContent(null);
    }
  };

  // Add Event Listeners to Handle Messages from the Iframe
  useEffect(() => {
    const handleMessage = async (event) => {
      // Ensure the iframe reference is not null
      if (!iframeRef.current || event.source !== iframeRef.current.contentWindow) {
        return;
      }

      const { type, payload } = event.data;

      switch (type) {
        case 'READ_FILE':
          // Read a file from the conversation folder and send it back
          try {
            const data = await readFile(payload.filename);
            event.source.postMessage({ type: 'FILE_CONTENT', payload: { filename: payload.filename, content: data } }, '*');
          } catch (err) {
            console.error(`Error reading file ${payload.filename}:`, err);
            event.source.postMessage({ type: 'ERROR', payload: `Failed to read file ${payload.filename}.` }, '*');
          }
          break;
        case 'WRITE_FILE':
          // Write data to a file in the conversation folder
          try {
            await writeFile(payload.filename, payload.content);
            event.source.postMessage({ type: 'WRITE_SUCCESS', payload: { filename: payload.filename } }, '*');
          } catch (err) {
            console.error(`Error writing to file ${payload.filename}:`, err);
            event.source.postMessage({ type: 'ERROR', payload: `Failed to write file ${payload.filename}.` }, '*');
          }
          break;
        default:
          console.warn('Unknown message type:', type);
          break;
      }
    };

    window.addEventListener('message', handleMessage);

    return () => {
      window.removeEventListener('message', handleMessage);
    };
  }, [currentConversation, conversationsHandle]);

  // General function to read a file
  const readFile = async (filename) => {
    if (!currentConversation || !conversationsHandle) {
      throw new Error('No conversation selected.');
    }
    const conversationFolderHandle = await conversationsHandle.getDirectoryHandle(currentConversation.name);
    try {
      const fileHandle = await conversationFolderHandle.getFileHandle(filename);
      const file = await fileHandle.getFile();
      const contents = await file.text();
      return contents;
    } catch (err) {
      console.warn(`${filename} not found. Returning empty content.`);
      return ''; // Return empty content if file doesn't exist
    }
  };

  // General function to write to a file
  const writeFile = async (filename, content) => {
    if (!currentConversation || !conversationsHandle) {
      throw new Error('No conversation selected.');
    }
    const conversationFolderHandle = await conversationsHandle.getDirectoryHandle(currentConversation.name);
    const fileHandle = await conversationFolderHandle.getFileHandle(filename, { create: true });
    const writable = await fileHandle.createWritable();
    await writable.write(content);
    await writable.close();
    console.log(`Data saved to ${filename}`);
  };

  // Compute the last assistant message
  const lastAssistantMessage = messages.slice().reverse().find((msg) => msg.sender === 'assistant');

  // Function to handle per-folder file uploads
  const handlePerFolderFileUpload = async (event) => {
    const files = event.target.files;
    if (files.length === 0 || !currentUploadFolder) return;

    try {
      // Get the folder handle
      const folderHandle = await foldersHandle.getDirectoryHandle(currentUploadFolder, { create: true });

      const newUploadedFiles = [];
      const folderPathToBlobURL = imagePathToBlobURLRef.current; // Reusing the same mapping for all file types
      const blobURLToFolderPathMap = blobURLToImagePathRef.current; // Reusing the same mapping

      for (const file of files) {
        let fileName = file.name;
        let counter = 1;
        while (true) {
          try {
            await folderHandle.getFileHandle(fileName);
            const nameParts = fileName.split('.');
            const extension = nameParts.pop();
            const baseName = nameParts.join('.');
            fileName = `${baseName}(${counter}).${extension}`;
            counter += 1;
          } catch (err) {
            break;
          }
        }

        const newFileHandle = await folderHandle.getFileHandle(fileName, { create: true });
        const writable = await newFileHandle.createWritable();
        await writable.write(file);
        await writable.close();

        const fileURL = URL.createObjectURL(file);
        const relativePath = `/${currentUploadFolder}/${fileName}`; // Do not encode the file name
        newUploadedFiles.push({ name: fileName, path: relativePath, url: fileURL });
        folderPathToBlobURL.set(relativePath, fileURL);
        blobURLToFolderPathMap.set(fileURL, relativePath);
        console.log(`Uploaded file: ${relativePath} -> ${fileURL}`);
      }

      // Update state with new files
      setUploadedImages((prev) => [...prev, ...newUploadedFiles]);

      // Update the filesInFolders state for the current upload folder
      setFilesInFolders((prev) => ({
        ...prev,
        [currentUploadFolder]: [...(prev[currentUploadFolder] || []), ...newUploadedFiles.map(file => file.name)],
      }));

      alert('Files uploaded successfully!');
    } catch (err) {
      console.error('Error uploading files:', err);
      alert('Failed to upload files.');
    } finally {
      // Reset currentUploadFolder
      setCurrentUploadFolder(null);
      // Reset the file input value to allow uploading the same file again if needed
      if (uploadFileInputRef.current) {
        uploadFileInputRef.current.value = '';
      }
    }
  };

  // Handler to toggle the collapse of Conversations section
  const toggleConversationsCollapse = () => {
    setIsConversationsCollapsed(!isConversationsCollapsed);
  };

  // Handler to toggle the collapse of Folders section
  const toggleFoldersCollapse = () => {
    setIsFoldersCollapsed(!isFoldersCollapsed);
  };

  // Function to toggle the collapse state of Favorite Apps section
  const toggleFavoriteAppsCollapse = () => {
    setIsFavoriteAppsCollapsed(!isFavoriteAppsCollapsed);
  };

  return (
    <div className="chat-page">
      {/* Red Limit Reached Bar */}
      {isLimitReached && (
        <div className="limit-reached-bar">
          <span>You reached limits to continue use all features. </span>
          <button onClick={handleUpgrade} className="upgrade-account-btn">
            Upgrade Account
          </button>
        </div>
      )}

      {/* Sidebar */}
      <div className="sidebar">
        {/* Conversations Section */}
        <div className="sidebar-section conversations-section">
          <button onClick={handleSelectDirectory} className="btn" disabled={isLimitReached}>
            Select Directory
          </button>
          <button onClick={handleCreateConversation} className="btn" disabled={isLimitReached}>
            New Conversation
          </button>

          {/* Collapsible Header */}
          <div
            className="conversations-header"
            onClick={toggleConversationsCollapse}
            style={{
              cursor: 'pointer',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginTop: '10px',
              marginBottom: '5px',
            }}
          >
            <h2>Conversations</h2>
            <button className="collapse-btn" style={{ background: 'none', border: 'none', fontSize: '1.2em' }}>
              {isConversationsCollapsed ? '+' : '-'}
            </button>
          </div>

          {/* Conversation List */}
          {!isConversationsCollapsed && (
            <>
              {conversations.length > 0 ? (
                <>
                  <ul className="conversation-list">
                    {conversations.slice(0, displayedConversations).map((convo, index) => (
                      <li
                        key={index}
                        className={`conversation-item ${
                          currentConversation && currentConversation.name === convo.name ? 'active' : ''
                        } ${isLimitReached && index >= 3 ? 'disabled-conversation' : ''}`}
                        onClick={() => handleSelectConversation(convo, index)}
                        style={isLimitReached && index >= 3 ? { pointerEvents: 'none', opacity: 0.5 } : {}}
                      >
                        <span>{convo.name}</span>
                        <div className="conversation-actions">
                          {/* Conditional Rendering of Action Buttons */}
                          {!isLimitReached && (
                            <>
                              {/* Favorite Button */}
                              <button
                                className="save-favorite-btn"
                                onClick={(e) => {
                                  e.stopPropagation(); // Prevent triggering the conversation load
                                  toggleFavoriteConversation(convo);
                                }}
                                title={
                                  favoriteConversations.includes(convo.name)
                                    ? 'Remove from Favorites'
                                    : 'Save to Favorites'
                                }
                              >
                                {favoriteConversations.includes(convo.name) ? '★' : '☆'}
                              </button>

                              {/* Rename Button */}
                              <button
                                className="rename-conversation-btn"
                                onClick={(e) => {
                                  e.stopPropagation(); // Prevent triggering the conversation load
                                  openRenameConversationModal(convo);
                                }}
                                title="Rename Conversation"
                              >
                                ✏️
                              </button>

                              {/* Delete Button */}
                              <button
                                className="delete-conversation-btn"
                                onClick={(e) => {
                                  e.stopPropagation(); // Prevent triggering the conversation load
                                  handleDeleteConversation(convo);
                                }}
                                title="Delete Conversation"
                              >
                                🗑️
                              </button>
                            </>
                          )}
                        </div>
                      </li>
                    ))}
                  </ul>
                  {/* Load More Button */}
                  {displayedConversations < conversations.length && (
                    <button
                      onClick={() => setDisplayedConversations((prev) => prev + 7)}
                      className="btn load-more-btn"
                      style={{ marginTop: '5px' }}
                    >
                      Load More
                    </button>
                  )}
                </>
              ) : (
                <p>No conversations available.</p>
              )}
            </>
          )}
        </div>

        {/* Favorite Apps Section */}
        <div className="sidebar-section favorite-apps-section">
          {/* Collapsible Header */}
          <div
            className="favorite-apps-header"
            onClick={toggleFavoriteAppsCollapse}
            style={{
              cursor: 'pointer',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginTop: '10px',
              marginBottom: '5px',
            }}
          >
            <h2>Favorite Apps</h2>
            <button className="collapse-btn" style={{ background: 'none', border: 'none', fontSize: '1.2em' }}>
              {isFavoriteAppsCollapsed ? '+' : '-'}
            </button>
          </div>

          {/* Favorite Apps List */}
          {!isFavoriteAppsCollapsed && (
            <>
              {favoriteConversations.length > 0 ? (
                <ul className="favorite-apps-list">
                  {favoriteConversations.map((favName, index) => {
                    const convo = conversations.find(c => c.name === favName);
                    if (!convo) {
                      // Handle case where the conversation no longer exists
                      return (
                        <li key={index} className="favorite-conversation-item">
                          {favName} <span style={{ color: 'red' }}> (Not Found)</span>
                          <button
                            className="remove-favorite-btn"
                            onClick={(e) => {
                              e.stopPropagation();
                              removeFavoriteConversation(favName);
                            }}
                            title="Remove from Favorites"
                          >
                            ✖️
                          </button>
                        </li>
                      );
                    }
                    return (
                      <li
                        key={index}
                        className={`favorite-conversation-item ${
                          currentConversation && currentConversation.name === convo.name ? 'active' : ''
                        }`}
                        onClick={() => handleSelectConversation(convo, conversations.indexOf(convo))}
                        style={isLimitReached && conversations.indexOf(convo) >= 3 ? { pointerEvents: 'none', opacity: 0.5 } : {}}
                      >
                        {convo.name}
                        {!isLimitReached && (
                          <button
                            className="remove-favorite-btn"
                            onClick={(e) => {
                              e.stopPropagation(); // Prevent triggering the conversation load
                              removeFavoriteConversation(convo.name);
                            }}
                            title="Remove from Favorites"
                          >
                            ✖️
                          </button>
                        )}
                      </li>
                    );
                  })}
                </ul>
              ) : (
                <p>No favorite apps.</p>
              )}
            </>
          )}
        </div>

        {/* Folders Section */}
        <div className="sidebar-section folders-section">
          <button onClick={openCreateFolderModal} className="btn" disabled={isLimitReached}>
            Create New Folder
          </button>

          {/* Collapsible Header */}
          <div
            className="folders-header"
            onClick={toggleFoldersCollapse}
            style={{
              cursor: 'pointer',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginTop: '10px',
              marginBottom: '5px',
            }}
          >
            <h2>Folders</h2>
            <button className="collapse-btn" style={{ background: 'none', border: 'none', fontSize: '1.2em' }}>
              {isFoldersCollapsed ? '+' : '-'}
            </button>
          </div>

          {/* Folders List */}
          {!isFoldersCollapsed && (
            <>
              {folders.length > 0 ? (
                <>
                  <ul className="folder-list">
                    {folders.slice(0, displayedFolders).map((folder, index) => (
                      <li key={index} className="folder-item">
                        <div className="folder-header" onClick={() => toggleFolderExpansion(folder.name)}>
                          <span className="folder-name">
                            {folder.name.toLowerCase() === 'images' ? `${folder.name} 📷` : folder.name}
                          </span>
                          <span className="folder-toggle">{expandedFolders[folder.name] ? '-' : '+'}</span>
                        </div>
                        {expandedFolders[folder.name] && (
                          <div className="folder-actions">
                            <button
                              onClick={() => {
                                setCurrentUploadFolder(folder.name);
                                if (uploadFileInputRef.current) {
                                  uploadFileInputRef.current.click();
                                }
                              }}
                              className="btn upload-btn"
                              disabled={isLimitReached}
                            >
                              Upload Files
                            </button>
                            <ul className="file-list">
                              {filesInFolders[folder.name] ? (
                                filesInFolders[folder.name].length > 0 ? (
                                  filesInFolders[folder.name].map((file, idx) => (
                                    <li key={idx} className="file-item">
                                      <button onClick={() => handleSelectFile(folder.name, file)} className="btn file-btn">
                                        {file}
                                      </button>
                                    </li>
                                  ))
                                ) : (
                                  <li className="no-files">No files in this folder.</li>
                                )
                              ) : (
                                <li className="loading-files">Loading files...</li>
                              )}
                            </ul>
                          </div>
                        )}
                      </li>
                    ))}
                  </ul>
                  {/* Load More Button */}
                  {displayedFolders < folders.length && (
                    <button
                      onClick={() => setDisplayedFolders((prev) => prev + 7)}
                      className="btn load-more-btn"
                      style={{ marginTop: '5px' }}
                    >
                      Load More
                    </button>
                  )}
                </>
              ) : (
                <p>No folders available.</p>
              )}
            </>
          )}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="main-chat">
        <h1>Chat Interface</h1>

        {/* Loading Indicators */}
        {isLoadingImages && (
          <div className="loading-indicator">
            <p>Loading images...</p>
          </div>
        )}

        <div className="messages-container">
          {/* Iterate over all messages */}
          {messages.map((msg, index) => (
            <div key={index} className={`message ${msg.sender}`}>
              {msg.sender === 'user' ? (
                <div className="message-content">{msg.content}</div>
              ) : (
                // For assistant messages, do not render displayContent
                null
              )}
            </div>
          ))}

          {/* Render the iframe for the last assistant message */}
          {lastAssistantMessage && indexContent && (
            <div className={`message assistant`}>
              <iframe
                ref={iframeRef}
                title={`Rendered Output`}
                className="rendered-iframe"
                srcDoc={indexContent}
                sandbox="allow-scripts allow-same-origin allow-downloads allow-popups allow-modals allow-forms"
              ></iframe>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="input-area">
          <textarea
            id="prompt-textarea"
            placeholder="Enter your request (e.g., I want a landing page)... Type '/' to insert a file path."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={handleTextareaKeyDown}
            disabled={!currentConversation || loading || isLimitReached}
          />
          <div className="buttons">
            <button
              onClick={handleSend}
              disabled={loading || !currentConversation || isLimitReached}
              className="btn send-btn"
            >
              {loading ? 'Generating...' : 'Send'}
            </button>
            {currentConversation && (
              <>
                <button onClick={handleResetConversation} disabled={loading || isLimitReached} className="btn reset-btn">
                  Reset
                </button>
              </>
            )}
          </div>
        </div>

        {/* Create Folder Modal */}
        <Modal
          isOpen={isCreateFolderModalOpen}
          onRequestClose={closeCreateFolderModal}
          contentLabel="Create New Folder"
          className="image-modal"
          overlayClassName="image-modal-overlay"
          ariaHideApp={false}
        >
          <div className="modal-content">
            <h2>Create New Folder</h2>
            <input
              type="text"
              placeholder="Enter folder name"
              value={newFolderName}
              onChange={(e) => setNewFolderName(e.target.value)}
              className="folder-input"
              disabled={isLimitReached}
            />
            <div className="modal-buttons">
              <button onClick={handleCreateFolder} className="btn create-folder-btn" disabled={isLimitReached}>
                Create
              </button>
              <button onClick={closeCreateFolderModal} className="btn close-modal-btn">
                Cancel
              </button>
            </div>
          </div>
        </Modal>

        {/* Rename Conversation Modal */}
        <Modal
          isOpen={isRenameModalOpen}
          onRequestClose={closeRenameConversationModal}
          contentLabel="Rename Conversation"
          className="image-modal"
          overlayClassName="image-modal-overlay"
          ariaHideApp={false}
        >
          <div className="modal-content">
            <h2>Rename Conversation</h2>
            <input
              type="text"
              placeholder="Enter new conversation name"
              value={newConversationName}
              onChange={(e) => setNewConversationName(e.target.value)}
              className="folder-input"
              disabled={isLimitReached}
            />
            <div className="modal-buttons">
              <button onClick={handleRenameConversation} className="btn rename-conversation-btn" disabled={isLimitReached}>
                Rename
              </button>
              <button onClick={closeRenameConversationModal} className="btn close-modal-btn">
                Cancel
              </button>
            </div>
          </div>
        </Modal>

        {/* Hidden File Input for Per-Folder Uploads */}
        <input
          type="file"
          multiple
          ref={uploadFileInputRef}
          style={{ display: 'none' }}
          onChange={handlePerFolderFileUpload}
          disabled={isLimitReached}
        />

        {/* Error Display */}
        {error && (
          <div className="error-message">
            <p>{error}</p>
            {error === 'Request limit reached. Upgrade your account.' && (
              <button onClick={handleUpgrade} className="btn upgrade-btn">
                Upgrade Account
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatPage;
