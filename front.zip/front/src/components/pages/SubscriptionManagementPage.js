// SubscriptionManagementPage.js
import React, { useEffect, useState, useContext } from 'react';


const SubscriptionManagementPage = ({ onClose }) => {
 
  return (
    <div className="subscription-management-container">

       </div>
  );
};

export default SubscriptionManagementPage;
