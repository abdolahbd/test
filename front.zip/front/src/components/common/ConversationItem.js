// src/components/common/ConversationItem.js

import React, { useState, useRef, useEffect } from 'react';
import { IoEllipsisHorizontal } from "react-icons/io5"; // Using a horizontal ellipsis icon
import './ConversationItem.css'; // Import corresponding CSS
import { AiTwotoneStar } from 'react-icons/ai';

const ConversationItem = ({
  convo,
  isActive,
  isLimitReached,
  favoriteConversations,
  toggleFavoriteConversation,
  openRenameConversationModal,
  handleDeleteConversation,
  handleExportSingleConversation,
  handleSelectConversation,
}) => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);
  const optionsButtonRef = useRef(null);

  const handleToggleDropdown = (e) => {
    e.stopPropagation(); // Prevent triggering the parent onClick
    setIsDropdownOpen((prev) => !prev);
  };

  const handleClickOutside = (event) => {
    if (
      dropdownRef.current &&
      !dropdownRef.current.contains(event.target) &&
      optionsButtonRef.current &&
      !optionsButtonRef.current.contains(event.target)
    ) {
      setIsDropdownOpen(false);
    }
  };

  useEffect(() => {
    if (isDropdownOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    } else {
      document.removeEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isDropdownOpen]);

  return (
    <li
      className={`conversation-item ${isActive ? 'active' : ''} ${isLimitReached ? 'disabled-conversation' : ''}`}
      onClick={handleSelectConversation}
      style={isLimitReached ? { pointerEvents: 'none', opacity: 0.5 } : {}}
    >
      <span className="conversation-name" title={convo.name}>
        {convo.name}
      </span>
      
      {!isLimitReached && (
        <div className="conversation-options">
          <button
            className="save-favorite-btn"
            onClick={(e) => {
              e.stopPropagation();
              toggleFavoriteConversation(convo);
              setIsDropdownOpen(false);
            }}
            title={
              favoriteConversations.includes(convo.id)
                ? 'Remove from Favorites'
                : 'Save to Favorites'
            }
          >
            {favoriteConversations.includes(convo.id) ? <span className={`star-on ${isActive ? 'active' : ''}`}>★</span> : <span className={`star-off ${isActive ? 'active' : ''}`}>☆</span>}
            {/* {favoriteConversations.includes(convo.id) ? <AiTwotoneStar className={`star-on ${isActive ? 'active' : ''}`}/> : <AiTwotoneStar className={`star-off ${isActive ? 'active' : ''}`}/>} */}
          </button>
          <button
            className={`options-button ${isActive ? 'active' : ''}`}
            onClick={handleToggleDropdown}
            ref={optionsButtonRef}
            title="Options"
          >
            <IoEllipsisHorizontal size={20} />
          </button>

          {isDropdownOpen && (
            <div className="options-dropdown" ref={dropdownRef}>
              <button
                className="my-dropdown-item export-conversation-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  handleExportSingleConversation(convo);
                  setIsDropdownOpen(false);
                }}
                title="Export This Conversation"
              >
                📥 Export
              </button>
              <button
                className="my-dropdown-item rename-conversation-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  openRenameConversationModal(convo);
                  setIsDropdownOpen(false);
                }}
                title="Rename Conversation"
              >
                ✏️ Rename
              </button>
              <button
                className="my-dropdown-item delete-conversation-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  handleDeleteConversation(convo);
                  setIsDropdownOpen(false);
                }}
                title="Delete Conversation"
              >
                🗑️ Delete
              </button>
            </div>
          )}
        </div>
      )}
    </li>
  );
};

export default ConversationItem;
