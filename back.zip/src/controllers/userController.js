// src/controllers/userController.js

const User = require('../models/User');
const Subscription = require('../models/Subscription');
const Requests = require('../models/Requests');
const Click = require('../models/Click');
const Invoice = require('../models/Invoice');
const { Op } = require('sequelize');
const { GoogleGenerativeAI } = require("@google/generative-ai");
const { Json } = require('sequelize/lib/utils');
const Error_Request = require('../models/Error_Request');

/**
 * Retrieves the user's subscription status and current request count.
 */
exports.getUserStatus = async (req, res) => {
  try {     
    //No login , No limits
    if(req.user===undefined){
        res.json({
            isSubscribed:true,
            currentClickCount:0,
            clickLimit:10000000000,
            currentRequestCount:0,
            requestLimit:10000000000,
            isLimitReached: false,
          });
        }

    //login + limit request or subscription    
    else{
    const userId = req.user.id;
    // Check for an active subscription
    const subscription = await Subscription.findOne({
      where: { 
        user_id:userId,
        status:  { [Op.in]: ['active','incomplete'] },
      },
      order: [['createdAt', 'DESC']],
    });


    const isSubscribed = !!subscription;

 

    // Find Requests entry
    const requestEntry = await Requests.findOne({
    //   where: { userId, year: currentYear, month: currentMonth },
      where: {user_id:userId},
    });

     // Find clicks entry
     const clickEntry = await Click.findOne({
        //   where: { userId, year: currentYear, month: currentMonth },
          where: {user_id:userId},
        });

    const currentRequestCount = requestEntry ? requestEntry.requestCount : 0;
    const requestLimit = isSubscribed ? Infinity : process.env.REQUSETS_LIMIT_PAID;

    const currentClickCount = clickEntry ? clickEntry.clickCount : 0;
    const clickLimit = isSubscribed ? Infinity : process.env.CLICKS_LIMIT_PAID;




    if (process.env.LMARHALA==1) {
        res.json({
            isSubscribed:true,
            currentClickCount:0,
            clickLimit:100000000000000,
            currentRequestCount:0,
            requestLimit:1000000000000,
            isLimitReached: false,
          });
    }
    
      else if (process.env.LMARHALA==2) {
        console.log('/*/*/*/*/*/*/*/*/*/*/*/');
        console.log(currentRequestCount >= requestLimit && currentClickCount >= clickLimit);
        console.log(currentRequestCount >= requestLimit );
        console.log(currentClickCount >= clickLimit);
        console.log('/*/*/*/*/*/*/*/*/*/*/*/');
        
        res.json({
            isSubscribed,
            currentClickCount,
            clickLimit,
            currentRequestCount,
            requestLimit,
            isLimitReached: currentRequestCount >= requestLimit || currentClickCount >= clickLimit,
          });
    }


        }
    
  } catch (err) {
    console.error('Error in getUserStatus:', err);
    res.status(500).json({ error: 'Failed to retrieve user status.' });
  }
};



/**
 * Retrieves the authenticated user's API keys for supported services.
 */
// backend/controllers/apiController.js


// Define supported services and their key mappings
const supportedServices = ['OpenAI', 'Claude', 'Gemini', 'Mistralai'];

// const serviceKeyMap = {
//   OpenAI: 'openaiApiKey',
//   Claude: 'claudeApiKey',
//   Gemini: 'geminiApiKey',
//   Mistralai: 'mistralaiApiKey',
// };


const serviceKeyMap = JSON.parse(process.env.SERVICE_KEY_MAP);

exports.getApiKeyStatus = async (req, res) => { 
  try {
    const userId = req.user.id;
    const user = await User.findByPk(userId, { attributes: ['apiKey'] });
    
    if (!user) {
      return res.status(404).json({ error: 'User not found.' });
    }
console.log(user);

    const apiKeys = JSON.parse(user.apiKey) || {};
    
    console.log('serviceKeyMap:', serviceKeyMap);
    
    const apiKeyStatus = {};
    
    // Using Object.entries for iteration
    Object.entries(serviceKeyMap).forEach(([service, key]) => {
      apiKeyStatus[key] = !!apiKeys[key]; // true if key exists, false otherwise
      console.log(`Service: ${service}, Key: ${key}, Status: ${apiKeyStatus[key]}`);
    });

    console.log("apiKeyStatus:", apiKeyStatus);

    res.json(apiKeyStatus); // e.g., { openaiApiKey: true, geminiApiKey: false, ... }
  } catch (err) {
    console.error('Error in getApiKeyStatus:', err);
    res.status(500).json({ error: 'Failed to retrieve API key status.' });
  }
};



/**
 * Sets or updates the authenticated user's API key for a specific service.
 */
exports.setApiKey = async (req, res) => {
  try {
    const userId = req.user.id;
    const { service, apiKey } = req.body;

    console.log('{ service, apiKey }');
    console.log({ service, apiKey });
    console.log('{ service, apiKey }');

    if (!service) {
      return res.status(400).json({ error: 'Invalid or unsupported service.' });
    }

    if (!apiKey || typeof apiKey !== 'string') {
      return res.status(400).json({ error: 'Invalid API key.' });
    }

    // Validate the API key format here (optional)

    // If the service is Gemini, validate the API key
    if (service.toLowerCase() === 'gemini') {
      const genAI = new GoogleGenerativeAI(apiKey);
      const model = genAI.getGenerativeModel({
        model: "gemini-2.0-flash-thinking-exp-1219",
      });

      const generationConfig = {
        temperature: 1,
        topP: 0.95,
        topK: 64,
        maxOutputTokens: 5, // Reduced for a small test
        responseMimeType: "text/plain",
      };

      try {
        const chatSession = model.startChat({
          generationConfig,
          history: [],
        });

        // Send a minimal test message
        const testMessage = "Test";
        const result = await chatSession.sendMessage(testMessage);

        // Check if the response is valid
        if (!result || !result.response || !result.response.text()) {
          return res.status(400).json({ error: 'Invalid Gemini API key.' });
        }

        console.log('Gemini API key validated successfully.');
      } catch (validationError) {
        
        

        

        try {
          await Error_Request.create({
            user_id: userId,
            error:'Modal Api Key : '+JSON.stringify(validationError.errorDetails),
          });
          console.log(`Logged error for User ID ${req.user.id}`);
        } catch (logError) {
          console.error('Failed to log error for authenticated user:', logError);
        }



        if (JSON.stringify(validationError.errorDetails).includes('API_KEY_INVALID')) {
          return res.status(400).json({ error: 'The API key you entered is incorrect. Please verify your key and enter a valid Gemini API key.' });
        }


        console.error('Gemini API key validation failed');
        return res.status(400).json({ error: 'Failed to validate Gemini API key, ensure that your API key is valid and functioning correctly.' });
      }
    }

    // Fetch the user
    const user = await User.findByPk(userId);

    let apiKeys = {};

    if (user.apiKey) {
      try {
        apiKeys = JSON.parse(user.apiKey);
      } catch (err) {
        console.error('Error parsing existing apiKey JSON:', err);
        // Initialize to empty object if parsing fails
        apiKeys = {};
      }
    }

    // Update the key for the specified service
    apiKeys[`${service.toLowerCase()}ApiKey`] = apiKey;

    // Serialize back to JSON
    const updatedApiKey = JSON.stringify(apiKeys);

    // Update the user
    await user.update({ apiKey: updatedApiKey });
    console.log('{ service, apiKey }----------------');
    console.log(apiKeys);
    console.log(apiKey);
    console.log(service);
    console.log(`${service.toLowerCase()}ApiKey`);
    console.log(apiKeys[`${service.toLowerCase()}ApiKey`]);
    console.log('{ service, apiKey }----------------');

    res.json({ message: `${service} API key saved successfully.` });
  } catch (err) {
    console.error('Error in setApiKey:', err);
    res.status(500).json({ error: 'Failed to set API key.' });
  }
};



exports.getUserInvoices = async (req, res) => {
  try {
    const userId = req.user.id; // Assuming you have req.user set by your auth middleware
    const invoices = await Invoice.findAll({
      where: { user_id:userId },
      order: [['invoiceDate', 'DESC']] // Sort by date descending
    });

    res.json(invoices);
  } catch (error) {
    console.error('Error retrieving user invoices:', error);
    res.status(500).json({ error: 'Failed to retrieve invoices.' });
  }
};
