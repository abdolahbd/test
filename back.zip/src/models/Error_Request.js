// src/models/Error_Request.js

const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./User');

const Error_Request = sequelize.define('Error_Request', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  user_id: { // Foreign key to User
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: User,
      key: 'id',
    },
    onDelete: 'CASCADE',
  },
  error: {
    type: DataTypes.TEXT, // Store full error stack or message
    allowNull: false,
  },
  createdAt: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW,
  },
}, {
  tableName: 'error_requests',
  timestamps: false, // If you only want `createdAt`, set `timestamps` to false
});

// Associations
Error_Request.belongsTo(User, { foreignKey: 'user_id' });

module.exports = Error_Request;
