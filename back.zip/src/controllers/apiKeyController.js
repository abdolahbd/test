// src/controllers/apiKeyController.js

const IP_ApiKey = require('../models/IP_ApiKey');
const geoip = require('geoip-lite');

/**
 * Helper function to extract the client's IP address.
 * Considers possible proxy headers.
 */
const getClientIP = (req) => {
  const forwarded = req.headers['x-forwarded-for'];
  let ip;

  if (forwarded) {
    // 'x-forwarded-for' may return multiple IPs: "client IP, proxy 1 IP, proxy 2 IP"
    const forwardedIps = forwarded.split(',').map(ip => ip.trim());
    ip = forwardedIps[0];
  } else {
    ip = req.connection.remoteAddress || req.socket.remoteAddress || req.ip;
  }

  // Handle IPv6 addresses that are IPv4 mapped (e.g., ::ffff:127.0.0.1)
  const cleanIp = ip.startsWith('::ffff:') ? ip.substring(7) : ip;

  // Lookup geolocation data (optional)
  const geo = geoip.lookup(cleanIp);
  const country = geo ? geo.country : 'Unknown';

  return { ip: cleanIp, country };
};

/**
 * Save API key statuses for unauthenticated users.
 * Expects a JSON object in the format: { "openai": true, "gemini": false, ... }
 */
const saveApiKeys = async (req, res) => {
  try {
    const { api_keys } = req.body;

    // Input validation
    if (!api_keys || typeof api_keys !== 'object') {
      return res.status(400).json({ error: 'api_keys is required and must be an object.' });
    }

    // Validate that all values in api_keys are boolean
    for (const [key, value] of Object.entries(api_keys)) {
      if (typeof value !== 'boolean') {
        return res.status(400).json({ error: `api_keys.${key} must be a boolean.` });
      }
    }

    // Extract client IP and country
    const { ip, country } = getClientIP(req);

    // Create the JSON string to store in the 'ip' column
    const ipData = JSON.stringify({ ip, country });

    // Find existing record for the same IP and country
    let ipApiKey = await IP_ApiKey.findOne({ where: { ip: ipData } });

    if (ipApiKey) {
      // Update existing record
      ipApiKey.api_keys = api_keys;
      ipApiKey.created_at = new Date(); // Update timestamp if needed
      await ipApiKey.save();
      console.log(`API keys updated for IP ${ip}:`, api_keys);
    } else {
      // Create new record
      ipApiKey = await IP_ApiKey.create({
        ip: ipData, // Store IP and country as JSON string
        api_keys,
        created_at: new Date(), // Set creation timestamp
      });
      console.log(`API keys saved for IP ${ip}:`, api_keys);
    }

    return res.status(200).json({
      message: 'API keys saved successfully.',
      data: ipApiKey,
    });
  } catch (error) {
    console.error('Error saving API keys:', error);
    return res.status(500).json({ error: 'Internal server error.' });
  }
};

module.exports = {
  saveApiKeys
};
