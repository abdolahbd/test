// src/components/pages/PaymentHistoryPage.js
import React, { useEffect, useState, useContext } from 'react';
import { AuthContext } from '../../contexts/AuthContext';
import api from '../../services/apiService';

function PaymentHistoryPage() {
  const { user } = useContext(AuthContext);
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchInvoices = async () => {
      try {
        const response = await api.get('/user/invoices'); 
        console.log(response.data);
        setInvoices(response.data);
      } catch (error) {
        console.error('Error fetching invoices:', error);
      } finally {
        setLoading(false);
      }
    };

    if (user) {
      fetchInvoices();
    }
  }, [user]);

  if (loading) {
    return <div>Loading invoices...</div>;
  }

  return (
    <div className="payment-history-page">
      <h2>Payment History</h2>
      {invoices.length === 0 ? (
        <p>No invoices found.</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Invoice Date</th>
              {/* Removed Amount Due header */}
              <th>Amount Paid</th>
              <th>Status</th>
              <th>PDF</th>
            </tr>
          </thead>
          <tbody>
            {invoices.map((invoice) => (
              <tr key={invoice.id}>
                <td>{new Date(invoice.invoiceDate).toLocaleDateString('en-GB')}</td>
                {/* Removed Amount Due cell */}
                <td>${invoice.amountPaid.toFixed(2)}</td>
                <td>{invoice.status}</td>
                <td>
                  {invoice.pdfUrl ? (
                    <a href={invoice.pdfUrl} target="_blank" rel="noopener noreferrer">
                      Download PDF
                    </a>
                  ) : (
                    'No PDF available'
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default PaymentHistoryPage;
