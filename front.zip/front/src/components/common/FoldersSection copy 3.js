// src/components/FoldersSection/FoldersSection.js

import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import './FoldersSection.css';
import { IoIosArrowDropdown, IoIosArrowDropup } from "react-icons/io";
import { FaFileAlt } from "react-icons/fa";

/**
 * Tooltip Component
 */
const Tooltip = ({ visible, content, position }) => {
  if (!visible) return null;

  const style = {
    top: position.y + 10, // small offset
    left: position.x + 10,
  };

  return (
    <div className={`tool-tip ${visible ? 'visible' : ''}`} style={style}>
      {content}
    </div>
  );
};

Tooltip.propTypes = {
  visible: PropTypes.bool.isRequired,
  content: PropTypes.string.isRequired,
  position: PropTypes.shape({
    x: PropTypes.number,
    y: PropTypes.number,
  }).isRequired,
};

const FoldersSection = ({
  folders,
  expandedFolders,
  toggleFolderExpansion,
  filesInFolders,
  handleSelectFile,
  handleDeleteFile,
  handleDeleteFolder,
  handleUploadFiles,
  openCreateFolderModal,
  isLimitReached,
}) => {
  // State for collapsing the entire folders section
  const [isFoldersCollapsed, setIsFoldersCollapsed] = useState(false);

  // State for tooltip
  const [tooltip, setTooltip] = useState({
    visible: false,
    content: '',
    position: { x: 0, y: 0 },
  });

  // State for tracking how many folders are displayed
  const [displayedFolders, setDisplayedFolders] = useState(7);

  // State for tracking how many files are displayed per folder
  const [displayedFiles, setDisplayedFiles] = useState({});

  // Initialize displayedFiles when folders change
  useEffect(() => {
    const initialDisplayedFiles = {};
    folders.forEach(folder => {
      // If already have a value, keep it; else initialize to 7
      initialDisplayedFiles[folder.name] = displayedFiles[folder.name] || 7;
    });
    setDisplayedFiles(initialDisplayedFiles);
  }, [folders]);

  const toggleFoldersCollapse = () => {
    setIsFoldersCollapsed(!isFoldersCollapsed);
  };

  // Tooltip handlers for files
  const handleFileMouseEnter = (e, fileName) => {
    setTooltip({
      visible: true,
      content: fileName.replace(/_/g, ' '),
      position: { x: e.clientX, y: e.clientY },
    });
  };

  // Tooltip handlers for folders
  const handleFolderMouseEnter = (e, folderName) => {
    setTooltip({
      visible: true,
      content: folderName,
      position: { x: e.clientX, y: e.clientY },
    });
  };

  const handleMouseMove = (e) => {
    if (tooltip.visible) {
      setTooltip((prev) => ({
        ...prev,
        position: { x: e.clientX, y: e.clientY },
      }));
    }
  };

  const handleMouseLeave = () => {
    setTooltip({
      visible: false,
      content: '',
      position: { x: 0, y: 0 },
    });
  };

  // Handler for loading more folders
  const handleLoadMoreFolders = () => {
    setDisplayedFolders((prev) => prev + 7);
  };

  // Handler for loading more files in a specific folder
  const handleLoadMoreFiles = (folderName) => {
    setDisplayedFiles((prev) => ({
      ...prev,
      [folderName]: prev[folderName] + 7,
    }));
  };

  return (
    <div className="folders-section" onMouseMove={handleMouseMove}>
      {/* Header */}
      <div className="folders-header" onClick={toggleFoldersCollapse}>
        <h2 className='section-collapse'>
          <div className="left-section">
            <span>📁 Folders</span>
          </div>
          <div className="right-section">
            <button
              onClick={(e) => {
                e.stopPropagation(); // avoid collapsing when clicking "+"
                openCreateFolderModal();
              }}
              className="create-folder-btn"
              disabled={isLimitReached}
              aria-label="Create New Folder"
            >
              ➕
            </button>
            <span
              className='section-collapse-icon'
              onClick={(e) => {
                e.stopPropagation(); // avoid collapsing when clicking arrow
                toggleFoldersCollapse();
              }}
              aria-label={isFoldersCollapsed ? "Expand Folders" : "Collapse Folders"}
            >
              {isFoldersCollapsed ? <IoIosArrowDropdown /> : <IoIosArrowDropup />}
            </span>
          </div>
        </h2>
      </div>

      {/* Smooth expand/collapse for the ENTIRE folder list */}
      <div className={`folders-container ${isFoldersCollapsed ? '' : 'open'}`}>
        {folders.length > 0 ? (
          <>
            <ul className="folder-list">
              {folders.slice(0, displayedFolders).map((folder, index) => {
                const isOpen = expandedFolders[folder.name] || false;
                const files = filesInFolders[folder.name] || [];
                const currentDisplayedFiles = displayedFiles[folder.name] || 7;
                const hasMoreFiles = currentDisplayedFiles < files.length;

                return (
                  <li key={index} className="folder-item">
                    {/* Clickable folder header */}
                    <div
                      className="folder-header"
                      onClick={() => toggleFolderExpansion(folder.name)}
                    >
                      <div className="folder-info">
                        <IoIosArrowDropdown
                          className={`toggle-icon ${isOpen ? 'expanded' : 'collapsed'}`}
                        />
                        <span
                          className="folder-name"
                          onMouseEnter={(e) => handleFolderMouseEnter(e, folder.name)}
                          onMouseMove={handleMouseMove}
                          onMouseLeave={handleMouseLeave}
                        >
                          {folder.name}
                        </span>
                      </div>

                      {/* Action Buttons: Upload + Delete */}
                      <div className="folder-actions-buttons">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleUploadFiles(folder.name);
                          }}
                          className="upload-btn"
                          disabled={isLimitReached}
                          title="Upload Files"
                          aria-label={`Upload files to ${folder.name}`}
                        >
                          ➕
                        </button>
                        <button
                          className="delete-folder-btn"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteFolder(folder.name);
                          }}
                          title="Delete Folder"
                          disabled={isLimitReached}
                          aria-label={`Delete folder ${folder.name}`}
                        >
                          🗑️
                        </button>
                      </div>
                    </div>

                    {/* 
                      Smooth expand/collapse for FILES inside each folder.
                      Always render the container, and toggle ".open".
                    */}
                    <div className={`folder-actions ${isOpen ? 'open' : ''}`}>
                      {/* We *always* render the file list so it can transition */}
                      <ul className="file-list">
                        {files.length > 0 ? (
                          files.slice(0, currentDisplayedFiles).map((file, idx) => (
                            <li key={idx} className="file-item">
                              <div className="file-container">
                                <button
                                  onClick={() => handleSelectFile(folder.name, file)}
                                  className="file-btn"
                                  onMouseEnter={(e) => handleFileMouseEnter(e, file)}
                                  onMouseLeave={handleMouseLeave}
                                  aria-label={`Select ${file.replace(/_/g, ' ')}`}
                                >
                                  <FaFileAlt className="file-icon" />
                                  <span className="file-name">
                                    {file.replace(/_/g, ' ')}
                                  </span>
                                </button>
                                <button
                                  className="delete-file-btn"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleDeleteFile(folder.name, file);
                                  }}
                                  title="Delete File"
                                  disabled={isLimitReached}
                                  aria-label={`Delete ${file.replace(/_/g, ' ')}`}
                                >
                                  🗑️
                                </button>
                              </div>
                            </li>
                          ))
                        ) : (
                          <li className="no-files">No files in this folder.</li>
                        )}
                      </ul>

                      {/* Load More Files Button */}
                      {hasMoreFiles && (
                        <button
                          onClick={() => handleLoadMoreFiles(folder.name)}
                          className="btn load-more-files-btn"
                          aria-label={`Load more files in ${folder.name}`}
                        >
                          Load More Files
                        </button>
                      )}
                    </div>
                  </li>
                );
              })}
            </ul>

            {/* Load More Folders Button */}
            {displayedFolders < folders.length && (
              <button
                onClick={handleLoadMoreFolders}
                className="btn load-more-btn"
                aria-label="Load more folders"
              >
                Load More Folders
              </button>
            )}
          </>
        ) : (
          <p className="no-folders-message">No folders available.</p>
        )}
      </div>

      {/* Tooltip */}
      <Tooltip
        visible={tooltip.visible}
        content={tooltip.content}
        position={tooltip.position}
      />
    </div>
  );
};

FoldersSection.propTypes = {
  folders: PropTypes.arrayOf(
    PropTypes.shape({
      name: PropTypes.string.isRequired,
      lastModified: PropTypes.number.isRequired,
    })
  ).isRequired,
  expandedFolders: PropTypes.objectOf(PropTypes.bool).isRequired,
  toggleFolderExpansion: PropTypes.func.isRequired,
  filesInFolders: PropTypes.objectOf(PropTypes.arrayOf(PropTypes.string)).isRequired,
  handleSelectFile: PropTypes.func.isRequired,
  handleDeleteFile: PropTypes.func.isRequired,
  handleDeleteFolder: PropTypes.func.isRequired,
  handleUploadFiles: PropTypes.func.isRequired,
  openCreateFolderModal: PropTypes.func.isRequired,
  isLimitReached: PropTypes.bool.isRequired,
};

export default FoldersSection;
