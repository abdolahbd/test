// src/controllers/reviewsController.js

const Review = require('../models/Review');
const IP_Review = require('../models/IP_Review');
const User = require('../models/User');
const geoip = require('geoip-lite');

/**
 * Helper function to extract the client's IP address.
 * This considers possible proxy headers.
 */
const getClientIP  = (req) => {
  // Extract the IP address
  const forwarded = req.headers['x-forwarded-for'];
  let ip;

  if (forwarded) {
    // 'x-forwarded-for' may return multiple IP addresses in the format: "client IP, proxy 1 IP, proxy 2 IP"
    const forwardedIps = forwarded.split(',').map(ip => ip.trim());
    ip = forwardedIps[0];
  } else {
    ip = req.connection.remoteAddress || req.socket.remoteAddress || req.ip;
  }

  // Handle IPv6 addresses that are IPv4 mapped (e.g., ::ffff:127.0.0.1)
  const cleanIp = ip.startsWith('::ffff:') ? ip.substring(7) : ip;

  // Lookup the geolocation data
  const geo = geoip.lookup(cleanIp);

  // Extract the country code or set to 'Unknown' if not found
  const country = geo ? geo.country : 'Unknown';

  return JSON.stringify({ ip: cleanIp, country });
};

/**
 * Handles submitting a review.
 * For authenticated users, appends the new text to the existing text array.
 * For unauthenticated users, updates existing review based on IP address by appending the text.
 */
const submitReview = async (req, res) => {
  try {
    const { name, stars, text } = req.body;


    if (stars !== undefined) {
      if (typeof stars !== 'number' || stars < 1 || stars > 5) {
        return res.status(400).json({ error: 'Stars must be a number between 1 and 5.' });
      }
    }

    if (req.user) {
      // Authenticated user
      const userId = req.user.id;
      console.log(`Authenticated User ID: ${userId}`);

      // Check if user exists
      const user = await User.findByPk(userId);
      if (!user) {
        return res.status(404).json({ error: 'User not found.' });
      }

      // Find existing review by this user
      let review = await Review.findOne({ where: { user_id: userId } });

      if (review) {
        // Parse existing text as JSON array
        let existingTexts;
        try {
          existingTexts = JSON.parse(review.text);
          if (!Array.isArray(existingTexts)) {
            existingTexts = [];
          }
        } catch (e) {
          existingTexts = [];
        }

        // Append the new text
        existingTexts.push(text);

        // Update the 'text' field with the new array
        review.text = JSON.stringify(existingTexts);

        // Optionally update timestamp if you have one
        review.timestamp = new Date();

        await review.save();

        console.log(`Review updated for User ID ${userId}:`, review.toJSON());

        return res.status(200).json({
          message: 'Review updated successfully.',
          data: review,
        });
      } else {
        // Create a new Review with text as an array
        review = await Review.create({
          user_id: userId,
          name: name || user.name, // Use provided name or default to user's name
          stars: stars || 5, // Default stars if not provided
          text: JSON.stringify([text]), // Initialize text as an array
        });

        console.log(`Review created for User ID ${userId}:`, review.toJSON());

        return res.status(201).json({
          message: 'Review submitted successfully.',
          data: review,
        });
      }
    } else {
      // Unauthenticated user, track by IP
      const ipAddress = getClientIP(req);
      console.log(`Unauthenticated User IP: ${ipAddress}`);

      // Check if a review already exists for this IP
      let ipReview = await IP_Review.findOne({ where: { ipAddress: ipAddress } });

      if (ipReview) {
        // Parse existing text as JSON array
        let existingTexts;
        try {
          existingTexts = JSON.parse(ipReview.text);
          if (!Array.isArray(existingTexts)) {
            existingTexts = [];
          }
        } catch (e) {
          existingTexts = [];
        }

        // Append the new text
        existingTexts.push(text);

        // Update the 'text' field with the new array
        ipReview.text = JSON.stringify(existingTexts);

        // Optionally update timestamp if you have one
        ipReview.timestamp = new Date();

        await ipReview.save();

        console.log(`Review updated for IP ${ipAddress}:`, ipReview.toJSON());

        return res.status(200).json({
          message: 'Review updated successfully.',
          data: ipReview,
        });
      } else {
        // Create a new IP_Review with text as an array
        ipReview = await IP_Review.create({
          ipAddress: ipAddress,
          name: name || 'Anonymous', // Default name if not provided
          stars: stars || 5, // Default stars if not provided
          text: JSON.stringify([text]), // Initialize text as an array
        });

        console.log(`Review created for IP ${ipAddress}:`, ipReview.toJSON());

        return res.status(201).json({
          message: 'Review submitted successfully.',
          data: ipReview,
        });
      }
    }
  } catch (error) {
    console.error('Error submitting review:', error);
    // Handle unique constraint errors for IP reviews if any
    if (error.name === 'SequelizeUniqueConstraintError') {
      return res.status(409).json({ error: 'A review from this IP address already exists.' });
    }
    return res.status(500).json({ error: 'Internal server error.' });
  }
};

/**
 * Retrieves all reviews.
 * Combines reviews from authenticated and unauthenticated users.
 */
const getAllReviews = async (req, res) => {
  try {
    // Fetch all authenticated user reviews
    const authenticatedReviews = await Review.findAll({
      include: [{
        model: User,
        attributes: ['id', 'name'], // Include user details if needed
      }],
      order: [['timestamp', 'DESC']],
    });

    // Fetch all unauthenticated user reviews
    const ipReviews = await IP_Review.findAll({
      order: [['timestamp', 'DESC']],
    });

    // Combine both
    const allReviews = [
      ...authenticatedReviews.map(review => ({
        id: review.id,
        user_id: review.user_id,
        name: review.name,
        stars: review.stars,
        text: JSON.parse(review.text), // Parse the JSON array
        timestamp: review.timestamp,
        authenticated: true,
      })),
      ...ipReviews.map(review => ({
        id: review.id,
        ipAddress: review.ipAddress,
        name: review.name,
        stars: review.stars,
        text: JSON.parse(review.text), // Parse the JSON array
        timestamp: review.timestamp,
        authenticated: false,
      })),
    ];

    return res.status(200).json({
      data: allReviews,
    });
  } catch (error) {
    console.error('Error fetching reviews:', error);
    return res.status(500).json({ error: 'Internal server error.' });
  }
};

/**
 * (Optional) Retrieve all reviews for the authenticated user or by IP for unauthenticated users.
 */
const getUserReviews = async (req, res) => {
  try {
    if (req.user) {
      // Authenticated user
      const userId = req.user.id;

      const userReviews = await Review.findAll({
        where: { user_id: userId },
        include: [{
          model: User,
          attributes: ['id', 'name'],
        }],
        order: [['timestamp', 'DESC']],
      });

      // Parse the text field as JSON
      const parsedUserReviews = userReviews.map(review => ({
        ...review.toJSON(),
        text: JSON.parse(review.text),
      }));

      return res.status(200).json({
        data: parsedUserReviews,
      });
    } else {
      // Unauthenticated user, fetch by IP
      const ipAddress = getClientIP(req);

      const ipReviews = await IP_Review.findAll({
        where: { ipAddress: ipAddress },
        order: [['timestamp', 'DESC']],
      });

      // Parse the text field as JSON
      const parsedIpReviews = ipReviews.map(review => ({
        ...review.toJSON(),
        text: JSON.parse(review.text),
      }));

      return res.status(200).json({
        data: parsedIpReviews,
      });
    }
  } catch (error) {
    console.error('Error fetching user reviews:', error);
    return res.status(500).json({ error: 'Internal server error.' });
  }
};

module.exports = {
  submitReview,
  getAllReviews,
  getUserReviews, // Optional
};
