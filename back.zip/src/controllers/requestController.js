// src/controllers/requestController.js

const { Op } = require('sequelize');
const User = require('../models/User');
const Subscription = require('../models/Subscription');
const Requests = require('../models/Requests');
const IP_Request = require('../models/IP_Request');
const Prompt = require('../models/Prompt'); // Import Prompt model
const IP_Prompt = require('../models/IP_Prompt'); // Import IP_Prompt model
const { generateCode_openAIService } = require('../services/openAIService');
const { generateCode_geminiService } = require('../services/geminiService');
const Click = require('../models/Click');
const Error_Request = require('../models/Error_Request');
const IP_Error_Request = require('../models/IP_Error_Request');
const geoip = require('geoip-lite');


const serviceKeyMap = JSON.parse(process.env.SERVICE_KEY_MAP);

/**
 * Retrieves the client's IP address from the request.
 * If your app is behind a proxy like Nginx, ensure that 'trust proxy' is set in Express.
 *
 * @param {Object} req - The Express request object.
 * @returns {string} - The client's IP address.
 */
const getClientIP  = (req) => {
  // Extract the IP address
  const forwarded = req.headers['x-forwarded-for'];
  let ip;

  if (forwarded) {
    // 'x-forwarded-for' may return multiple IP addresses in the format: "client IP, proxy 1 IP, proxy 2 IP"
    const forwardedIps = forwarded.split(',').map(ip => ip.trim());
    ip = forwardedIps[0];
  } else {
    ip = req.connection.remoteAddress || req.socket.remoteAddress || req.ip;
  }

  // Handle IPv6 addresses that are IPv4 mapped (e.g., ::ffff:127.0.0.1)
  const cleanIp = ip.startsWith('::ffff:') ? ip.substring(7) : ip;

  // Lookup the geolocation data
  const geo = geoip.lookup(cleanIp);

  // Extract the country code or set to 'Unknown' if not found
  const country = geo ? geo.country : 'Unknown';

  return JSON.stringify({ ip: cleanIp, country });
};




/**
 * Handles incoming requests from both authenticated and non-authenticated users.
 * Logs errors into respective tables based on the user's authentication status.
 *
 * @param {Object} req - The Express request object.
 * @param {Object} res - The Express response object.
 */
exports.handleRequest = async (req, res) => {
  try {
    const { prompt, messages, conversationName } = req.body;
    const k=req.body.apiKeys;
    // Validate prompt
    if (!prompt || typeof prompt !== 'string' || prompt.trim().length === 0) {
      return res.status(400).json({ error: 'Invalid prompt provided.' });
    }

    console.log('--------------------------------');
    // console.log('k:', k, 'Prompt:', prompt, 'Messages:', messages, 'Conversation Name:', conversationName);
    // console.log('req body:', req.body);
    console.log('--------------------------------');

    // No login, No limits
    if (!req.user) {
      const ipAddress = getClientIP(req);
      console.log(`IP Address: ${ipAddress}`);

      // Find or create IP_Request entry
      const [ipRequestEntry, created] = await IP_Request.findOrCreate({
        where: { ipAddress },
        defaults: { requestCount: 0 },
      });

console.log('-------------**-');
// console.log(req.body);
console.log(k);






var apiKeys=req.body.apiKeys;
var service=req.body.service;
var serviceApiKey=serviceKeyMap[service];

console.log('*/*/*/*/*/*/*/*/*/*/*/');
console.log(service);
console.log(apiKeys[serviceApiKey]);
console.log('*/*/*/*/*/*/*/*/*/*/*/');

var code;

switch (service) {
case 'OpenAI':
code = await generateCode_openAIService(apiKeys[serviceApiKey], prompt, messages, conversationName);
break;
case 'Gemini':
code = await generateCode_geminiService(apiKeys[serviceApiKey], prompt, messages, conversationName);
break;
case 'Mistralai':
code = await generateCode_geminiService(apiKeys[serviceApiKey], prompt, messages, conversationName);
break;
case 'Claude':
code = await generateCode_geminiService(apiKeys[serviceApiKey], prompt, messages, conversationName);
break;
default:
break;
}



      // // Generate code using OpenAI with limited context
      // const code = await generateCode_geminiService(k.geminiApiKey, prompt, messages, conversationName);

      // Increment request count for the IP
      ipRequestEntry.requestCount += 1;
      await ipRequestEntry.save();

      console.log(`Updated Anonymous Request Count for IP ${ipAddress}: ${ipRequestEntry.requestCount}`);

      // **Insert into ip_prompts table**
      await IP_Prompt.create({
        ip_address: ipAddress,
        conversation_name: conversationName,
        prompt,
        created_at: new Date(),
      });

      console.log(`Stored prompt for IP ${ipAddress}`);

      res.json({ code });
    }
    // Logged-in user + limit request or subscription
    else {
      const userId = req.user.id;


console.log('UUUUUUUUUUUUUUUUUUUUUUUUUUUUU');
console.log(userId);
console.log('UUUUUUUUUUUUUUUUUUUUUUUUUUUUU');



      const user = await User.findByPk(userId);
      if (!user) return res.status(404).json({ error: 'User not found' });

      // Check for an active subscription
      const subscription = await Subscription.findOne({
        where: {
          user_id:userId,
          status: { [Op.in]: ['active','incomplete'] },
        },
        order: [['createdAt', 'DESC']],
      });

console.log('----------- subscription------------------');
console.log(subscription);
console.log('----------- subscription------------------');


      const isSubscribed = !!subscription;

      // Find or create Requests entry for the user
      const [requestEntry] = await Requests.findOrCreate({
        where: { user_id:userId },
        defaults: { requestCount: 0 },
      });

      // Find or create Clicks entry
      const [clickEntry] = await Click.findOrCreate({
        where: { user_id: userId },
        defaults: { clickCount: 0, timestamp: new Date() },
      });

      let RequestLimitLmarhala;
      let ClickLimitLmarhala;

      if (process.env.LMARHALA == 1) {
        const no_limit=1000000000000000000;
        RequestLimitLmarhala = no_limit;
        ClickLimitLmarhala = no_limit;
      } else if (process.env.LMARHALA == 2) {
      console.log(123.555);
      
        RequestLimitLmarhala = parseInt(process.env.REQUSETS_LIMIT_PAID, 10) || 1000; // Fallback to 1000 if not set
        ClickLimitLmarhala = parseInt(process.env.CLICKS_LIMIT_PAID, 10) || 1000; // Fallback to 1000 if not set
      } else {
        // Default limits if LMARHALA is not 1 or 2
        RequestLimitLmarhala = 100;
        ClickLimitLmarhala = 100;
      }

      // Determine request limit
      const requestLimit = isSubscribed ? Infinity : RequestLimitLmarhala;
      const clickLimit = isSubscribed ? Infinity : ClickLimitLmarhala;

      console.log(`Subscription Status: ${isSubscribed}`);
      console.log(`User Click Count: ${clickEntry.clickCount}, Click Limit: ${clickLimit}`);
      console.log(`User Request Count: ${requestEntry.requestCount}, Request Limit: ${requestLimit}`);

      if (requestEntry.requestCount >= requestLimit || clickEntry.clickCount >= clickLimit) {
        return res.status(403).json({ error: 'Request limit reached. Upgrade your account.' });
      }


      var apiKeys=JSON.parse(user.apiKey);
      var service=req.body.service;
      var serviceApiKey=serviceKeyMap[service];

      console.log('*/*/*/*/*/*/*/*/*/*/*/');
console.log(service);
console.log(apiKeys[serviceApiKey]);
console.log('*/*/*/*/*/*/*/*/*/*/*/');

console.log('reeeeeq :',req.body);


var code;

switch (service) {
  case 'OpenAI':
     code = await generateCode_openAIService(apiKeys[serviceApiKey], prompt, messages, conversationName);
      break;
  case 'Gemini':
     code = await generateCode_geminiService(apiKeys[serviceApiKey], prompt, messages, conversationName);
      break;
  case 'Mistralai':
     code = await generateCode_geminiService(apiKeys[serviceApiKey], prompt, messages, conversationName);
      break;
  case 'Claude':
     code = await generateCode_geminiService(apiKeys[serviceApiKey], prompt, messages, conversationName);
      break;
  default:
      break;
}
      
      const clientIP = getClientIP(req);
      // Increment request count
      requestEntry.requestCount += 1;
      requestEntry.ip = clientIP;
      await requestEntry.save();

      console.log(`Updated Request Count for User ID ${userId}: ${requestEntry.requestCount}`);
      console.log(`Conversation Name: ${conversationName}`);

      // **Insert into prompts table**
      await Prompt.create({
        user_id: userId,
        conversation_name: conversationName,
        prompt,
        created_at: new Date(),
      });

      console.log(`Stored prompt for User ID ${userId}`);

      res.json({ code });
    }
  } catch (err) {
    console.error('Error in handleRequest:', err);




    // Initialize error details
    let errorDetails = {
      error: err.stack || err.message || 'Unknown error',
      createdAt: new Date(),
    };

    // Extract error code if available
    let errorCode = 'request_failed'; // Default error code

    console.log(err);
    

    if (
      err.originalError &&
      err.originalError.response &&
      err.originalError.response.data &&
      err.originalError.response.data.error &&
      err.originalError.response.data.error.code
    ) {
      errorCode = err.originalError.response.data.error.code;
      errorDetails.error = err.originalError.response.data.error.message || errorCode;
    } else if (err.code) {
      errorCode = err.code;
    }
    else if (JSON.stringify(err).includes("API_KEY_INVALID") && service=='Gemini' ) {
            
      errorCode = "API_KEY_INVALID";
    }
    
    // Map specific error codes to user-friendly messages
    const errorMessages = {
      model_not_found:
        'Request failed. Please try again. If the problem persists, please verify your OpenAI API key in your OpenAI account.',
      invalid_api_key: 'The API key you entered is incorrect. Please verify your key and enter a valid OpenAI API key.',
      API_KEY_INVALID: 'The API key you entered is incorrect. Please verify your key and enter a valid Gemini API key.',
    };

    // Determine the message to send based on the error code
    const errorMessage = errorMessages[errorCode] || 'Request failed. Please try again.';

    // Determine if the user is authenticated
    if (req.user && req.user.id) {
      // Authenticated user: log to Error_Request
      try {
        await Error_Request.create({
          user_id: req.user.id,
          ...errorDetails,
        });
        console.log(`Logged error for User ID ${req.user.id}`);
      } catch (logError) {
        console.error('Failed to log error for authenticated user:', logError);
        // Optionally, handle logging failure (e.g., send alert)
      }
    } else {
      // Non-authenticated user: log to IP_Error_Request
      const ipAddress = getClientIP(req) || 'Unknown IP';
      try {
        await IP_Error_Request.create({
          ipAddress,
          ...errorDetails,
        });
        console.log(`Logged error for IP ${ipAddress}`);
      } catch (logError) {
        console.error('Failed to log error for IP:', logError);
        // Optionally, handle logging failure
      }
    }

    // Send the specific error message to the frontend
    res.status(500).json({
      error: errorMessage, // Send the mapped error message
    });
  }
};
