// models/IP_Review.js

const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const IP_Review = sequelize.define('IP_Review', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  ipAddress: { 
    type: DataTypes.STRING, 
    allowNull: false, 
    unique: true // One record per unique IP
  },
  name: { // Name provided by the user
    type: DataTypes.STRING,
    allowNull: true,
  },
  stars: { // Star rating (1-5)
    type: DataTypes.INTEGER,
    allowNull: false,
    validate: {
      min: 1,
      max: 5,
    },
  },
  text: { // Review text
    type: DataTypes.TEXT,
    allowNull: true,
  },
  timestamp: { // When the review was created
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW,
  },
}, {
  tableName: 'ip_reviews',
  timestamps: false, // Disable Sequelize's automatic timestamps
});

module.exports = IP_Review;
