// src/contexts/AuthContext.js
import React, { createContext, useState, useEffect } from 'react';
import api from '../services/apiService';
import { jwtDecode } from 'jwt-decode'; // Corrected import
import CryptoJS from 'crypto-js';

// ==========================
// 1) Encryption / Hash Setup
// ==========================

// Reuse your environment-based encryption key
const encryptionKey = process.env.REACT_APP_ENCRYPTION_KEY;

// Flag to enable or disable encryption for localStorage
const encryptionEnabledFlag = process.env.REACT_APP_ENCRYPTION_ENABLED === '1';

// Use CryptoJS for hashing and encryption

/**
 * When encryptionEnabledFlag = true, hash the key with SHA-256.
 * Otherwise, store the key as plain text.
 */
const maybeHashKey = (key) => {
  if (encryptionEnabledFlag) {
    return CryptoJS.SHA256(key).toString();
  } else {
    return key; // store as plain text key
  }
};

/**
 * Encrypt/decrypt text if encryptionEnabledFlag = true.
 * Otherwise, store/fetch in plain text.
 */
const encryptLocalData = (plainText) => {
  if (!encryptionKey) {
    throw new Error('REACT_APP_ENCRYPTION_KEY is missing. Please set in your .env file.');
  }
  return CryptoJS.AES.encrypt(plainText, encryptionKey).toString();
};

const decryptLocalData = (cipherText) => {
  if (!encryptionKey) {
    throw new Error('REACT_APP_ENCRYPTION_KEY is missing. Please set in your .env file.');
  }
  const bytes = CryptoJS.AES.decrypt(cipherText, encryptionKey);
  return bytes.toString(CryptoJS.enc.Utf8);
};

/**
 * A secure wrapper around localStorage to maybe hash the key
 * and optionally encrypt the value if encryptionEnabledFlag = true.
 */
const secureLocalStorage = {
  setItem: (key, value) => {
    if (!key) return;
    const storageKey = maybeHashKey(key);

    if (encryptionEnabledFlag) {
      const encryptedValue = encryptLocalData(value);
      localStorage.setItem(storageKey, encryptedValue);
    } else {
      localStorage.setItem(storageKey, value);
    }
  },
  getItem: (key) => {
    if (!key) return null;
    const storageKey = maybeHashKey(key);

    const storedValue = localStorage.getItem(storageKey);
    if (!storedValue) return null;

    if (encryptionEnabledFlag) {
      try {
        return decryptLocalData(storedValue);
      } catch (error) {
        console.error('Failed to decrypt localStorage value:', error);
        return null;
      }
    }
    return storedValue;
  },
  removeItem: (key) => {
    if (!key) return;
    const storageKey = maybeHashKey(key);
    localStorage.removeItem(storageKey);
  },
  clear: () => {
    localStorage.clear();
  },
};

// ==========================
// 2) AuthContext Code
// ==========================

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true); // Initialize loading to true

  useEffect(() => {
    const initializeAuth = async () => {
      const token = secureLocalStorage.getItem('token'); // <== replaced localStorage.getItem
      if (token) {
        try {
          const decoded = jwtDecode(token);
          // Optionally, verify token expiration
          const currentTime = Date.now() / 1000;
          if (decoded.exp < currentTime) {
            // Token has expired
            logout();
          } else {
            setUser(decoded);
            api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
            api.defaults.headers.common['ngrok-skip-browser-warning'] = `true`;
          }
        } catch (error) {
          console.error('Invalid token:', error);
          logout();
        }
      }
      setLoading(false); // Authentication check completed
    };

    initializeAuth();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const login = async (email, password) => {
    try {
      const response = await api.post('/auth/login', { email, password });
      const { token } = response.data;
      secureLocalStorage.setItem('token', token); // <== replaced localStorage.setItem
      api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      const decoded = jwtDecode(token);
      setUser(decoded);
    } catch (error) {
      console.error('Login failed:', error);
      throw error; // Re-throw to handle in UI
    }
  };

  const logout = () => {
    secureLocalStorage.removeItem('token'); // <== replaced localStorage.removeItem
    setUser(null);
    delete api.defaults.headers.common['Authorization'];
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, logout, setUser }}>
      {children}
    </AuthContext.Provider>
  );
};
