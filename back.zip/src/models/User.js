// models/User.js

const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const User = sequelize.define('User', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  name: {
    type: DataTypes.STRING(191),
    allowNull: true, 
  },
  email: { 
    type: DataTypes.STRING(191), 
    unique: true, 
    allowNull: false 
  },
  password: { 
    type: DataTypes.STRING, 
    allowNull: true 
  },
  googleId: { 
    type: DataTypes.STRING, 
    allowNull: true 
  },
  apiKey: { 
    type: DataTypes.TEXT, // Changed from STRING to TEXT to accommodate JSON strings
    allowNull: true,
    get() {
      const rawValue = this.getDataValue('apiKey');
      return rawValue ? JSON.parse(rawValue) : {};
    },
    set(value) {
      this.setDataValue('apiKey', JSON.stringify(value));
    },
  },
  stripeCustomerId: {
    type: DataTypes.STRING,
    allowNull: true,
  },
});

module.exports = User;
