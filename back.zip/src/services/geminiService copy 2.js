// src/services/geminiService.js

const {
  GoogleGenerativeAI,
  HarmCategory,
  HarmBlockThreshold,
} = require("@google/generative-ai");
require('dotenv').config();

/**
 * Generates code based on the user's prompt and limited conversation history using Google Gemini's API.
 *
 * @param {string} apiKey - The user's Gemini API key.
 * @param {string} prompt - The prompt provided by the user.
 * @param {Array} messages - The last exchange in the conversation history as an array of message objects.
 * @param {string} conversationName - The name of the conversation.
 * @returns {Promise<string>} - The generated code.
 * @throws {Error} - Throws an error with detailed information if the API call fails.
 */
const generateCode_geminiService = async (apiKey, prompt, messages, conversationName) => {
  console.log(conversationName);
  console.log('prompt',prompt);
  console.log('messages',messages);
  // console.log('Messages sent to Gemini:', messages);

  try {
    // const databaseName = `myDatabase_${conversationName.replace(/\s+/g, '_')}`;
    
    // System Instruction
    const systemInstruction = `
    
    ### [PRIVATE INSTRUCTIONS FOR THE AI SYSTEM]

    You are a highly skilled AI assistant specializing in generating complete, functional, and secure HTML5 applications based on user requests for example:
  

Application Functionality

    Implement Create, Read, Update, and Delete (CRUD) operations.
    On any data modification, send a WRITE_FILE message to update data.json.
    Provide real-time UI updates upon data changes.
    Perform the actual functionality requested by the user (e.g., if the user wants a PDF converter, ensure the code truly converts Word to PDF).

Code Structure

    Provide a single HTML file with embedded <style> and <script> sections (no external dependencies).
    Write clean, well-organized code.
    Include comments explaining key sections and functions.

User Interface

    Offer enough information so users understand how to use the app.
    Important :Design a responsive, user-friendly interface with modern UI/UX, theme, pattern, colors, elements and accessibility considerations (e.g., ARIA labels, keyboard navigation).
    Also :The application's interface should cover the entire body to ensure it displays properly and that scrollbars appear correctly, rather than just covering only a part so make attention about heights.
    For math formulas use <math>.





### **End of PRIVATE INSTRUCTIONS**  
    `

    // Initialize the Google Generative AI client
    const genAI = new GoogleGenerativeAI(apiKey);

    // Prepare the message history for Gemini with correct roles
    const geminiHistory = messages.map((msg) => ({
      role: msg.sender === 'user' ? 'user' : 'model',
      parts: [
        {
          text: msg.content,
        },
      ],
    }));

    // Append the current user prompt
    geminiHistory.push({
      role: 'user',
      parts: [
        {
          text: 'user request: '+prompt,
        },
      ],
    });


    const safetySettings  = [
      // {
      //   category: HarmCategory.HARM_CATEGORY_HARASSMENT,
      //   threshold: HarmBlockThreshold.BLOCK_NONE,
      // },
      // {
      //   category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
      //   threshold: HarmBlockThreshold.BLOCK_NONE,
      // },
      // {
      //   category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
      //   threshold: HarmBlockThreshold.BLOCK_NONE,
      // },
      // {
      //   category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
      //   threshold: HarmBlockThreshold.BLOCK_NONE,
      // }
    ];

    // Get the generative model
    const model = genAI.getGenerativeModel({
      // model: "gemini-2.0-flash-exp",
      model: "gemini-2.0-flash-thinking-exp-01-21",
      systemInstruction: systemInstruction,
      safetySettings
    });


    // Define generation configuration without unsupported fields
    const generationConfig = {
      temperature: 0.2, // Controls randomness: 0 (deterministic) to 1 (creative)
      topP: 0.95,
      topK: 40,
      maxOutputTokens: 50000, // Adjust based on expected response length
      responseMimeType: "text/plain",
    };

    // Start the chat session with history
    const chatSession = model.startChat({
      generationConfig,
      history: geminiHistory,
    });

    // Send the user's message and await the response
    const result = await chatSession.sendMessage(prompt);

    // Extract the generated text
    const generatedText = result.response.text().trim();

    // Optional: Extract code blocks if necessary
    const extractedCode = extractCodeBlocks(generatedText);

    // console.log('Extracted Code:', extractedCode);

    // Return the extracted code or the entire generated text
    return extractedCode.length > 0 ? extractedCode[0] : generatedText;
  } catch (err) {
    console.error(
      'Error generating code with Gemini:',
      err.response ? err.response.data : err.message
    );

    // Prepare detailed error message
    let detailedError = 'Failed to generate code. Please try again later.';
    if (err.response && err.response.data) {
      detailedError = `Gemini API Error: ${JSON.stringify(err.response.data)}`;
    } else if (err.message) {
      detailedError = `Error: ${err.message}`;
    }

    // Throw a new error with detailed information
    const error = new Error(detailedError);
    error.originalError = err; // Attach the original error for further inspection if needed
    console.log('*********************************');
console.log(error);
console.log('*********************************');
    throw error;
  }
};

/**
 * Extracts code blocks from the given text.
 *
 * @param {string} text - The text containing code blocks.
 * @returns {Array<string>} - An array of extracted code blocks.
 */
function extractCodeBlocks(text) {
  // Regular expression to match ```html or ```javascript or ```css followed by any content until ```
  const regex = /```(?:html|javascript|css)\s*([\s\S]*?)\s*```/g;

  // Initialize an array to hold the extracted code blocks
  const codeBlocks = [];

  // Use matchAll to find all matches in the text
  const matches = text.matchAll(regex);

  // Iterate over each match and push the captured group to the codeBlocks array
  for (const match of matches) {
    // match[1] contains the content between the code block delimiters
    codeBlocks.push(match[1]);
  }

  return codeBlocks;
}

module.exports = { generateCode_geminiService };
