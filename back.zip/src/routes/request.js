// src/routes/request.js
const express = require('express');
const router = express.Router();
const { handleRequest } = require('../controllers/requestController');
const auth = require('../middleware/auth');
const Noauth = require('../middleware/NoAuth');


if (process.env.LMARHALA==0) {
    router.post('/', Noauth, handleRequest);
}

else {
    router.post('/', auth, handleRequest);
}



module.exports = router;
