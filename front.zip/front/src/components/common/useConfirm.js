// useConfirm.js
import React, { useState } from 'react';

export function useConfirm() {
  const [confirmState, setConfirmState] = useState({
    isOpen: false,
    message: '',
    resolve: null, // we'll store the promise's resolve here
  });

  /**
   * Opens the modal with the given message, returning a promise that
   * resolves true or false based on user action.
   */
  const confirm = (message) => {
    return new Promise((resolve) => {
      setConfirmState({
        isOpen: true,
        message,
        resolve, // store the resolve function so we can call it later
      });
    });
  };

  // When user clicks "Yes"
  const handleConfirm = () => {
    setConfirmState((prev) => {
      if (prev.resolve) prev.resolve(true);
      return { ...prev, isOpen: false };
    });
  };

  // When user clicks "No" or clicks outside the modal
  const handleCancel = () => {
    setConfirmState((prev) => {
      if (prev.resolve) prev.resolve(false);
      return { ...prev, isOpen: false };
    });
  };

  /**
   * The actual ConfirmModal component
   */
  const ConfirmModal = () => {
    if (!confirmState.isOpen) return null;

    return (
      <>
        {/* Inline styles for the modal and overlay */}
        <div style={modalOverlayStyle} onClick={handleCancel}>
          <div style={modalStyle} onClick={(e) => e.stopPropagation()}>
            <h3 style={modalHeaderStyle}>Confirmation</h3>
            <p style={modalMessageStyle}>{confirmState.message}</p>
            <div style={buttonContainerStyle}>
              <button className="submitBtnHelp" onClick={handleConfirm}>
                Yes
              </button>
              <button className="closeBtnHelp" onClick={handleCancel}>
                No
              </button>
            </div>
          </div>
        </div>

        {/* Style tag for button styles */}
        <style>
          {`
            .closeBtnHelp {
              background-color: #f0f8ff00 !important;
              border: 1px solid black !important;
              color: black !important;
              border-radius: 8px !important;
              padding: 4px 15px !important;
              cursor: pointer !important;
              font-size: 14px !important;
              font-weight: 600 !important;
              margin-right: 10px !important;
              transition: background-color 0.3s, color 0.3s;
            }

            .closeBtnHelp:hover {
              background-color: #000000 !important;
              color: white !important;
            }

            .submitBtnHelp {
              border-radius: 8px !important;
              padding: 5px 15px !important;
              cursor: pointer !important;
              font-size: 14px !important;
              font-weight: 600 !important;
              background-color:rgb(0, 0, 0) !important;
              color: white !important;
              border: none !important;
              margin-right: 10px !important;
              transition: background-color 0.3s, color 0.3s;
            }

            .submitBtnHelp:hover {
              background-color: #505050 !important;
              color: white !important;
            }
          `}
        </style>
      </>
    );
  };

  return {
    confirm,
    ConfirmModal,
  };
}

/* Enhanced inline styles for a modern look */

const modalOverlayStyle = {
  position: 'fixed',
  top: 0,
  left: 0,
  width: '100vw',
  height: '100vh',
  backgroundColor: 'rgba(0, 0, 0, 0.5)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  zIndex: 1000, // Ensure the modal is on top
};

const modalStyle = {
  background: '#ffffff',
  padding: '2rem',
  borderRadius: '8px',
  minWidth: '300px',
  maxWidth: '90%',
  boxShadow: '0 5px 15px rgba(0,0,0,0.3)',
  animation: 'fadeIn 0.3s ease-out',
};

const modalHeaderStyle = {
  marginTop: 0,
  marginBottom: '1rem',
  fontSize: '1.25rem',
  color: '#333',
  textAlign: 'center',
};

const modalMessageStyle = {
  marginBottom: '1.5rem',
  fontSize: '1rem',
  color: '#555',
  textAlign: 'center',
};

const buttonContainerStyle = {
  display: 'flex',
  justifyContent: 'center',
  gap: '1rem',
};


