import React from 'react';
import Modal from 'react-modal';
import {
  FacebookShareButton,
  TwitterShareButton,
  LinkedinShareButton,
  WhatsappShareButton,
  FacebookIcon,
  XIcon,
  LinkedinIcon,
  WhatsappIcon,
} from 'react-share';
import './ShareModal.css'; // Ensure this file exists for styling

// Bind modal to your appElement (http://reactcommunity.org/react-modal/accessibility/)
Modal.setAppElement('#root');

const ShareModal = ({ isOpen, onRequestClose, shareUrl, title, description }) => {
  const copyToClipboard = () => {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(shareUrl)
        .then(() => {
          alert('#success:Link copied to clipboard!');
        })
        .catch((err) => {
          console.error('Failed to copy: ', err);
          fallbackCopyText();
        });
    } else {
      fallbackCopyText();
    }
  };

  const fallbackCopyText = () => {
    // Create a temporary textarea element
    const textArea = document.createElement('textarea');
    textArea.value = shareUrl;
    // Avoid scrolling to bottom
    textArea.style.position = 'fixed';
    textArea.style.top = '0';
    textArea.style.left = '0';
    textArea.style.width = '2em';
    textArea.style.height = '2em';
    textArea.style.padding = '0';
    textArea.style.border = 'none';
    textArea.style.outline = 'none';
    textArea.style.boxShadow = 'none';
    textArea.style.background = 'transparent';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();

    try {
      const successful = document.execCommand('copy');
      if (successful) {
        alert('#success:Link copied to clipboard!');
      } else {
        alert('Failed to copy link.');
      }
    } catch (err) {
      console.error('Fallback: Oops, unable to copy', err);
      alert('Failed to copy link.');
    }

    document.body.removeChild(textArea);
  };

  return (
    <Modal
      isOpen={isOpen}
      onRequestClose={onRequestClose}
      contentLabel="Share this app"
      className="share-modal"
      overlayClassName="share-modal-overlay"
    >
      <h2>Share This App</h2>
      <button onClick={onRequestClose} className="close-button">
        &times;
      </button>
      <div className="share-buttons">
        <FacebookShareButton url={shareUrl} quote={description}>
          <FacebookIcon size={48} round />
        </FacebookShareButton>
        <TwitterShareButton url={shareUrl} title={title}>
          <XIcon size={48} round />
        </TwitterShareButton>
        <LinkedinShareButton url={shareUrl} title={title} summary={description}>
          <LinkedinIcon size={48} round />
        </LinkedinShareButton>
        <WhatsappShareButton url={shareUrl} title={title}>
          <WhatsappIcon size={48} round />
        </WhatsappShareButton>
      </div>
      <div className="share-link">
        <input
          type="text"
          value={shareUrl}
          readOnly
          onClick={(e) => e.target.select()}
        />
        <button onClick={copyToClipboard}>Copy</button>
      </div>
    </Modal>
  );
};

export default ShareModal;
