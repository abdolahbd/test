const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Invoice = sequelize.define('Invoice', {
  id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
  user_id: { type: DataTypes.INTEGER, allowNull: false },
  subscriptionId: { type: DataTypes.INTEGER, allowNull: false },
  stripeInvoiceId: { type: DataTypes.STRING, allowNull: false, unique: true },
  amountDue: { type: DataTypes.FLOAT, allowNull: false },
  amountPaid: { type: DataTypes.FLOAT, allowNull: false },
  status: { type: DataTypes.STRING, allowNull: false },
  invoiceDate: { type: DataTypes.DATE, allowNull: false },
  dueDate: { type: DataTypes.DATE, allowNull: true },
  pdfUrl: { type: DataTypes.STRING, allowNull: true } // Add this line
});

Invoice.associate = (models) => {
  Invoice.belongsTo(models.User, { foreignKey: 'user_id' });
  Invoice.belongsTo(models.Subscription, { foreignKey: 'subscriptionId' });
};

module.exports = Invoice;
