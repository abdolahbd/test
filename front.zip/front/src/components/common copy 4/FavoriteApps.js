import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { IoIosArrowDropdown, IoIosArrowDropup } from "react-icons/io";
import './FavoriteApps.css'; // Ensure you import the CSS

const FavoriteApps = ({
  favoriteConversations,
  conversations,
  currentConversation,
  isLimitReached,
  removeFavoriteConversation,
  handleSelectConversation,
}) => {
  // State to manage collapse/expand of the favorite apps section
  const [isFavoriteAppsCollapsed, setIsFavoriteAppsCollapsed] = useState(false);

  // State to manage how many favorites are currently displayed
  const [displayedFavoritesCount, setDisplayedFavoritesCount] = useState(7);

  // Handler to toggle the collapse state
  const toggleFavoriteAppsCollapse = () => {
    setIsFavoriteAppsCollapsed(!isFavoriteAppsCollapsed);
  };

  // Handler to load more favorites
  const handleLoadMore = () => {
    setDisplayedFavoritesCount(prevCount => prevCount + 7);
  };

  // Map favorite IDs to conversation objects and filter out any undefined
  const favoriteConversationsData = favoriteConversations
    .map(favId => conversations.find(c => c.id === favId))
    .filter(convo => convo !== undefined);

  // Determine if there are more favorites to load
  const hasMoreFavorites = displayedFavoritesCount < favoriteConversationsData.length;

  // Slice the favorites to display based on the current count
  const favoritesToDisplay = favoriteConversationsData.slice(0, displayedFavoritesCount);

  return (
    <div className="sidebar-section favorite-apps-section">
      <div className="favorite-apps-header" onClick={toggleFavoriteAppsCollapse}>
        <h2 className='section-collapse'>
          <span>✨ Favorite Apps</span>
          <span className='section-collapse-icon'>
            {isFavoriteAppsCollapsed ? <IoIosArrowDropdown /> : <IoIosArrowDropup />}
          </span>
        </h2>
      </div>

      {/* Smooth expand/collapse for the entire favorite apps list */}
      <div className={`favorite-apps-container ${isFavoriteAppsCollapsed ? '' : 'open'}`}>
        {favoriteConversationsData.length > 0 ? (
          <ul className="favorite-apps-list">
            {favoritesToDisplay.map((convo, index) => {
              const convoIndex = conversations.findIndex(c => c.id === convo.id);
              return (
                <li
                  key={convo.id}
                  className={`favorite-conversation-item ${currentConversation && currentConversation.id === convo.id ? 'active' : ''}`}
                  onClick={() => handleSelectConversation(convo, convoIndex)}
                  style={
                    isLimitReached && convoIndex >= 3
                      ? { pointerEvents: 'none', opacity: 0.5 }
                      : {}
                  }
                >
                  <span className="conversation-name" title={convo.name}>
                    {convo.name}
                  </span>
                  {!isLimitReached && (
                    <button
                      className="remove-favorite-btn"
                      onClick={(e) => {
                        e.stopPropagation();
                        removeFavoriteConversation(convo.id);
                      }}
                      title="Remove from Favorites"
                    >
                      🗑️
                    </button>
                  )}
                </li>
              );
            })}
          </ul>
        ) : (
          <p className="no-favorites-message">No favorite apps.</p>
        )}

        {/* "Load More Favorites" button */}
        {hasMoreFavorites && (
          <button className="load-more-favorites-btn" onClick={handleLoadMore}>
            Load More Favorites
          </button>
        )}
      </div>
    </div>
  );
};

FavoriteApps.propTypes = {
  favoriteConversations: PropTypes.arrayOf(PropTypes.string).isRequired,
  conversations: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    lastModified: PropTypes.number,
  })).isRequired,
  currentConversation: PropTypes.shape({
    id: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    lastModified: PropTypes.number,
  }),
  isLimitReached: PropTypes.bool.isRequired,
  removeFavoriteConversation: PropTypes.func.isRequired,
  handleSelectConversation: PropTypes.func.isRequired,
};

export default FavoriteApps;
